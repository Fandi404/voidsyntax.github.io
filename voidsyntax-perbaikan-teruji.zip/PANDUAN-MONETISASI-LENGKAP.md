# 💰 PANDUAN MASTER MONETISASI LENGKAP
## VoidSyntax TikTok Downloader — https://voidsyntax.my.id

> Semua angka & langkah di dokumen ini sudah diverifikasi (saweria.co, monetag.com,
> sumber Indonesia 2025–2026). Website Anda sudah SIAP: semua slot iklan, donasi,
> dan analytics sudah terpasang — panduan ini fokus ke **cara membuat akun** dan
> **cara menempatkan** setiap metode monetisasi.

---

## 🚀 MULAI HARI INI — 5 AKSI PERTAMA (urutan prioritas)

| # | Aksi | Waktu | Hasil |
|---|---|---|---|
| 1 | Daftar **Adsterra** (publisher) → add website → tunggu approve | 30 menit + 1–3 hari | Iklan siap dipasang |
| 2 | Daftar **Monetag** → add site → buat zone | 30 menit + cepat | Cadangan network #2 |
| 3 | Daftar **Saweria** → isi link + QR ke config | 30 menit | Donasi DANA/ShopeePay/QRIS aktif |
| 4 | Buat **Google Analytics 4** → isi `ga4_id` | 20 menit | Bisa pantau traffic |
| 5 | Upload `config/monetization.php` (+ QR Saweria) ke hosting | 10 menit | Semua mulai tayang |

Setelah itu: promosi (TikTok @_fandi96, komunitas) + 1 artikel baru per minggu.
Traffic = uang. Iklan & donasi hanya mulai menghasilkan kalau ada kunjungan.

---

# 📑 DAFTAR ISI
1. [Jalur A — Iklan](#1-jalur-a--iklan) ⭐ pendapatan utama
2. [Jalur B — Donasi](#2-jalur-b--donasi) ❤️ sudah terpasang
3. [Jalur C — Google Analytics 4](#3-jalur-c--google-analytics-4)
4. [Jalur D — Affiliate](#4-jalur-d--affiliate)
5. [Jalur E — Premium Berbayar (Midtrans/Xendit)](#5-jalur-e--premium-berbayar)
6. [Jalur F — Aplikasi & Google Play](#6-jalur-f--aplikasi--google-play)
7. [Traffic = Uang](#7-traffic--uang)
8. [Ekspektasi & Perhitungan Realistis](#8-ekspektasi--perhitungan-realistis)
9. [Checklist Urutan Kerja](#9-checklist-urutan-kerja)
10. [Lampiran: Struktur config/monetization.php](#10-lampiran-struktur-configmonetizationphp)
11. [Cara Upload ke Hosting (Rumahweb cPanel)](#11-cara-upload-ke-hosting-rumahweb-cpanel)

---

# 1. JALUR A — IKLAN ⭐ (pendapatan pasif utama)

## 1.0 Kenapa mulai dari ad network alternatif, bukan AdSense?

Google AdSense **sering MENOLAK** website downloader karena kebijakan hak cipta
("memfasilitasi download konten berhak cipta"). Kalau dipaksa lolos lalu ketahuan,
akun bisa **diblokir permanen dan saldo hangus**. Network alternatif (Adsterra,
Monetag, PropellerAds, PopCash) memang menerima niche ini.

## 1.1 Pilih network — perbandingan (terverifikasi 2026)

| Network | Website | Format iklan | Min. payout | Dibayar | Catatan |
|---|---|---|---|---|---|
| **Adsterra** | publishers.adsterra.com | Banner, Popunder, Social Bar, Native | ~$5 (PayPal/Payoneer/crypto) | 2× sebulan (sekitar tgl 1 & 16) | Approval cepat, tanpa minimum traffic, cocok segala niche |
| **Monetag** | monetag.com | Popunder, Push, In-Page Push, Vignette, SmartLink | $5 | Mingguan | Dulunya PropellerAds. Approval instan/cepat. Bisa jalan bareng AdSense |
| **PropellerAds** | propellerads.com | Popunder (OnClick), Banner, Native, Push | $5 | Mingguan (Kamis) | Tanpa minimum traffic; hasil kecil kalau <1.000 kunjungan/hari |
| **PopCash** | popcash.net | Popunder saja | $10 | On request (24–48 jam) | Approval <12 jam kerja |

**Rekomendasi urutan:** 1) Adsterra → 2) Monetag → 3) PropellerAds → 4) PopCash.
Jangan pasang semua sekaligus — mulai 1 network, tambah kalau sudah stabil.
Maksimal 2–3 network (kalau terlalu banyak: website jadi lambat & UX buruk).

## 1.2 PANDUAN LENGKAP — ADSTERRA (cara buat akun + buat iklan + dapat kode)

**Langkah 1 — Daftar akun**
1. Buka **https://publishers.adsterra.com** → klik **Sign Up**
2. Isi: nama lengkap, **email aktif** (afandiae01@gmail.com), password → daftar
3. Cek email → klik link konfirmasi → login ke dashboard

**Langkah 2 — Tambahkan website**
4. Dashboard → menu **Websites** → **Add Website**
5. Isi: URL = `https://voidsyntax.my.id` · kategori (pilih yang paling mendekati,
   mis. "Software/Downloads" atau "Other") · bahasa = Indonesian/English
6. **Verifikasi kepemilikan website** (pilih salah satu):
   - Upload file `.txt` yang mereka berikan ke **root website** (folder `public_html`)
     via cPanel → File Manager → Upload, ATAU
   - Tempel **meta tag** ke `<head>` website
7. Klik submit → tunggu review **±1–3 hari kerja** (notifikasi via email).
   **Tidak ada syarat minimum traffic** — website baru langsung boleh daftar.

**Langkah 3 — Buat zone iklan & dapatkan kode**
8. Setelah disetujui: **Websites** → klik nama website Anda → **Ad zones** → **New zone**
9. Pilih format yang diinginkan:
   - **Banner** → 728×90 (leaderboard atas), 300×250, 160×300, atau **Responsive**
   - **Popunder** → muncul di belakang saat klik (paling menguntungkan, paling mengganggu)
   - **Social Bar** / **Native** (opsional)
10. Klik **Get code** → **copy kode iklan** (biasanya 1 blok `<script>...`)

**Langkah 4 — Tempelkan ke website** → lihat bagian [1.7 Cara Menempatkan Kode](#17-cara-menempatkan-kode-iklan-ke-website)

**Pembayaran:** 2× sebulan (sekitar tanggal 1 & 16). Metode: PayPal, Payoneer,
WebMoney, crypto (USDT), atau wire bank (min. $100). Semua dalam **USD**.
Terima di PayPal (email afandiae01@gmail.com) atau Payoneer → tarik ke bank Indonesia.

## 1.3 PANDUAN LENGKAP — MONETAG

1. Buka **https://monetag.com** (atau publishers.monetag.com) → **Sign up** →
   email (afandiae01@gmail.com) + password → verifikasi email
2. Login → dashboard → **Sites** → **Add site** → isi `https://voidsyntax.my.id` + kategori
3. Form "What do you monetize?" → pilih **Website**. Form lainnya (contoh jawaban
   sudah saya kasih di chat): How did you hear → "Google search"; Other networks →
   sebutkan yang benar (Adsterra dalam proses, Saweria & PayPal untuk donasi);
   Tools → SEO, sosmed (TikTok/IG), komunitas, GSC, GA4
4. Setelah klik **"Add site"**, Monetag menampilkan **3 opsi verifikasi** — di sinilah
   "tag"-nya (bukan kode iklan, tapi kode verifikasi kepemilikan website):
   - **Opsi 1 (recommended oleh Monetag): download file `sw.js`** → upload ke root
     website (`public_html`) via cPanel File Manager — tanpa edit kode.
     ⚠️ File ini hanya untuk verifikasi. Jangan membuat zone **Push Notification**
     (konflik dengan service worker PWA kita — lihat pembahasan push).
   - **Opsi 2 (paling akurat menurut Monetag): copy meta tag verifikasi** → tempel ke
     `'head_tags'` di `config/monetization.php` → upload → tag otomatis tayang di
     `<head>` semua halaman
   - Opsi 3: plugin WordPress — tidak relevan (website kita custom PHP)
5. Kembali ke dashboard Monetag → klik tombol **"Verify"** → terverifikasi dalam
   **beberapa menit** (centang hijau muncul di daftar Sites)
6. Setelah verified: klik nama site Anda → **"Add zone"** → pilih format —
   **HANYA yang aman** (lihat tabel di bawah)
7. Isi nama zone (misal: `voidsyntax-popunder`) → klik **"Get tag"**
8. **Copy kode zone** (blok `<script>...</script>`) → tempel ke slot yang sesuai:
   - **Onclick (Popunder)** → `'popunder'`
   - **Vignette Banner** → `'top_banner'` atau `'bottom_banner'`
9. Upload `config/monetization.php` → iklan langsung tayang
10. Pantau: **Statistics** (impressions/earnings — data penuh ±24–48 jam)
    Payout: **mingguan**, minimum **$5**, via PayPal / Payoneer / bank / crypto

**Format Monetag — mana yang aman untuk PWA kita:**

| Format | Aman? | Kenapa |
|---|---|---|
| **Onclick (Popunder)** | ✅ **AMAN — pakai ini** | Tanpa service worker; muncul saat pengunjung klik. Paling cocok untuk niche downloader (pengunjung pasti klik tombol download) |
| **Vignette Banner** | ✅ AMAN | Banner overlay biasa di halaman, tanpa service worker |
| In-Page Push (Banner) | ⚠️ umumnya aman (tampil di halaman, tanpa izin notifikasi) — kalau ragu, lewati | Page-based, tapi namanya mirip push |
| **MultiTag** | ❌ **HINDARI** | Butuh sw.js terdaftar → bisa mengganggu service worker PWA kita |
| **Push Notifications** | ❌ **HINDARI** | Wajib sw.js terdaftar → konflik dengan PWA (fitur "Install App" bisa rusak) |

**Kenapa Popunder paling cocok untuk website downloader:** pengunjung datang untuk
download → pasti klik tombol → popunder langsung muncul. Tidak perlu izin apa pun,
tanpa service worker, tanpa gangguan PWA.

⚠️ **Anti multiaccount:** website + APK + TikTok/Sosmed Anda = **1 akun Monetag**.
Jangan buat akun kedua. Kalau memang perlu akun tambahan untuk alasan bisnis,
email dulu ke contact.us@monetag.com.

## 1.4 PANDUAN LENGKAP — PROPELLERADS

1. Buka **https://propellerads.com** → daftar sebagai **Publisher**
2. **Add website** → URL + kategori → verifikasi via meta tag
3. Approval ±1–2 hari, **tanpa minimum traffic**
4. **Zones** → pilih: **OnClick (popunder)**, Banner, Native, atau Push
5. Copy kode → tempel ke slot
6. Payout: **mingguan (setiap Kamis)**, min. **$5** — PayPal, Skrill, Payoneer,
   WebMoney, ePayments, atau transfer bank
7. Catatan jujur: di bawah ±1.000 kunjungan/hari, hasilnya relatif kecil

## 1.5 PANDUAN LENGKAP — POPCASH

1. Buka **https://popcash.net** → register → verifikasi email
2. **Add website** → review **<12 jam kerja**
3. Dapatkan kode **popunder** → tempel ke slot `popunder`
4. Payout: min. **$10**, bisa request harian, proses 24–48 jam — PayPal, Payoneer,
   Paxum, Skrill, WebMoney, crypto

## 1.6 GOOGLE ADSENSE (hati-hati — baca dulu!)

⚠️ **Peringatan:** AdSense sering menolak niche downloader (kebijakan hak cipta).
Kalau dipaksa dan lolos tapi ketahuan → **banned permanen, saldo hangus**.

**Kalau tetap mau mencoba:**
1. Buka **https://adsense.google.com** → login pakai akun Google (afandiae01@gmail.com)
2. **Sites** → **Add site** → isi `voidsyntax.my.id`
3. Verifikasi kepemilikan: upload file **ads.txt** ke root website (public_html)
   atau tempel meta tag
4. Siapkan halaman pendukung (syarat AdSense): **Privacy Policy**, **About/Tentang Kami**,
   **Contact** — disclaimer hak cipta sudah ada di footer website Anda
5. Tunggu review — bisa **1–2 minggu**, dan bisa ditolak berkali-kali (itu normal)
6. Kalau **DISETUJUI**: Anda dapat ID `ca-pub-XXXXXXXXXXXXXXXX`
7. Isi ke config:
   ```php
   'adsense_enabled' => true,
   'adsense_client'  => 'ca-pub-XXXXXXXXXXXXXXXX',
   ```
8. Upload → script AdSense otomatis tayang di `<head>` semua halaman

💡 Monetag bisa jalan **bersamaan** dengan AdSense (terverifikasi dari FAQ Monetag).
Tapi tetap: risiko ban ada di tangan Anda.

## 1.7 CARA MENEMPATKAN KODE IKLAN KE WEBSITE (detail)

**Satu-satunya file yang Anda edit:** `config/monetization.php`

Struktur slot (sudah terpasang di website):

| Slot | Kode diisi dari | Tampil di mana |
|---|---|---|
| `top_banner` | Banner 728×90 / responsive | **Atas semua halaman** (di bawah navigasi) |
| `below_result` | Banner 300×250 / responsive | Halaman utama, **di bawah kotak hasil download** |
| `bottom_banner` | Banner 728×90 / 160×300 | **Bawah semua halaman** (sebelum footer) |
| `popunder` | Kode popunder | Muncul saat pengunjung klik — **HATI-HATI, mengganggu** |

**Contoh pengisian lengkap** (buka `config/monetization.php`, tempel kode di dalam tanda `''`):

```php
'ad_slots' => [
    'top_banner'    => '<script type="text/javascript">kode-banner-atas-anda</script>',
    'below_result'  => '<script type="text/javascript">kode-banner-bawah-hasil-anda</script>',
    'bottom_banner' => '<script type="text/javascript">kode-banner-bawah-anda</script>',
    'popunder'     => '', // kosongkan kalau tidak mau popunder
],
```

**Aturan penempatan (supaya hasil maksimal & tidak di-ban):**
- ✅ Mulai 1 network, 1–2 slot dulu. Lihat hasil 1–2 minggu, baru tambah.
- ✅ Pakai format **responsive** untuk banner (otomatis menyesuaikan HP).
- ✅ Jangan menutupi tombol "Download" utama dengan iklan besar di atas.
- ⚠️ Popunder = paling cuan tapi paling mengganggu. Maksimal 1 network popunder.
- ❌ Jangan klik iklan sendiri, jangan minta teman klik, jangan pakai bot/autosurf,
  jangan refresh halaman pakai script → **akun banned permanen, saldo hangus**.
- ✅ Cek kecepatan website setelah pasang iklan (target: tetap nyaman dipakai di HP).

**Cara cek hasil:** login ke dashboard masing-masing network → lihat
impressions/clicks/earnings per hari. Bandingkan antar network & antar slot,
pindahkan kode ke slot yang paling menghasilkan.

---

# 2. JALUR B — DONASI ❤️ (sudah terpasang di website)

Bagian **"❤️ Dukung Kami"** di halaman utama sudah aktif dengan:

| Metode | Data | Status |
|---|---|---|
| 💳 PayPal | paypal.me/afandiae01@gmail.com | ✅ terpasang |
| 💙 DANA | 087711180777 (tombol salin) | ✅ terpasang |
| 🧡 ShopeePay | 087711180777 (tombol salin) | ✅ terpasang |
| ☕ Saweria | link + QR (isi setelah daftar) | ⏳ tinggal isi 2 baris |
| ☕ Ko-fi | opsional | ⏳ kosong |

**Yang tinggal Anda lakukan (Saweria — 1 link untuk semua metode Indonesia):**
1. Daftar di **saweria.co/register** (email afandiae01@gmail.com, verifikasi,
   pilih username — ini jadi link Anda: `saweria.co/usernamekamu`, usia 17+)
2. Login → lengkapi profil → tambah rekening bank/e-wallet tujuan (a.n. Anda)
3. Verifikasi KTP (wajib untuk cairkan)
4. Download **QR code** dari dashboard
5. Isi ke `config/monetization.php`:
   ```php
   'saweria'    => 'https://saweria.co/usernamekamu',
   'saweria_qr' => '/assets/img/saweria-qr.png',
   ```
6. Upload gambar QR ke `assets/img/saweria-qr.png` + upload config yang sudah diedit

**Biaya Saweria (terverifikasi):** 5–6% per donasi (min. Rp150) + gateway 0,8–2%
+ cashout Rp5.000. **Cairkan:** dashboard → "Dukungan Masuk dan Cashout" →
"Cairkan" — min. Rp50.000, proses jam kerja Sen–Jum 08.00–20.00 WIB,
donasi masuk saldo setelah ±3 hari kerja verifikasi.

**PayPal (untuk donatur luar negeri):** tombol sudah terpasang. Pastikan akun
PayPal Anda terdaftar dengan email **afandiae01@gmail.com**. Untuk tarik dana
ke bank Indonesia: cek opsi penarikan di akun PayPal (atau via Payoneer).

---

# 3. JALUR C — GOOGLE ANALYTICS 4 (wajib — untuk tahu traffic dari mana)

Tanpa analytics, Anda "buta": tidak tahu berapa kunjungan, dari mana, halaman mana
yang paling sering dibuka.

**Cara buat (sekali, ±20 menit):**
1. Buka **https://analytics.google.com** → login pakai akun Google (afandiae01@gmail.com)
2. Klik **Admin** (ikon roda gigi bawah) → **Buat properti** → nama: `VoidSyntax Downloader`
3. Isi zona waktu: **(GMT+07:00) Indonesia Barat**, mata uang: **IDR**
4. Klik **Berikutnya** → pilih platform **Web** → nama stream: `Website`
5. URL website: `https://voidsyntax.my.id` → **Buat stream**
6. Anda akan dapat **Measurement ID** berbentuk `G-XXXXXXXXXX`
   (ada di halaman detail stream / bagian "Tagging")
7. Isi ke `config/monetization.php`:
   ```php
   'ga4_id' => 'G-XXXXXXXXXX',
   ```
8. Upload config → data mulai muncul dalam ±24 jam

**Yang dipantau:** kunjungan real-time · sumber traffic (Google / TikTok / langsung)
· halaman terpopuler · negara pengunjung · perangkat (HP/desktop).

**Pakai data untuk keputusan:** kalau traffic banyak dari TikTok → fokus konten
TikTok. Kalau halaman artikel tertentu ramai → buat artikel serupa.

---

# 4. JALUR D — AFFILIATE (komisi dari rekomendasi)

**Program yang relevan untuk niche Anda:**
- **Aplikasi edit video**: CapCut, VN Video Editor, InShot (ada program partner/affiliate)
- **Cloud storage**: pCloud, Terabox (komisi per pendaftaran)
- **Hosting/domain**: Rumahweb & Niagahoster punya program affiliate
- **VPN** (untuk akses TikTok dari luar negeri — relevan untuk audiens internasional)

**Cara buat & menempatkan:**
1. Daftar program affiliate masing-masing (cari "[nama] affiliate program")
2. Setelah disetujui, Anda dapat **link unik** (ada kode affiliate di dalamnya)
3. Tempatkan di website:
   - **Di artikel**: misal di artikel "Cara Download Video TikTok Tanpa Watermark"
     tambah bagian: *"Sudah download? Butuh edit video? Coba CapCut → [link affiliate Anda]"*
   - **Banner kecil** di halaman artikel (bisa pakai slot iklan yang sama atau bagian artikel)
4. Bagikan juga link affiliate di caption video TikTok/IG Anda

**Tips:** link harus relevan dengan konteks (jangan asal tempel), cek hasil
per link di dashboard affiliate, fokus ke 1–2 program dulu.

---

# 5. JALUR E — PREMIUM BERBAYAR (masa depan — Midtrans / Xendit)

**Kapan baru jalan:** kalau traffic sudah besar (ribuan kunjungan/hari) dan Anda
mau jual fitur premium, misal: tanpa iklan, batch download, prioritas server.

**Payment gateway pilihan (terverifikasi):**

| | Midtrans | Xendit |
|---|---|---|
| Daftar untuk perorangan | ✅ bisa (KTP, NPWP kalau ada, rekening a.n. sama) | ✅ bisa, tidak wajib badan hukum |
| Verifikasi | 1–5 hari kerja | 1–5 hari kerja |
| Metode terima | Snap: QRIS, VA semua bank, DANA/GoPay/OVO/ShopeePay, kartu kredit, Indomart/Alfamart (18 metode) | QRIS, VA, e-wallet (DANA/GoPay/OVO/ShopeePay), kartu, retail, + **xenInvoice** (link bayar via WA) |
| Biaya | sekitar 0,7%–3% per transaksi tergantung metode (cek dashboard) | sama, cek dashboard |

**Langkah umum (kedua platform):**
1. Siapkan: KTP, NPWP (kalau ada), rekening bank aktif atas nama sendiri, deskripsi bisnis
2. Daftar di website platform → isi formulir KYC → upload dokumen
3. Tunggu verifikasi 1–5 hari kerja
4. Dapatkan API key / buat halaman pembayaran → integrasikan ke website
   (butuh development — bisa kita kerjakan kalau sudah waktunya)

---

# 6. JALUR F — APLIKASI & GOOGLE PLAY

**Kenapa ini penting untuk exposure:** jutaan pengguna bisa install langsung dari
Play Store — traffic terbesar untuk niche downloader.

1. Daftar **Google Play Console** → https://play.google.com/console → bayar **$25 sekali** (seumur hidup)
2. Build versi **AAB yang di-sign** (bukan APK debug) — bisa dari project Android
   Studio yang sudah ada (`android-app/`) atau via **PWABuilder** (pwabuilder.com,
   gratis, tanpa coding)
3. Isi store listing: nama, deskripsi, ikon 512px (sudah ada: `icon-512.png`),
   screenshot, konten rating
4. Upload AAB → review Google ±1–7 hari → tayang
5. **Monetisasi di aplikasi:** daftar **AdMob** → buat unit iklan (banner/interstitial)
   → hubungkan ke aplikasi → dapat juga pendapatan dari pengguna aplikasi

⚠️ Hati-hati: aplikasi downloader juga bisa ditolak Play Store (kebijakan hak cipta).
Deskripsi harus hati-hati (tidak menjanjikan download konten berhak cipta secara eksplisit).

---

# 7. TRAFFIC = UANG 🔑

Semua jalur di atas **hanya menghasilkan kalau ada kunjungan**. Urutan promosi:

**A. SEO (gratis, efek jangka panjang)**
- Sudah ada: 3 artikel di `/artikel/`, sitemap, JSON-LD, OG meta ✅
- Lanjutkan: **1 artikel baru per minggu**. Keyword target:
  - "download tiktok tanpa watermark"
  - "cara download video tiktok tanpa aplikasi"
  - "download tiktok mp3 tanpa watermark"
  - "tiktok downloader tanpa wm"
  - "cara simpan video tiktok ke galeri"
- Artikel baru → tambah URL ke `sitemap.xml` → submit/request indexing di Google Search Console
- Daftar juga di **Bing Webmaster Tools** (webmaster.bing.com) → submit sitemap

**B. Media sosial (efek cepat)**
- **TikTok @_fandi96**: video pendek "cara download TikTok tanpa watermark 2026"
  (tutorial 15–30 detik, link website di bio) — paling efektif untuk niche ini
- Instagram Reels, X/Twitter — konten yang sama
- Caption setiap video: link + QR Saweria Anda

**C. Komunitas (gratis)**
- Grup WhatsApp & channel Telegram (bagikan link +QR, jangan spam)
- Reddit r/Indonesia, Quora (jawaban pertanyaan + link website)
- Kaskus (thread teknologi), forum downloader

**D. Direktori & backlink**
- Upload APK ke direktori: APKPure, Uptodown (hati-hati clone/scam)
- Komentar bermanfaat di blog teknologi Indonesia (link ke website Anda)

**E. Performa website (faktor ranking Google)**
- Sudah cepat, mobile-friendly, SSL aktif ✅ — pertahankan

---

# 8. EKSPEKTASI & PERHITUNGAN REALISTIS

**RPM (pendapatan per 1.000 kunjungan) traffic Indonesia di ad network alternatif:**
sekitar **$0,30 – $1** (banner). Popunder bisa lebih tinggi tapi mengganggu UX.
Google AdSense (kalau lolos): RPM Indonesia sekitar **$0,50 – $2**.

| Kunjungan/hari | Per hari | Per bulan (iklan saja) |
|---|---|---|
| 1.000 | ±$0,30–1 | ±$9–30 (±Rp150rb–500rb) |
| 5.000 | ±$1,50–5 | ±$45–150 (±Rp750rb–2,5jt) |
| 10.000 | ±$3–10 | ±$90–300 (±Rp1,5jt–5jt) |

**Donasi (Saweria):** sangat bergantung komunitas. Audiens Indonesia yang loyal
seringkali lebih dermawan daripada nilai iklan. Contoh: 1 donasi Rp20.000/hari
= Rp600.000/bulan — bisa melebihi iklan kalau komunitasnya aktif.

**Realita (jujur):** butuh **3–6 bulan konsisten** (konten + promosi + optimasi)
sebelum hasil terasa. Tidak ada cara cepat — yang penting: konsisten.

---

# 9. CHECKLIST URUTAN KERJA

**Hari 1–2 (setup — ±2 jam):**
- [ ] Daftar Adsterra → add website → verifikasi → tunggu approve
- [ ] Daftar Monetag → add site → buat 1 zone popunder
- [ ] Daftar Saweria → verifikasi → isi link + QR ke config → upload
- [ ] Buat GA4 → isi `ga4_id` → upload config
- [ ] Upload `config/monetization.php` + QR Saweria ke hosting
- [ ] Cek: iklan tampil? tombol Saweria + QR tampil? analytics terpasang?

**Minggu 1–2 (promosi):**
- [ ] 3–5 video TikTok @_fandi96 (tutorial + link di bio)
- [ ] Posting Instagram + X
- [ ] Bagikan ke 3–5 grup WA/Telegram komunitas
- [ ] Jawab 2–3 pertanyaan di Quora/Reddit dengan link website

**Minggu 3–4 (konten & optimasi):**
- [ ] 1 artikel baru (keyword baru) → update sitemap → request indexing
- [ ] Cek GA4: sumber traffic terbesar → fokus ke sana
- [ ] Cek dashboard iklan: pindahkan kode ke slot yang paling menghasilkan
- [ ] Tambah network ke-2 (kalau yang pertama sudah stabil)

**Bulan 2–3 (skala):**
- [ ] Artikel rutin mingguan, 2–3 video TikTok/minggu
- [ ] Daftar PropellerAds/PopCash sebagai cadangan
- [ ] Evaluasi: daftar affiliate yang relevan
- [ ] Kalau traffic sudah besar: pertimbangkan Play Store & premium

**Bulan 3–6 (cairkan & pertahankan):**
- [ ] Cairkan saldo iklan (PayPal/Payoneer → bank) saat sudah melewati minimum
- [ ] Cairkan Saweria (min. Rp50.000, jam kerja)
- [ ] Teruskan konten — hasil biasanya mulai terasa di bulan ke-3 sampai ke-6

---

# 10. LAMPIRAN: STRUKTUR `config/monetization.php` (lengkap)

```php
<?php
$MONETIZATION = [

    /* ---------- Google AdSense (hati-hati, sering tolak niche downloader) ---------- */
    'adsense_enabled' => false,
    'adsense_client'  => 'ca-pub-XXXXXXXXXXXXXXXX',

    /* ---------- Slot iklan (Adsterra / Monetag / PropellerAds / PopCash) ---------- */
    'ad_slots' => [
        'top_banner'    => '', // banner atas semua halaman (728x90 / responsive)
        'below_result'  => '', // bawah hasil download (halaman utama)
        'bottom_banner' => '', // banner bawah semua halaman (sebelum footer)
        'popunder'     => '', // HATI-HATI, mengganggu UX
    ],

    /* ---------- Tag global ad network ---------- */
    'site_tags' => '', // tag JS global (mis. MultiTag) — tayang sebelum </body>

    /* ---------- Tag di <head> ---------- */
    'head_tags' => '', // meta tag verifikasi Monetag — tayang di <head> semua halaman

    /* ---------- Donasi ---------- */
    'donation' => [
        'enabled' => true,
        'saweria'    => 'https://saweria.co/usernamekamu',
        'saweria_qr' => '/assets/img/saweria-qr.png',
        'ko-fi'   => '',
        'paypal'  => 'https://paypal.me/afandiae01@gmail.com',
        'dana'    => '087711180777',
        'shopee'  => '087711180777',
    ],

    /* ---------- Google Analytics 4 ---------- */
    'ga4_id' => 'G-XXXXXXXXXX',
];
```

**Aturan:** slot yang kosong = tidak tampil (aman). Satu-satunya file yang perlu
Anda edit untuk monetisasi adalah file ini.

---

# 11. CARA UPLOAD KE HOSTING (Rumahweb — cPanel)

**A. Edit & upload satu file saja:**
1. Download `config/monetization.php` dari cPanel File Manager (atau pakai yang dari ZIP)
2. Edit dengan Notepad/Notepad++ sesuai panduan di atas
3. Upload kembali (timpa) via File Manager → Upload, atau
   cPanel → File Manager → klik file → **Edit** (edit langsung di server)

**B. Upload QR Saweria:**
1. File Manager → folder `assets/img/` → Upload → pilih gambar QR dari Saweria
   dengan nama **persis**: `saweria-qr.png`

**C. Upload semua versi terbaru (kalau ragu):**
1. Download ZIP terbaru dari saya: `voidsyntax-tiktok-downloader.zip`
2. cPanel → File Manager → `public_html` → **Upload** → pilih ZIP → **Extract**
3. Edit `config/monetization.php` sesuai panduan → selesai

**D. Cek hasil (wajib setelah upload):**
- Buka `https://voidsyntax.my.id` → scroll ke bawah: harus muncul bagian
  **"❤️ Dukung Kami"** dengan tombol PayPal + card DANA/ShopeePay (+ QR & tombol
  Saweria kalau sudah diisi)
- Kalau iklan sudah diisi: banner muncul di atas/bawah halaman
- Kalau halaman terlihat lama (cache): tekan **Ctrl + F5**

---

## ⚠️ ATURAN EMAS (jangan dilanggar — akun bisa banned permanen)

1. Jangan klik iklan sendiri / minta teman klik / pakai bot
2. Jangan manipulasi traffic (autosurf, refresh script, incentivized)
3. Jangan pasang iklan di konten ilegal/dewasa/bajakan
4. Jangan terlalu banyak iklan (website lambat = ranking Google turun = traffic turun)
5. Semua angka bisa berubah — selalu cek dashboard resmi masing-masing platform

## 📝 CATATAN PAJAK (jujur, singkat)

Pendapatan dari iklan/donasi adalah penghasilan. Untuk nominal kecil & tidak rutin,
umumnya tidak perlu tindakan. Kalau sudah rutin & besar, konsultasikan ke konsultan
pajak (PPH sesuai aturan yang berlaku). Dokumen ini bukan nasihat pajak.

---

*Panduan dibuat khusus untuk VoidSyntax TikTok Downloader (voidsyntax.my.id) — Fandi*
*Update terakhir: 2026-10-08*
