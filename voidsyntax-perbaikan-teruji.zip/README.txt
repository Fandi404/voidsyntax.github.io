============================================================
 VOIDSYNTAX TIKTOK + DOUYIN DOWNLOADER — 100% GRATIS
 Domain : https://voidsyntax.my.id
 Hosting: Rumahweb (Shared Hosting, cPanel)
 Tanggal: 2026-10-10
 Versi  : 1.3.0 (tema ORISINAL Cosmic Aurora — desain sendiri, aman
        hak cipta + Douyin + Multi-Bahasa + Slideshow/ZIP + Dark Mode
        + HD/4K & MP3 + ANTI-DOWN provider + NOTIFIKASI PEMBARUAN
        untuk aplikasi yang sudah terpasang)
============================================================

STRUKTUR FILE
- index.php               Halaman utama (clone SnapTik: hero + form + 3 kartu
                          fitur + cara pakai + tips + konten SEO + FAQ)
- cara-penggunaan.php     Halaman panduan (Cara Penggunaan)
- faq.php                 Halaman FAQ
- kontak.php              Halaman Kontak + DMCA + Privasi
- app.php                 Halaman Download APK Android
- download.php            Endpoint unduh (stream proxy, Range/resume,
                          type=hd|sd|wm|mp3|zip)
- config.php              Konfigurasi utama (domain, provider TikTok & Douyin,
                          timeout, UA, versi)
- includes/i18n.php       Mesin multi-bahasa (deteksi bahasa, t(), lang_url())
- lang/                   Terjemahan (id.php, en.php, ms.php) — 165 kunci/bahasa
- config/site.php         Konten tampilan (fitur, langkah, FAQ) — dari lang/
- config/monetization.php Pengaturan monetisasi (iklan, donasi, GA4)
- includes/functions.php  Semua fungsi inti (HTTP, parser, AUTO PROVIDER,
                          deteksi platform TikTok/Douyin, ekstrak URL share)
- includes/ads.php        Sistem monetisasi (slot iklan, donasi, popunder)
- includes/header.php     Header HTML (SEO, JSON-LD, hreflang, pemilih bahasa,
                          AdSense/GA4 opsional)
- includes/footer.php     Footer HTML (slot iklan bawah, nav, credit,
                          kamus teks VS_I18N untuk JavaScript)
- api/index.php           API JSON: /api/?url=<link tiktok/douyin>
- artikel/                Halaman artikel SEO multi-bahasa (index + 3 artikel)
- assets/css/style.css    Desain tampilan (dark theme, responsif)
- assets/js/app.js        Logika form, hasil, dan riwayat (localStorage)
- assets/img/og-thumbnail.jpg  Thumbnail share (OG image) 1200x630
- assets/img/icon-192.png Ikon aplikasi PWA 192x192
- assets/img/icon-512.png Ikon aplikasi PWA 512x512
- assets/img/icon-512-maskable.png  Ikon maskable 512x512 (untuk APK/Play Store)
- files/voidsyntax-downloader-v1.0.0.apk  Aplikasi Android (APK) — didownload
                           pengunjung langsung dari halaman utama & footer
- manifest.json           Manifest PWA (nama app, ikon, warna tema)
- service-worker.js       Service worker PWA (network-first: halaman selalu segar;
                           aset cache-first; API tidak di-cache)
- version.php             Cap versi website — untuk auto-refresh (cek tiap menit,
                           reload sendiri kalau ada update). Jangan hapus.
- .htaccess               Keamanan, API endpoint, (opsional) paksa HTTPS
- robots.txt              Aturan crawler
- sitemap.xml             Sitemap untuk Google Search Console (sudah include artikel)
- googleff3b12f5655f595a.html  File verifikasi Google Search Console
- PANDUAN-MONETISASI-LENGKAP.md  Panduan monetisasi lengkap (iklan, donasi, GA4,
                                   affiliate, premium, traffic) — file panduan saja,
                                   boleh dihapus dari hosting setelah dibaca

FITUR
- DESAIN ORISINAL "COSMIC AURORA" (bukan salinan situs lain — aman hak
  cipta): gradien indigo→langit→teal, kartu kaca, hero dengan badge hidup
  + cip fitur, form + tombol Tempel, animasi masuk saat scroll, placeholder
  berputar, bilah progres scroll, toast notifikasi, statistik animasi,
  langkah bernomor, tips pro, konten SEO panjang, FAQ accordion, footer
  gelap 4 kolom, tombol "Unduh APK" hijau, DARK MODE (toggle bulan/matahari)
- Unduh video kualitas tertinggi (label HD 1080p/4K) tanpa watermark,
  versi MP4 standar (SD), versi dengan watermark, dan audio MP3
- FOTO/SLIDESHOW: post foto TikTok & Douyin → tombol
  "Download Semua Foto (ZIP)" (otomatis dikemas jadi ZIP)
- DUKUNGAN DOUYIN (抖音): tempel link video Douyin (www.douyin.com/video/...,
  v.douyin.com/...) — deteksi platform otomatis, rantai provider khusus
  Douyin anti-down: Douyin.wtf API -> DLPanda -> Direct (scrape halaman
  share resmi Douyin + cookie ttwid, tanpa API pihak ketiga) -> TikHub
- MULTI-BAHASA: menu bahasa di pojok kanan atas (switcher SELALU berhasil
  pindah bahasa — termasuk ke Indonesia; sudah diperbaiki). Tersedia
  Indonesia / English / Bahasa Melayu. URL berprefix bahasa (/en, /ms)
  untuk SEO (hreflang otomatis). Pilihan bahasa disimpan di cookie.
- Paste teks share UTUH dari aplikasi TikTok/Douyin juga bisa — URL-nya
  diekstrak otomatis
- AUTO PROVIDER ANTI-DOWN: fallback otomatis antar provider — kalau satu
  provider down/rate-limit/ganti format, sistem langsung pindah ke
  berikutnya sampai berhasil (tanpa perlu diapa-apakan).
  TikTok (6 kaki): TikWM -> TikWM Mirror -> TiklyDown -> Douyin.wtf Hybrid
  -> TikTok Direct (scrape lokal halaman TikTok) -> TikHub (opsional,
  aktif jika TIKHUB_API_KEY diisi).
  Douyin (4 kaki): Douyin.wtf -> DLPanda -> Douyin Direct (scrape lokal
  halaman share Douyin + cookie ttwid) -> TikHub (opsional).
  Setiap provider di-retry 2x dengan jeda 1,2 detik (lolos batas
  1 request/detik TikWM); hasil sukses di-cache 15 menit (link langsung
  instan untuk pengunjung berikutnya); total waktu proses dibatasi 50 detik.
- Mendukung link pendek vm.tiktok.com / vt.tiktok.com / v.douyin.com
  (auto-resolve)
- Tanpa registrasi, tanpa batasan unduhan
- Riwayat 5 unduhan terakhir tersimpan di browser (localStorage)
- Download aplikasi Android (APK) langsung dari halaman utama
- MONETISASI: slot iklan siap pakai (AdSense / Adsterra / Monetag /
  PropellerAds / PopCash) + donasi (PayPal / DANA / ShopeePay / Saweria /
  Ko-fi) + Google Analytics 4 — semua diatur di config/monetization.php
- SEO: JSON-LD structured data (WebApplication + FAQPage) untuk rich
  results, canonical URL, OG/Twitter meta, dan 3 artikel panduan di /artikel/

CATATAN PENTING
1. PEMBARUAN OTOMATIS APP/SITUS: saat website diupdate, pengunjung
   (termasuk app Android yang sudah terpasang & PWA) melihat notifikasi
   "Pembaruan tersedia" lalu halaman memuat versi terbaru otomatis
   (dicek tiap 1 menit via version.php). Tidak perlu install ulang APK.
2. Versi PHP minimal 7.4 (disarankan 8.1 / 8.2).
   Cek/ubah di cPanel: MultiPHP Manager atau Select PHP Version.
3. Ekstensi PHP yang dipakai: curl dan json (aktif default di Rumahweb).
4. SSL: aktifkan SSL gratis (Let's Encrypt) via cPanel -> SSL/TLS Status.
   Setelah SSL aktif, buka file .htaccess lalu aktifkan (uncomment)
   bagian "Paksa HTTPS".
5. Provider API gratis memiliki batas wajar (rate limit). Jika sedang
   gangguan, sistem otomatis pindah ke provider berikutnya.
6. File .htaccess WAJIB ikut ter-upload. Di cPanel File Manager,
   aktifkan "Show Hidden Files" agar file berawalan titik terlihat.
7. Jangan hapus file googleff3b12f5655f595a.html — dipakai verifikasi
   Google Search Console.
8. THUMBNAIL SHARE (Google/WhatsApp/Telegram): file assets/img/og-thumbnail.jpg
   (sudah terpasang di meta og:image & twitter:image, ukuran 1200x630).
   Untuk mengganti thumbnail: upload file baru dengan NAMA YANG SAMA,
   lalu minta re-index di Google Search Console (URL Inspection ->
   Request Indexing). Google menyimpan cache thumbnail, jadi proses
   perubahannya bisa beberapa hari.
9. CREDIT: footer sudah bertuliskan "Dibuat oleh Fandi" dengan kontak
   WA 087711180777, TikTok @_fandi96, email afandiae01@gmail.com.
10. PWA (INSTALL APLIKASI TANPA BUILD): site sudah support "Install App".
   Di Android Chrome: buka site -> menu (titik 3) -> "Install app" / "Add to
   Home Screen". Hasilnya sudah seperti aplikasi (ikon di launcher, fullscreen).
11. VERSI APK: project Android Studio lengkap ada di folder terpisah
    "android-app" (zip: voidsyntax-downloader-android-app.zip). Buka di
    Android Studio -> Build -> Build APK. Lihat android-app/README.md.
    Alternatif tanpa coding: https://www.pwabuilder.com -> masukkan URL site
    -> "Package for stores" -> Android -> download APK.
12. DOWNLOAD APK UNTUK PENGUNJUNG: file APK tersimpan di folder files/ dan
    otomatis tampil sebagai tombol "Download Aplikasi Android" di halaman
    utama + link di footer. Pengunjung tinggal klik -> APK terunduh ->
    install di HP (Android 8.0+). Kalau mau ganti versi APK, upload file
    baru ke folder files/ dengan nama yang sama.
    CATATAN: APK hanya untuk ANDROID. Untuk iOS (iPhone/iPad), halaman utama
    sudah menampilkan petunjuk "Add to Home Screen" via Safari (PWA).
13. MONETISASI: isi kode iklan / link donasi / ID GA4 di config/monetization.php.
    Slot iklan: top_banner (atas), below_result (bawah hasil download),
    bottom_banner (bawah, semua halaman), popunder (HATI-HATI, mengganggu UX).
    Donasi terpasang: PayPal (paypal.me/afandiae01@gmail.com),
    DANA (087711180777), ShopeePay (087711180777) — tampil dengan tombol
    salin nomor di bagian "Dukung Kami" halaman utama.
    PERHATIAN: Google AdSense sering MENOLAK site downloader (kebijakan hak
    cipta) — mulai dari ad network alternatif (Adsterra/Monetag/PropellerAds).
    TIP SAWERIA (saweria.co — gratis, info terverifikasi 2026): 1 link + QR
    otomatis bisa terima DANA, ShopeePay, GoPay, OVO, LinkAja, QRIS (semua
    bank), dan bank transfer. Daftar: saweria.co/register (email aktif,
    verifikasi email, usia 17+). Username = link kamu (saweria.co/username).
    Pasang di web: isi 'saweria' + 'saweria_qr' di config/monetization.php.
    Biaya: 5-6% per donasi (min. Rp150) + gateway 0,8-2% + cashout Rp5.000.
    Cairkan: dashboard -> "Dukungan Masuk dan Cashout" -> Cairkan (min
    Rp50.000, jam kerja Sen-Jum 08.00-20.00 WIB). Verifikasi KTP untuk cair.
    Detail lengkap: saweria.co/faq dan saweria.co/tutorial.
    VERIFIKASI MONETAG: setelah "Add site", Monetag menampilkan 3 opsi verifikasi:
    (1) download sw.js -> upload ke root (public_html), atau
    (2) copy meta tag verifikasi -> tempel ke 'head_tags' di config/monetization.php
    (tag otomatis tayang di <head> semua halaman), atau (3) plugin WordPress.
    Lalu klik tombol "Verify" di dashboard Monetag (verifikasi beberapa menit).
    Setelah verified: klik site -> "Add zone" -> pilih "Onclick (Popunder)"
    (atau Vignette Banner) -> isi nama zone -> "Get tag" -> copy kode zone ->
    tempel ke slot iklan yang sesuai ('popunder' / 'top_banner' / 'bottom_banner').
    HINDARI MultiTag & Push Notification (butuh sw.js terdaftar -> konflik
    dengan service worker PWA — lihat PANDUAN-MONETISASI-LENGKAP.md).
    Tag JS global lain (bukan meta): tempel ke 'site_tags' (tayang sebelum </body>).
14. ARTIKEL SEO: 3 artikel panduan sudah tersedia di /artikel/ untuk traffic
    organik dari Google. Kalau menambah artikel baru, tambahkan juga URL-nya
    ke sitemap.xml dan daftarkan ke Google Search Console (request indexing).
15. TRAFFIC: submit sitemap.xml di Google Search Console & Bing Webmaster
    Tools; aktifkan GA4 (config/monetization.php) untuk pantau pengunjung;
    bagikan link di media sosial (TikTok @_fandi96, IG, X) & komunitas
    (grup WA, Telegram, Reddit, Quora); publish APK ke Google Play Store
    untuk exposure terbesar.
16. MENAMBAH BAHASA BARU (mudah, ±5 menit):
    a. Salin lang/en.php menjadi lang/xx.php (xx = kode bahasa 2 huruf,
       mis. 'ar' Arab, 'zh' Mandarin, 'es' Spanyol).
    b. Terjemahkan nilai di sebelah kanan ('=>'), JANGAN ubah kunci
       di sebelah kiri dan jangan hapus placeholder seperti :year.
    c. Daftarkan di includes/i18n.php, array $VS_LANG_META, contoh:
       'ar' => ['name' => 'العربية', 'flag' => '🇸🇦'],
    d. Selesai — menu 🌐 otomatis menampilkan bahasa baru, URL /ar aktif,
       dan tag hreflang SEO ikut bertambah.
17. PROVIDER ANTI-DOWN & TIKHUB: daftar provider ada di config.php
    ($PROVIDERS untuk TikTok, $DOUYIN_PROVIDERS untuk Douyin). Rantai saat
    ini punya 6 kaki TikTok + 4 kaki Douyin — jika satu provider down,
    kena rate-limit, atau ganti format, sistem otomatis pindah ke kaki
    berikutnya (retry 2x dengan jeda 1,2 detik, total dibatasi 50 detik).
    Untuk hasil paling stabil: daftar TikHub.io (ada paket gratis), salin
    kunci API-nya lalu isi SATU baris di config.php:
        define('TIKHUB_API_KEY', 'Bkxxxxxxxx');
    Provider TikHub otomatis aktif di kedua rantai — tanpa ubah kode lain.
    CATATAN HUKUM: fitur Douyin/TikTok untuk keperluan pribadi wajar;
    hormati hak cipta kreator & ketentuan platform.
