<?php
/**
 * api/index.php — API ENDPOINT (JSON)
 * Pemakaian: /api/?url=<link tiktok/douyin> [&lang=id|en|ms]
 * Contoh   : /api/?url=https://www.tiktok.com/@user/video/1234567890
 *            /api/?url=https://v.douyin.com/xxxxxxx/
 *
 * Respons sukses : JSON metadata video (judul, author, link HD/WM/MP3, platform, dll)
 * Respons gagal  : {"error": "..."} dengan HTTP 4xx/5xx.
 */

require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('X-Content-Type-Options: nosniff');

if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

$url = isset($_GET['url']) ? extract_url(trim((string)$_GET['url'])) : '';

if ($url === '') {
    http_response_code(400);
    echo json_encode([
        'error'  => t('api.err_required'),
        t('api.example') => SITE_URL . '/api/?url=https://www.tiktok.com/@user/video/1234567890',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$result = fetch_video($url);

if (isset($result['error'])) {
    http_response_code(422);
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
