<?php
/**
 * app.php — Halaman Download APK Android (tema Cosmic Aurora)
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle     = t('page.app.title');
$pageDesc      = t('page.app.desc');
$canonicalPath = '/app.php';
$noFaqSchema   = true;

require_once __DIR__ . '/includes/header.php';
?>
<div class="page-head">
    <h1 class="grad-text"><?= te('app.title') ?></h1>
    <p><?= t('page.app.desc') ?></p>
</div>

<section class="prose-section" style="margin-top:32px">
    <div class="space">
        <p><?= t('app.desc') ?></p>
        <p class="center" style="margin:24px 0">
            <a class="btn-green" href="<?= SITE_URL ?>/files/voidsyntax-downloader-v1.0.0.apk" download>
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                <span><?= te('app.download_apk') ?></span>
                <span class="badge-xs">Android</span>
            </a>
        </p>
        <h3><?= te('app.install_h') ?></h3>
        <p><?= te('app.install_note') ?></p>
        <h3><?= te('app.auto_h') ?></h3>
        <p><?= te('app.auto_note') ?></p>
        <h3><?= te('app.ios_h') ?></h3>
        <p><?= t('app.ios_note') ?></p>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
