<?php
/**
 * ARTIKEL SEO 1 — Cara Download Video TikTok Tanpa Watermark (multi-bahasa)
 * Isi artikel diambil dari folder /lang (kunci article.a1.body).
 */
require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

$pageTitle     = t('article.a1.title') . ' — ' . SITE_NAME;
$pageDesc      = t('article.a1.desc');
$canonicalPath = '/artikel/cara-download-video-tiktok-tanpa-watermark.php';

$bodyVars = [
    'meta_line' => t('article.meta_line'),
    'cta_free'  => t('article.cta_free'),
    'open_tool' => t('article.open_tool'),
    'apk_url'   => SITE_URL . '/files/voidsyntax-downloader-v1.0.0.apk',
    'home_url'  => lang_url('/'),
];

require_once dirname(__DIR__) . '/includes/header.php';
?>
<article class="section">
    <div class="container container-narrow article">
        <?= t('article.a1.body', $bodyVars) ?>
    </div>
</article>
<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
