<?php
/**
 * artikel/index.php — DAFTAR ARTIKEL (SEO, multi-bahasa)
 */
require_once dirname(__DIR__) . '/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

$pageTitle     = t('artikel.index.title') . ' — ' . SITE_NAME;
$pageDesc      = t('artikel.index.desc');
$canonicalPath = '/artikel/';

require_once dirname(__DIR__) . '/includes/header.php';
?>
<section class="section">
    <div class="container">
        <h1 style="text-align:center;font-size:1.6rem;margin-bottom:24px;"><?= t('artikel.index.heading') ?></h1>
        <div class="article-list">
            <div class="card">
                <h3><a href="<?= e(lang_url('/artikel/cara-download-video-tiktok-tanpa-watermark.php')) ?>"><?= te('article.a1.list_title') ?></a></h3>
                <p><?= te('article.a1.list_desc') ?></p>
            </div>
            <div class="card">
                <h3><a href="<?= e(lang_url('/artikel/cara-download-audio-tiktok-mp3.php')) ?>"><?= te('article.a2.list_title') ?></a></h3>
                <p><?= te('article.a2.list_desc') ?></p>
            </div>
            <div class="card">
                <h3><a href="<?= e(lang_url('/artikel/cara-download-tiktok-tanpa-aplikasi.php')) ?>"><?= te('article.a3.list_title') ?></a></h3>
                <p><?= te('article.a3.list_desc') ?></p>
            </div>
        </div>
    </div>
</section>
<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
