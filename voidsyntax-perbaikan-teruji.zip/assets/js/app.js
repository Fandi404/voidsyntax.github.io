/* ===== VoidSyntax Downloader — app.js v3 (tema Cosmic, interaktif) ===== */
(function () {
  'use strict';

  /* ---------- Kamus teks multi-bahasa (diisi footer.php) ---------- */
  var T = window.VS_I18N || {};
  function t(key, fallback) {
    return T[key] || fallback;
  }

  /* ---------- Notifikasi kecil (toast) ---------- */
  function showToast(msg, ms) {
    var el = document.createElement('div');
    el.className = 'vs-toast';
    el.setAttribute('role', 'status');
    el.textContent = msg;
    document.body.appendChild(el);
    requestAnimationFrame(function () { el.classList.add('show'); });
    setTimeout(function () {
      el.classList.remove('show');
      setTimeout(function () { el.remove(); }, 400);
    }, ms || 3000);
    return el;
  }
  window.vsToast = showToast;

  /* ---------- Tombol salin nomor dompet (donasi) ---------- */
  function bindWalletCopy() {
    document.querySelectorAll('.wallet-copy').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var text = btn.getAttribute('data-copy');
        function done() {
          btn.textContent = t('copied', '✅ Copied');
          setTimeout(function () { btn.textContent = t('copy', '📋 Copy'); }, 1500);
        }
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(done, done);
        } else {
          var ta = document.createElement('textarea');
          ta.value = text; document.body.appendChild(ta);
          ta.select(); try { document.execCommand('copy'); } catch (e) {}
          document.body.removeChild(ta); done();
        }
      });
    });
  }
  bindWalletCopy();

  /* ---------- Toggle tema terang/gelap ---------- */
  var root = document.documentElement;
  document.querySelectorAll('[data-theme]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var dark = root.classList.toggle('dark');
      try { localStorage.setItem('vs_theme', dark ? 'dark' : 'light'); } catch (e) {}
    });
  });

  /* ---------- Dropdown nav ---------- */
  document.querySelectorAll('[data-dropdown]').forEach(function (dd) {
    var btn = dd.querySelector('button');
    if (!btn) { return; }
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      var wasOpen = dd.classList.contains('open');
      document.querySelectorAll('[data-dropdown]').forEach(function (o) { o.classList.remove('open'); });
      if (!wasOpen) { dd.classList.add('open'); }
    });
  });

  /* ---------- Menu bahasa ---------- */
  document.querySelectorAll('[data-langwrap]').forEach(function (wrap) {
    var btn = wrap.querySelector('[data-langbtn]');
    if (!btn) { return; }
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      var wasOpen = wrap.classList.contains('open');
      document.querySelectorAll('[data-langwrap]').forEach(function (o) { o.classList.remove('open'); });
      if (!wasOpen) { wrap.classList.add('open'); }
    });
  });

  /* ---------- Menu mobile (burger) ---------- */
  var burger = document.querySelector('[data-burger]');
  var mobileMenu = document.querySelector('[data-mobilemenu]');
  if (burger && mobileMenu) {
    burger.addEventListener('click', function () {
      mobileMenu.classList.toggle('open');
    });
  }

  /* Tutup semua menu saat klik di luar */
  document.addEventListener('click', function () {
    document.querySelectorAll('[data-dropdown],[data-langwrap]').forEach(function (o) { o.classList.remove('open'); });
  });

  /* ---------- Animasi placeholder berputar di kotak link ---------- */
  var input = document.getElementById('tiktok-url');
  if (input && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var samples = (input.getAttribute('placeholder') || '').split('|').map(function (s) { return s.trim(); }).filter(Boolean);
    if (samples.length > 1) {
      var si = 0, ci = 0, del = false;
      input.setAttribute('placeholder', samples[0]);
      setInterval(function () {
        if (document.activeElement === input || input.value) { return; }
        var full = samples[si];
        ci += del ? -1 : 1;
        input.setAttribute('placeholder', full.slice(0, ci) + '▌');
        if (!del && ci >= full.length) { del = true; setTimeout(function () {}, 600); }
        else if (del && ci <= 0) { del = false; si = (si + 1) % samples.length; }
      }, 55);
    }
  }

  /* ---------- Animasi masuk saat scroll + hitungan statistik ---------- */
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add('in');
          if (en.target.hasAttribute('data-count')) {
            var target = parseInt(en.target.getAttribute('data-count'), 10) || 0;
            var suffix = en.target.getAttribute('data-suffix') || '';
            var start = null;
            function step(ts) {
              if (!start) { start = ts; }
              var p = Math.min((ts - start) / 900, 1);
              en.target.textContent = Math.round(target * (1 - Math.pow(1 - p, 3))) + suffix;
              if (p < 1) { requestAnimationFrame(step); }
            }
            requestAnimationFrame(step);
            en.target.removeAttribute('data-count');
          }
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });
    document.querySelectorAll('[data-count]').forEach(function (el) { io.observe(el); });
  } else {
    document.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('in'); });
  }

  /* ---------- Bilah progres scroll di atas halaman ---------- */
  var progress = document.createElement('div');
  progress.className = 'vs-progress';
  document.body.appendChild(progress);
  window.addEventListener('scroll', function () {
    var h = document.documentElement.scrollHeight - window.innerHeight;
    progress.style.width = (h > 0 ? (window.scrollY / h) * 100 : 0) + '%';
  }, { passive: true });

  /* ---------- Form download ---------- */
  var form     = document.getElementById('dl-form');
  var btn      = document.getElementById('dl-btn');
  var statusEl = document.getElementById('status');
  var resultEl = document.getElementById('result');
  var pasteBtn = document.getElementById('paste-btn');

  if (!form) { return; }

  /* ---------- Tombol Tempel (clipboard) — fallback berlapis ----------
   * 1) Clipboard API modern; 2) execCommand('paste') lama;
   * 3) kalau keduanya diblokir browser/WebView: fokus kotak + petunjuk toast. */
  function pasteFallback() {
    var ta = document.createElement('textarea');
    ta.style.position = 'fixed'; ta.style.top = '-100px'; ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus();
    var val = '';
    try { if (document.execCommand('paste')) { val = ta.value || ''; } } catch (e) {}
    document.body.removeChild(ta);
    if (val.trim()) {
      input.value = val.trim();
      input.focus();
      return;
    }
    input.focus();
    showToast(t('paste_hint', 'Press Ctrl+V or long-press the box to paste.'), 3200);
  }
  if (pasteBtn && input) {
    pasteBtn.addEventListener('click', function () {
      if (navigator.clipboard && navigator.clipboard.readText) {
        navigator.clipboard.readText().then(function (text) {
          if (text && text.trim()) {
            input.value = text.trim();
            input.focus();
          } else {
            pasteFallback();
          }
        }).catch(pasteFallback);
      } else {
        pasteFallback();
      }
    });
  }

  /* ---------- Ekstrak URL dari teks share utuh ---------- */
  function extractUrl(text) {
    var m = String(text || '').match(/https?:\/\/[^\s"'<>]+/i);
    if (m) {
      return m[0].replace(/[.,;:!?\)\]\}]+$/, '');
    }
    return String(text || '').trim();
  }

  /* ---------- Deteksi platform dari URL ---------- */
  function detectPlatform(url) {
    if (/^https?:\/\/([a-z0-9-]+\.)*(douyin\.com|iesdouyin\.com|douyin\.net)(\/|$|\?)/i.test(url)) {
      return 'douyin';
    }
    if (/^https?:\/\/([a-z0-9-]+\.)*tiktok\.com(\/|$|\?)/i.test(url)) {
      return 'tiktok';
    }
    return null;
  }

  /* ---------- Submit form ---------- */
  form.addEventListener('submit', function (e) {
    e.preventDefault();

    var raw = (input.value || '').trim();
    var url = extractUrl(raw);
    if (!url) { return; }
    input.value = url;

    var platform = detectPlatform(url);
    if (!platform) {
      statusEl.textContent = '❌ ' + t('invalid_url', 'Invalid URL. Paste a TikTok or Douyin video link.');
      statusEl.className = 'status error';
      return;
    }

    btn.disabled = true;
    form.classList.add('disabled');
    btn.textContent = t('processing', 'Processing...');
    statusEl.textContent = t('fetching', 'Fetching video data...');
    statusEl.className = 'status';
    resultEl.hidden = true;

    fetch('/api/?url=' + encodeURIComponent(url), { headers: { 'Accept': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data && data.error) {
          statusEl.textContent = '❌ ' + data.error;
          statusEl.className = 'status error';
          return;
        }
        renderResult(data, url);
        statusEl.textContent = '';
        saveHistory(data, url);
      })
      .catch(function () {
        statusEl.textContent = '❌ ' + t('network_error', 'A network error occurred.');
        statusEl.className = 'status error';
      })
      .finally(function () {
        btn.disabled = false;
        form.classList.remove('disabled');
        btn.textContent = t('submit', 'Download Video');
      });
  });

  /* ---------- Render hasil unduhan ---------- */
  function renderResult(d, sourceUrl) {
    var q = encodeURIComponent(sourceUrl);
    var platform = d.platform || detectPlatform(sourceUrl) || 'tiktok';
    var platformLabel = platform === 'douyin'
      ? t('platform_douyin', 'Douyin')
      : t('platform_tiktok', 'TikTok');
    var isImages = (d.type === 'images') && d.images && d.images.length;

    var html = '<div class="result-card">';
    if (d.cover) {
      html += '<img class="thumb" src="' + esc(d.cover) + '" alt="Thumbnail" loading="lazy">';
    }

    html += '<div class="meta">';
    html += '<p class="title">' + esc(d.title || t('no_title', '(Untitled)')) + '</p>';
    html += '<p class="author">@' + esc(d.author || 'unknown');
    if (d.duration) { html += ' • ' + d.duration + ' ' + t('seconds', 'sec'); }
    html += ' • ' + t('via', 'via') + ' ' + esc(d.provider || '-') + '</p>';

    html += '<div class="result-btns">';

    if (isImages) {
      /* Post foto/slideshow: ZIP + MP3 */
      html += '<a class="green" href="/download.php?url=' + q + '&type=zip">' + t('btn_zip', '🗂️ Download All Photos (ZIP)') + '</a>';
      if (d.music) {
        html += '<a class="primary" href="/download.php?url=' + q + '&type=mp3">' + t('btn_mp3', '🎵 Download MP3 Audio Only') + '</a>';
      }
    } else {
      /* Video: HD (utama), SD, watermark, MP3 */
      html += '<a class="primary" href="/download.php?url=' + q + '&type=hd">' + t('btn_hd', '⬇️ Download Full HD (1080p/4K)') + '</a>';
      if (d.sd && d.sd !== d.hd) {
        html += '<a href="/download.php?url=' + q + '&type=sd">' + t('btn_sd', '⬇️ Download MP4 (No Watermark)') + '</a>';
      }
      if (d.wm && d.wm !== d.hd) {
        html += '<a href="/download.php?url=' + q + '&type=wm">' + t('btn_wm', '💧 Download With Watermark') + '</a>';
      }
      if (d.music) {
        html += '<a class="green" href="/download.php?url=' + q + '&type=mp3">' + t('btn_mp3', '🎵 Download MP3 Audio Only') + '</a>';
      }
    }
    html += '</div>';

    if (d.webpage_url) {
      html += '<p class="src">' + t('source', 'Source') + ': <a href="' + esc(d.webpage_url) + '" target="_blank" rel="noopener">' + esc(d.webpage_url) + '</a></p>';
    }
    html += '</div></div>';

    resultEl.innerHTML = html;
    resultEl.hidden = false;

    var badge = document.createElement('span');
    badge.className = 'platform-badge platform-' + platform;
    badge.textContent = platformLabel;
    var card = resultEl.querySelector('.result-card');
    if (card) { card.appendChild(badge); }
  }

  /* ---------- Riwayat (localStorage) ---------- */
  function saveHistory(d, url) {
    try {
      var key = 'voidsyntax_history';
      var list = JSON.parse(localStorage.getItem(key) || '[]');
      list.unshift({ title: d.title || url, author: d.author || '', url: url, time: Date.now() });
      list = list.slice(0, 5);
      localStorage.setItem(key, JSON.stringify(list));
    } catch (e) { /* abaikan */ }
  }

  /* ---------- Escape HTML ---------- */
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
})();

/* ===== Pembaruan versi: NOTIFIKASI + auto-update =====
 * Dipakai di browser, PWA, dan APK (WebView) — kalau website diupdate,
 * pengunjung/app yang sudah terpasang melihat notifikasi lalu dimuat ulang. */
(function () {
  var lastVersion = null;
  var checking = false;
  var notified = false;

  function notifyUpdate(thenReload) {
    if (notified) { return; }
    notified = true;
    var msg = (window.VS_I18N && window.VS_I18N.update_available) || '✨ Update available! Loading the new version…';
    if (window.vsToast) {
      window.vsToast(msg, 2600);
    } else {
      alert(msg);
    }
    if (thenReload) {
      setTimeout(function () { location.reload(); }, 2800);
    }
  }

  function checkVersion() {
    if (checking) { return; }
    checking = true;
    fetch('/version.php?_=' + Date.now(), { cache: 'no-store' })
      .then(function (r) { return r.text(); })
      .then(function (v) {
        v = (v || '').trim();
        if (!v) { return; }
        if (lastVersion === null) {
          lastVersion = v;
          /* Bandingkan dengan yang terakhir dilihat pengguna/app */
          try {
            var seen = localStorage.getItem('vs_seen_version');
            localStorage.setItem('vs_seen_version', v);
            if (seen && seen !== v) { notifyUpdate(false); }
          } catch (e) {}
          return;
        }
        if (v !== lastVersion) {
          /* Website baru saja diupdate → notifikasi lalu muat ulang */
          notifyUpdate(true);
        }
      })
      .catch(function () {})
      .then(function () { checking = false; });
  }
  setTimeout(checkVersion, 4000);
  setInterval(checkVersion, 60000);
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) { checkVersion(); }
  });

  /* PWA: kalau service worker baru tersedia → notifikasi pembaruan.
     (updatefound adalah event milik ServiceWorkerRegistration, bukan navigator.serviceWorker) */
  if ('serviceWorker' in navigator && navigator.serviceWorker && navigator.serviceWorker.getRegistration) {
    try {
      navigator.serviceWorker.getRegistration().then(function (reg) {
        if (reg && reg.addEventListener) {
          reg.addEventListener('updatefound', function () {
            var sw = navigator.serviceWorker.controller;
            if (sw) { notifyUpdate(true); }
          });
        }
      }).catch(function () {});
    } catch (e) { /* abaikan — cukup polling version.php */ }
  }
})();
