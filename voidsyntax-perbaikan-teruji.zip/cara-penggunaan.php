<?php
/**
 * cara-penggunaan.php — Panduan penggunaan (tema Cosmic Aurora)
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle     = t('page.howto.title');
$pageDesc      = t('page.howto.desc');
$canonicalPath = '/cara-penggunaan.php';
$noFaqSchema   = true;

require_once __DIR__ . '/includes/header.php';
?>
<div class="page-head">
    <h1 class="grad-text"><?= t('howto.heading') ?></h1>
    <p><?= t('page.howto.desc') ?></p>
</div>

<section class="section" style="margin-top:32px">
    <div class="steps-grid">
        <?php for ($i = 1; $i <= 4; $i++): ?>
        <div class="step">
            <div class="step-num"><?= $i ?></div>
            <h3><?= te('howto.' . $i . '.title') ?></h3>
            <p><?= te('howto.' . $i . '.desc') ?></p>
        </div>
        <?php endfor; ?>
    </div>
    <div class="tips-box">
        <h3><?= te('tips.title') ?></h3>
        <ul>
            <?php for ($i = 1; $i <= 5; $i++): ?>
            <li><?= te('tips.' . $i) ?></li>
            <?php endfor; ?>
        </ul>
    </div>
</section>

<section class="prose-section" style="margin-top:48px">
    <h2 class="h2-grad" style="margin-bottom:20px"><?= t('seo.heading') ?></h2>
    <div class="space">
        <p><?= t('seo.intro') ?></p>
        <?= t('seo.why') ?>
        <?= t('seo.cta') ?>
    </div>
</section>

<div class="center" style="margin:40px 0">
    <a class="btn-grad" style="display:inline-flex" href="<?= e(lang_url('/#unduh')) ?>"><?= t('form.button') ?></a>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
