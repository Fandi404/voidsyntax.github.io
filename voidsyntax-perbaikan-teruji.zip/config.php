<?php
/**
 * ============================================================
 *  config.php — KONFIGURASI UTAMA
 *  Project : TikTok + Douyin Downloader (Tanpa Watermark) — GRATIS
 *  Domain  : https://voidsyntax.my.id
 *  Hosting : Rumahweb (Shared Hosting, cPanel, Apache + PHP)
 * ============================================================
 */

if (!defined('APP_NAME')) {

    /* ---------- Identitas Situs ---------- */
    define('APP_NAME',     'VoidSyntax TikTok Downloader');
    define('APP_VERSION',  '1.3.2');
    define('SITE_URL',     'https://voidsyntax.my.id'); // ganti jika domain berubah
    define('SITE_NAME',    'VoidSyntax Downloader');
    define('SITE_DESC',    'Download video TikTok & Douyin tanpa watermark (HD), dengan watermark, dan audio MP3. Gratis, tanpa registrasi, tanpa batasan.');
    define('SITE_KEYWORDS', 'download tiktok, tiktok downloader, tiktok tanpa watermark, download video tiktok, tiktok mp3, download douyin, douyin tanpa watermark, voidsyntax');

    /* ---------- Pengaturan HTTP / cURL ---------- */
    define('HTTP_TIMEOUT',       25); // detik — timeout request umum
    define('HTTP_MAX_REDIRECTS', 5);
    define('HTTP_USER_AGENT',    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36');

    /* ---------- ANTI-DOWN: pengaturan provider ----------
     * PROVIDER_TIMEOUT  : timeout per provider (detik) — pendek supaya cepat
     *                     pindah ke provider berikutnya saat satu provider down.
     * PROVIDER_RETRIES  : jumlah percobaan per provider sebelum pindah.
     * PROVIDER_BUDGET   : total waktu maksimum memproses 1 link (detik).
     * CACHE_TTL         : hasil sukses di-cache (detik) — link sama tidak
     *                     dihitung 2x, kuota provider hemat, anti rate-limit.
     * CACHE_FAIL_TTL    : hasil gagal di-cache singkat supaya tidak
     *                     memborbardir provider saat link memang tidak valid.
     */
    define('PROVIDER_TIMEOUT', 12);
    define('PROVIDER_RETRIES', 2);
    define('PROVIDER_BUDGET',  50);
    define('CACHE_TTL',        900);
    define('CACHE_FAIL_TTL',   45);
    // Kunci API TikHub (https://tikhub.io) — OPSIONAL. Isi kunci di sini
    // ("Bkxxxx") dan provider TikHub otomatis aktif untuk TikTok & Douyin.
    define('TIKHUB_API_KEY', '');

    /* ---------- PROVIDER API TIKTOK (AUTO PROVIDER / fallback otomatis) ----------
     * ANTI-DOWN: semakin banyak provider, semakin kecil kemungkinan situs
     * tidak bisa dipakai. Jika provider pertama gagal/timeout/rate-limit,
     * sistem OTOMATIS pindah ke berikutnya (dengan retry) sampai berhasil.
     * Untuk menambah provider, tambahkan item di array ini
     * (lihat includes/functions.php untuk parser-nya).
     */
    $PROVIDERS = [
        [
            'id'      => 'tikwm',
            'name'    => 'TikWM',
            'api_url' => 'https://www.tikwm.com/api/?url=',
            'parser'  => 'parse_tikwm',
        ],
        [
            'id'      => 'tikwm_mirror',
            'name'    => 'TikWM Mirror',
            'api_url' => 'https://tikwm.com/api/?url=',
            'parser'  => 'parse_tikwm',
        ],
        [
            'id'      => 'tiklydown',
            'name'    => 'TiklyDown',
            'api_url' => 'https://api.tiklydown.eu.org/api/download?url=',
            'parser'  => 'parse_tiklydown',
        ],
        [
            // Hybrid API — juga bisa memproses link TikTok
            'id'      => 'douyin_wtf_tiktok',
            'name'    => 'Douyin.wtf Hybrid',
            'api_url' => 'https://api.douyin.wtf/api/hybrid/video_data?url=',
            'parser'  => 'parse_douyin_wtf',
        ],
        [
            // Parser lokal: scrape halaman video TikTok sendiri (tanpa API
            // pihak ketiga) — penyelamat terakhir kalau semua API down
            'id'      => 'tiktok_direct',
            'name'    => 'TikTok Direct',
            'parser'  => 'parse_tiktok_direct',
        ],
        [
            // TikHub API — otomatis aktif hanya jika TIKHUB_API_KEY diisi
            'id'      => 'tikhub',
            'name'    => 'TikHub API',
            'parser'  => 'parse_tikhub',
        ],
    ];

    /* ---------- PROVIDER API DOUYIN (AUTO PROVIDER untuk link Douyin/抖音) ----------
     * Dipakai otomatis kalau link yang ditempel adalah link Douyin.
     * Urutan = prioritas, sama seperti provider TikTok di atas.
     *
     * Jenis provider:
     *   - Punya 'api_url'  -> GET api_url + urlencode(link), hasil JSON di-parse 'parser'
     *   - Tanpa 'api_url'  -> 'parser' dipanggil langsung dengan link asli
     *     (dipakai untuk parser yang men-scrape halaman share Douyin sendiri)
     *
     * Contoh menambah provider ber-API-key (mis. TikHub.io):
     *   [
     *       'id'      => 'tikhub',
     *       'name'    => 'TikHub',
     *       'api_url' => 'https://api.tikhub.io/api/v1/douyin/web/fetch_one_video?aweme_id=',
     *       'headers' => ['Authorization: Bearer KUNCI_API_ANDA'],
     *       'parser'  => 'parse_douyin_wtf', // atau parser khusus
     *   ],
     */
    $DOUYIN_PROVIDERS = [
        [
            'id'      => 'douyin_wtf',
            'name'    => 'Douyin.wtf API',
            'api_url' => 'https://api.douyin.wtf/api/hybrid/video_data?url=',
            'parser'  => 'parse_douyin_wtf',
        ],
        [
            // Scraper DLPanda — berguna saat Douyin memblokir IP server
            'id'      => 'dlpanda_douyin',
            'name'    => 'DLPanda',
            'parser'  => 'parse_dlpanda_douyin',
        ],
        [
            // Parser lokal: scrape halaman share Douyin sendiri (dengan cookie ttwid)
            'id'      => 'douyin_direct',
            'name'    => 'Douyin Direct',
            'parser'  => 'parse_douyin_direct',
        ],
        [
            // TikHub API — otomatis aktif hanya jika TIKHUB_API_KEY diisi di atas
            'id'      => 'tikhub',
            'name'    => 'TikHub API',
            'parser'  => 'parse_tikhub',
        ],
    ];

    /* ---------- Batas ---------- */
    define('MAX_DOWNLOAD_SIZE', 0); // byte; 0 = tanpa batas

    /* ---------- Multi-bahasa: muat mesin i18n + tentukan bahasa aktif ---------- */
    require_once __DIR__ . '/includes/i18n.php';
    define('SITE_LANG', vs_current_lang()); // 'id', 'en', 'ms', ... (lihat folder /lang)

    /* ---------- Muat konten tampilan (teks fitur, langkah, FAQ) ---------- */
    require_once __DIR__ . '/config/site.php';

    /* ---------- Muat pengaturan monetisasi (iklan, donasi, GA4) ---------- */
    require_once __DIR__ . '/config/monetization.php';
}
