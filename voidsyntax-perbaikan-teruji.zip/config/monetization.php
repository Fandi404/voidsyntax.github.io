<?php
/**
 * config/monetization.php — PENGATURAN MONETISASI
 * Semua pengaturan iklan, donasi, dan analytics ada di file ini.
 * Cukup isi/nonaktifkan di sini — tidak perlu edit file lain.
 */

if (!defined('SITE_URL')) {
    exit('Akses langsung tidak diizinkan.');
}

$MONETIZATION = [

    /* ---------- Google AdSense ----------
     * PERHATIAN: AdSense sering MENOLAK site downloader (kebijakan hak cipta).
     * Saran: mulai dari ad network alternatif (Adsterra/Monetag/PropellerAds)
     * yang memang menerima niche ini. Aktifkan AdSense hanya kalau akun sudah
     * DISETUJUI.
     */
    'adsense_enabled' => false,
    'adsense_client'  => 'ca-pub-XXXXXXXXXXXXXXXX', // ganti dengan ID Anda (ca-pub-...)

    /* ---------- Slot iklan (ad network alternatif) ----------
     * Tempel kode iklan dari Adsterra / Monetag / PropellerAds / PopCash ke slot
     * yang sesuai. Slot yang kosong = tidak tampil (aman).
     *
     * ATURAN TANDA KUTIP (PENTING — kalau salah, website error 500!):
     * Kode iklan Monetag berisi tanda kutip satu ('). Kalau kode Anda mengandung ',
     * pakai tanda kutip DUA (") di awal dan akhir nilai, contoh:
     *   'popunder' => "<script>...kode dengan ' di dalam...</script>",
     * Jangan mencampur: ' di dalam string '  atau  " di dalam string ".
     */
    'ad_slots' => [
        'top_banner'    => '', // banner atas halaman (728x90 / responsive)
        'below_result'  => '', // di bawah hasil download (halaman utama)
        'bottom_banner' => "<script>(function(s){s.dataset.zone='11983211',s.src='https://n6wxm.com/vignette.min.js'}([document.documentElement,document.body].filter(Boolean).pop().appendChild(document.createElement('script'))))</script>", // vignette Monetag (zone 11983211)
    ],

    /* ---------- Tag global ad network ----------
     * Tag JS dari dashboard Monetag (untuk verifikasi website) ditempel di sini.
     * Tag akan tayang otomatis sebelum </body> di semua halaman.
     */
    'site_tags' => '',

    /* ---------- Tag di <head> (mis. meta tag verifikasi Monetag) ----------
     * Tempel meta tag verifikasi dari Monetag di sini — tayang otomatis di <head>.
     */
    'head_tags' => '<meta name="monetag" content="f5ef24eeef21d63a761aaa3141f89a83">',

    /* ---------- Donasi / dukungan ----------
     * Cukup 2 metode: Saweria (Indonesia — QRIS: DANA/ShopeePay/GoPay/bank dalam
     * satu link) dan PayPal (internasional). DANA & ShopeePay langsung sengaja
     * dikosongkan — isi lagi kalau mau menampilkan metode transfer manual.
     */
    'donation' => [
        'enabled' => true,
        'saweria' => 'https://saweria.co/fandi96', // link halaman donasi Saweria Anda
        'saweria_qr' => '', // contoh: /assets/img/saweria-qr.png (QR code dari dashboard Saweria)
        'ko-fi'   => '', // contoh: https://ko-fi.com/fandi96 (opsional)
        'paypal'  => 'https://paypal.me/afandiae01@gmail.com', // PayPal: afandiae01@gmail.com
        'dana'    => '', // dikosongkan — hanya Saweria & PayPal
        'shopee'  => '', // dikosongkan — hanya Saweria & PayPal
    ],

    /* ---------- Google Analytics 4 (opsional, untuk pantau traffic) ---------- */
    'ga4_id' => '', // contoh: G-XXXXXXXXXX
];
