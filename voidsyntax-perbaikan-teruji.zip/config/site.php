<?php
/**
 * config/site.php — KONTEN TAMPILAN (teks)
 * Semua teks diambil dari sistem multi-bahasa (folder /lang lewat t()).
 * Untuk mengubah teks: edit file di lang/id.php, lang/en.php, lang/ms.php.
 * File ini di-require oleh config.php.
 */

if (!defined('SITE_URL')) {
    exit('Akses langsung tidak diizinkan.');
}

/* 3 kartu fitur (tema Cosmic Aurora) */
$SITE_FEATURES = [
    ['title' => t('feature1.title'), 'desc' => t('feature1.desc')],
    ['title' => t('feature2.title'), 'desc' => t('feature2.desc')],
    ['title' => t('feature3.title'), 'desc' => t('feature3.desc')],
];

/* FAQ (10 pertanyaan) */
$SITE_FAQ = [];
for ($i = 1; $i <= 10; $i++) {
    $SITE_FAQ[] = ['q' => t("faq.$i.q"), 'a' => t("faq.$i.a")];
}

$SITE_FOOTER_TEXT = t('footer.copy', ['year' => date('Y'), 'name' => SITE_NAME]);
