<?php
/**
 * download.php — ENDPOINT UNDUH
 * Stream file video/audio dari CDN TikTok/Douyin ke browser (proxy).
 * Pemakaian: /download.php?url=<link tiktok/douyin>&type=hd|wm|mp3
 *
 * Fitur: nama file rapi, support Range (resume/progress akurat),
 * validasi host media (anti-SSRF), deteksi platform otomatis.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

@set_time_limit(0);
@ini_set('zlib.output_compression', '0');

$url  = isset($_GET['url'])  ? extract_url(trim((string)$_GET['url'])) : '';
$type = isset($_GET['type']) ? strtolower((string)$_GET['type'])     : 'hd';

if ($url === '' || !is_supported_url($url)) {
    http_response_code(400);
    exit(t('dl.err_invalid_url'));
}

$platform = detect_platform($url) ?: 'tiktok';

/* ---------- Ambil data video via AUTO PROVIDER ---------- */
$info = fetch_video($url);
if (!is_array($info) || isset($info['error'])) {
    http_response_code(502);
    exit(t('dl.err_fetch'));
}

$referer  = media_referer(isset($info['platform']) ? $info['platform'] : $platform);

/* ---------- Unduh semua foto (slideshow) sebagai ZIP ---------- */
if ($type === 'zip') {
    $images = (isset($info['images']) && is_array($info['images'])) ? $info['images'] : [];
    if (empty($images)) {
        http_response_code(404);
        exit(t('dl.err_not_available'));
    }
    if (!class_exists('ZipArchive')) {
        http_response_code(500);
        exit(t('dl.err_fetch'));
    }

    $tmp = tempnam(sys_get_temp_dir(), 'vszip');
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) {
        http_response_code(500);
        exit(t('dl.err_fetch'));
    }

    $n = 0;
    foreach ($images as $imgUrl) {
        if (!is_allowed_media_host($imgUrl)) {
            continue;
        }
        $ch = curl_init($imgUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => HTTP_MAX_REDIRECTS,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => HTTP_TIMEOUT,
            CURLOPT_USERAGENT      => HTTP_USER_AGENT,
            CURLOPT_REFERER        => $referer,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $bin = curl_exec($ch);
        curl_close($ch);
        if ($bin !== false && $bin !== '') {
            $n++;
            $extImg = 'jpg';
            $pathPart = parse_url($imgUrl, PHP_URL_PATH);
            if ($pathPart && preg_match('/\.(jpe?g|png|webp|gif)$/i', $pathPart, $m)) {
                $extImg = strtolower($m[1]);
            }
            $zip->addFromString(sprintf('photo_%02d.%s', $n, $extImg), $bin);
        }
    }
    $zip->close();

    if ($n === 0) {
        @unlink($tmp);
        http_response_code(502);
        exit(t('dl.err_fetch'));
    }

    $filename = make_filename($info, 'zip');
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    header('Content-Length: ' . (string)filesize($tmp));
    readfile($tmp);
    @unlink($tmp);
    exit;
}

/* ---------- Pilih file sesuai tipe ---------- */
switch ($type) {
    case 'wm':
        $remote = $info['wm'];
        $mime   = 'video/mp4';
        $ext    = 'mp4';
        break;
    case 'sd':
        $remote = (isset($info['sd']) && $info['sd'] !== '') ? $info['sd'] : $info['hd'];
        $mime   = 'video/mp4';
        $ext    = 'mp4';
        break;
    case 'mp3':
    case 'audio':
        $remote = $info['music'];
        $mime   = 'audio/mpeg';
        $ext    = 'mp3';
        break;
    case 'hd':
    default:
        $remote = $info['hd'];
        $mime   = 'video/mp4';
        $ext    = 'mp4';
        break;
}

if (empty($remote) || !is_allowed_media_host($remote)) {
    http_response_code(404);
    exit(t('dl.err_not_available'));
}

$filename = make_filename($info, $ext);

/* ---------- Probe kecil (GET + Range) ----------
 * CATATAN: CDN TikTok MENOLAK request HEAD (balas 503), jadi probe
 * wajib pakai GET dengan Range. Dari "Content-Range: bytes 0-0/TOTAL"
 * kita dapat ukuran total file untuk Content-Length yang akurat.
 */
$probe = function ($range) use ($remote, $referer) {
    $ch = curl_init($remote);
    $headers = [];
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, // PENTING: body probe jangan sampai ke output
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => HTTP_MAX_REDIRECTS,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => HTTP_TIMEOUT,
        CURLOPT_USERAGENT      => HTTP_USER_AGENT,
        CURLOPT_REFERER        => $referer,
        CURLOPT_SSL_VERIFYPEER => true,
        // CURLOPT_RANGE expects "X-Y" (libcurl sendiri yang menambah "bytes=")
        CURLOPT_RANGE          => preg_replace('/^bytes=/i', '', $range),
        CURLOPT_HEADERFUNCTION => function ($ch, $h) use (&$headers) {
            $headers[] = trim($h);
            return strlen($h);
        },
    ]);
    curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$status, $headers];
};

$parseHeaders = function ($headers) {
    $out = ['length' => 0, 'range' => ''];
    foreach ($headers as $h) {
        $l = strtolower($h);
        if (strpos($l, 'content-length:') === 0) {
            $out['length'] = (int)trim(substr($h, 15));
        }
        if (strpos($l, 'content-range:') === 0) {
            $out['range'] = trim(substr($h, 14));
        }
    }
    return $out;
};

$clientRange = isset($_SERVER['HTTP_RANGE']) ? trim((string)$_SERVER['HTTP_RANGE']) : '';

$rStatus = 0;
$rLength = 0;
$rRange  = '';
$total   = 0;

if ($clientRange !== '') {
    // Probe sesuai range yang diminta client
    list($rStatus, $rHeaders) = $probe($clientRange);
    if ($rStatus === 206) {
        $p = $parseHeaders($rHeaders);
        $rLength = $p['length'];
        $rRange  = $p['range'];
    } else {
        // Remote tidak mendukung range → fallback kirim file penuh
        $clientRange = '';
    }
}

if ($clientRange === '') {
    // Probe 1 byte untuk mengetahui ukuran total file
    list($rStatus, $rHeaders) = $probe('bytes=0-0');
    $p = $parseHeaders($rHeaders);
    if ($rStatus === 206 && $p['range'] !== '') {
        // Content-Range: bytes 0-0/12699632 → ambil angka totalnya
        if (preg_match('#/(\d+)#', $p['range'], $m)) {
            $total = (int)$m[1];
        }
    } elseif ($rStatus === 200) {
        $total = $p['length'];
    }
}

/* ---------- Bersihkan output buffer ---------- */
while (ob_get_level() > 0) {
    @ob_end_clean();
}

/* ---------- Kirim header unduhan ---------- */
header('Content-Type: ' . $mime);
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

if ($clientRange !== '' && $rStatus === 206) {
    // Client minta resume → remote mendukung → teruskan sebagai 206
    http_response_code(206);
    header('Accept-Ranges: bytes');
    if ($rRange !== '') {
        header('Content-Range: ' . $rRange);
    }
    if ($rLength > 0) {
        header('Content-Length: ' . $rLength);
    }
} else {
    header('Accept-Ranges: bytes');
    if ($total > 0) {
        header('Content-Length: ' . $total);
    }
}

/* ---------- Stream file via cURL ---------- */
$reqHeaders = ['Accept: */*'];
if ($clientRange !== '') {
    $reqHeaders[] = 'Range: ' . $clientRange;
}

$ch = curl_init($remote);
curl_setopt_array($ch, [
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS      => HTTP_MAX_REDIRECTS,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT        => 0,
    CURLOPT_USERAGENT      => HTTP_USER_AGENT,
    CURLOPT_REFERER        => $referer,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_HTTPHEADER     => $reqHeaders,
    CURLOPT_WRITEFUNCTION  => function ($ch, $chunk) {
        echo $chunk;
        flush();
        return strlen($chunk);
    },
]);
curl_exec($ch);
$code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err  = curl_error($ch);
curl_close($ch);

if ($err !== '' || $code >= 400) {
    echo "\n[" . t('dl.err_stream') . ': ' . ($err !== '' ? $err : 'HTTP ' . $code) . ']';
}
exit;
