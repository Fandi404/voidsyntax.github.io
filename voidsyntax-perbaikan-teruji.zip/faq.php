<?php
/**
 * faq.php — Halaman FAQ (tema Cosmic Aurora)
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle     = t('page.faq.title');
$pageDesc      = t('page.faq.desc');
$canonicalPath = '/faq.php';
$noFaqSchema   = true;

require_once __DIR__ . '/includes/header.php';
?>
<div class="page-head">
    <h1 class="grad-text"><?= t('faq.heading') ?></h1>
    <p><?= t('page.faq.desc') ?></p>
</div>

<section class="section" style="margin-top:16px">
    <div class="faq-list">
        <?php foreach ($SITE_FAQ as $q): ?>
        <div class="faq-item">
            <details>
                <summary>
                    <h3 style="margin:0;font-size:1.15rem"><?= e($q['q']) ?></h3>
                    <svg class="chev" width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </summary>
                <div class="a" style="margin-top:10px"><?= e($q['a']) ?></div>
            </details>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<div class="center" style="margin:40px 0">
    <a class="btn-grad" style="display:inline-flex" href="<?= e(lang_url('/#unduh')) ?>"><?= t('form.button') ?></a>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
