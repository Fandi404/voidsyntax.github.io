<?php
/**
 * includes/ads.php — SISTEM MONETISASI
 * Fungsi untuk menampilkan slot iklan, donasi (link + QR + dompet), dan popunder.
 * Semua pengaturan ada di config/monetization.php — edit di sana saja.
 */

if (!defined('SITE_URL')) {
    require_once dirname(__DIR__) . '/config.php';
}
require_once __DIR__ . '/functions.php';

/**
 * Tampilkan slot iklan. Tidak tampil kalau kode kosong.
 */
function render_ad_slot($slot)
{
    global $MONETIZATION;
    $code = isset($MONETIZATION['ad_slots'][$slot]) ? trim((string)$MONETIZATION['ad_slots'][$slot]) : '';
    if ($code === '') {
        return;
    }
    echo '<div class="ad-slot ad-' . e($slot) . '">' . "\n" . $code . "\n" . '</div>' . "\n";
}

/**
 * Script popunder (kalau diisi di config). Dipanggil sebelum </body>.
 */
function render_popunder()
{
    global $MONETIZATION;
    $code = isset($MONETIZATION['ad_slots']['popunder']) ? trim((string)$MONETIZATION['ad_slots']['popunder']) : '';
    if ($code !== '') {
        echo $code . "\n";
    }
}

/**
 * Tag global ad network (mis. tag verifikasi dari dashboard Monetag).
 * Ditempel mentah sebelum </body>. Kosong = tidak tampil.
 */
function render_site_tags()
{
    global $MONETIZATION;
    $tags = isset($MONETIZATION['site_tags']) ? trim((string)$MONETIZATION['site_tags']) : '';
    if ($tags !== '') {
        echo $tags . "\n";
    }
}

/**
 * Tag untuk <head> (mis. meta tag verifikasi Monetag).
 * Ditempel mentah di dalam <head>. Kosong = tidak tampil.
 */
function render_head_tags()
{
    global $MONETIZATION;
    $tags = isset($MONETIZATION['head_tags']) ? trim((string)$MONETIZATION['head_tags']) : '';
    if ($tags !== '') {
        echo $tags . "\n";
    }
}

/**
 * Bagian donasi "Dukung Kami".
 * - QR code Saweria (opsional, tampil kalau saweria_qr diisi)
 * - Link: Saweria / Ko-fi / PayPal (tombol langsung ke halaman bayar)
 * - Dompet: DANA / ShopeePay (tampilkan nomor + tombol salin + konfirmasi WA)
 * Muncul otomatis kalau donation.enabled = true dan minimal satu metode terisi.
 */
function render_donations()
{
    global $MONETIZATION;
    $d = isset($MONETIZATION['donation']) ? $MONETIZATION['donation'] : [];
    if (empty($d['enabled'])) {
        return;
    }

    $links = [];
    if (!empty($d['saweria'])) { $links[] = ['url' => $d['saweria'], 'label' => '☕ Saweria', 'cls' => 'btn btn-primary']; }
    if (!empty($d['ko-fi']))   { $links[] = ['url' => $d['ko-fi'],   'label' => '☕ Ko-fi',   'cls' => 'btn']; }
    if (!empty($d['paypal']))  { $links[] = ['url' => $d['paypal'],  'label' => '💳 PayPal',  'cls' => 'btn']; }

    $wallets = [];
    if (!empty($d['dana']))   { $wallets[] = ['name' => 'DANA',      'num' => $d['dana'],   'icon' => '💙']; }
    if (!empty($d['shopee'])) { $wallets[] = ['name' => 'ShopeePay', 'num' => $d['shopee'], 'icon' => '🧡']; }

    $qr = isset($d['saweria_qr']) ? trim((string)$d['saweria_qr']) : '';

    if (empty($links) && empty($wallets) && $qr === '') {
        return;
    }

    echo '<section class="section section-alt" id="dukung">' . "\n";
    echo '  <div class="container container-narrow">' . "\n";
    echo '    <div class="card donate-card">' . "\n";
    echo '      <h2>' . t('donate.title') . '</h2>' . "\n";
    echo '      <p>' . t('donate.desc') . '</p>' . "\n";

    if ($qr !== '') {
        $qrUrl = (strpos($qr, 'http://') === 0 || strpos($qr, 'https://') === 0) ? $qr : SITE_URL . $qr;
        echo '      <img class="donate-qr" src="' . e($qrUrl) . '" alt="' . e(t('donate.qr_alt')) . '">' . "\n";
    }

    if (!empty($links)) {
        echo '      <div class="donate-btns">' . "\n";
        foreach ($links as $l) {
            echo '        <a class="' . e($l['cls']) . '" href="' . e($l['url']) . '" target="_blank" rel="noopener">' . $l['label'] . '</a>' . "\n";
        }
        echo '      </div>' . "\n";
    }

    if (!empty($wallets)) {
        echo '      <div class="wallet-list">' . "\n";
        foreach ($wallets as $w) {
            echo '        <div class="wallet-item">' . "\n";
            echo '          <span class="wallet-icon">' . $w['icon'] . '</span>' . "\n";
            echo '          <div class="wallet-info">' . "\n";
            echo '            <strong>' . e($w['name']) . '</strong>' . "\n";
            echo '            <span class="wallet-num">' . e($w['num']) . '</span>' . "\n";
            echo '            <small>' . e(t('donate.wallet_by')) . '</small>' . "\n";
            echo '          </div>' . "\n";
            echo '          <button type="button" class="btn wallet-copy" data-copy="' . e($w['num']) . '">' . t('donate.copy') . '</button>' . "\n";
            echo '        </div>' . "\n";
        }
        echo '      </div>' . "\n";
        echo '      <p class="wallet-note">' . t('donate.wallet_note') . ' <a href="https://wa.me/6287711180777" target="_blank" rel="noopener">087711180777</a>.</p>' . "\n";
    }

    echo '    </div>' . "\n";
    echo '  </div>' . "\n";
    echo '</section>' . "\n";

    /* Catatan: logika tombol salin dompet ada di assets/js/app.js
       (lihat fungsi bindWalletCopy) — mendukung multi-bahasa. */
}
