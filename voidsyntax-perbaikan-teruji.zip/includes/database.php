<?php

require_once __DIR__ . '/env_loader.php';

EnvLoader::load(__DIR__ . '/../config');

$host = EnvLoader::get('DB_HOST');
$dbname = EnvLoader::get('DB_NAME');
$username = EnvLoader::get('DB_USER');
$password = EnvLoader::get('DB_PASSWORD');

$conn = new mysqli(
    $host,
    $username,
    $password,
    $dbname
);

if ($conn->connect_error) {
    die('Koneksi database gagal: ' . $conn->connect_error);
}

$conn->set_charset('utf8mb4');