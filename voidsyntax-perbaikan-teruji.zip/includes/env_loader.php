<?php
/**
 * Minimal .env loader compatible with PHP 7.4+ (no str_starts_with dependency).
 * Reads config/.env and project-root .env if present. Existing process/server
 * environment variables take precedence over file values.
 */
final class EnvLoader
{
    private static $loaded = false;
    private static $values = [];

    public static function load($directory = null)
    {
        if (self::$loaded) {
            return;
        }
        self::$loaded = true;
        $directory = $directory ?: dirname(__DIR__) . '/config';
        $files = [rtrim($directory, '/\\') . '/.env', dirname(rtrim($directory, '/\\')) . '/.env'];
        foreach (array_unique($files) as $file) {
            if (!is_file($file) || !is_readable($file)) {
                continue;
            }
            $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (!is_array($lines)) {
                continue;
            }
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) {
                    continue;
                }
                list($key, $value) = explode('=', $line, 2);
                $key = trim($key);
                $value = trim($value);
                if ($key === '' || !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $key)) {
                    continue;
                }
                if (strlen($value) >= 2) {
                    $first = $value[0];
                    $last = substr($value, -1);
                    if (($first === '"' && $last === '"') || ($first === "'" && $last === "'")) {
                        $value = substr($value, 1, -1);
                    }
                }
                // Do not overwrite variables provided by hosting/server config.
                $existing = getenv($key);
                if ($existing !== false && $existing !== '') {
                    continue;
                }
                self::$values[$key] = $value;
                if (!isset($_ENV[$key])) {
                    $_ENV[$key] = $value;
                }
                if (!isset($_SERVER[$key])) {
                    $_SERVER[$key] = $value;
                }
            }
        }
    }

    public static function get($key, $default = null)
    {
        if (array_key_exists($key, self::$values)) {
            return self::$values[$key];
        }
        $value = getenv($key);
        if ($value !== false && $value !== '') {
            return $value;
        }
        if (isset($_ENV[$key]) && $_ENV[$key] !== '') {
            return $_ENV[$key];
        }
        if (isset($_SERVER[$key]) && $_SERVER[$key] !== '') {
            return $_SERVER[$key];
        }
        return $default;
    }
}
