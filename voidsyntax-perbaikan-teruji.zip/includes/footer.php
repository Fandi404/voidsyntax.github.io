<?php
/**
 * includes/footer.php — FOOTER HTML (tema Cosmic Aurora, 4 kolom).
 * Termasuk: brand + tombol APK, tautan cepat, alat, media sosial,
 * kamus teks untuk JavaScript (VS_I18N), registrasi service worker.
 */
if (!defined('SITE_URL')) {
    require_once dirname(__DIR__) . '/config.php';
}
require_once dirname(__DIR__) . '/includes/ads.php';
?>
</main>
<?php render_ad_slot('bottom_banner'); ?>
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div>
                <h3 class="brand" style="font-size:1.35rem;margin-bottom:16px"><span class="b1">Void</span><span class="b2">Syntax</span></h3>
                <p class="footer-desc"><?= te('footer.about') ?></p>
                <div style="display:flex;flex-direction:column;gap:12px;width:fit-content">
                    <a class="btn-green" href="<?= e(lang_url('/app.php')) ?>">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        <span><?= te('footer.apk') ?></span>
                        <span class="badge-xs">Android</span>
                    </a>
                </div>
            </div>

            <div>
                <h3><?= te('footer.quick') ?></h3>
                <ul class="footer-links">
                    <li><a href="<?= e(lang_url('/')) ?>"><?= te('nav.home') ?></a></li>
                    <li><a href="<?= e(lang_url('/cara-penggunaan.php')) ?>"><?= te('nav.howto') ?></a></li>
                    <li><a href="<?= e(lang_url('/faq.php')) ?>"><?= te('nav.faq') ?></a></li>
                    <li><a href="<?= e(lang_url('/kontak.php')) ?>"><?= te('nav.contact') ?></a></li>
                    <li><a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.tiktok_video') ?></a></li>
                    <li><a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.tiktok_mp3') ?></a></li>
                    <li><a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.tiktok_slideshow') ?></a></li>
                    <li><a href="<?= e(lang_url('/artikel/')) ?>"><?= te('nav.sub.articles') ?></a></li>
                </ul>
            </div>

            <div>
                <h3><?= te('footer.tools') ?></h3>
                <ul class="footer-links">
                    <li><a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_video') ?></a></li>
                    <li><a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_photo') ?></a></li>
                    <li><a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_audio') ?></a></li>
                    <li><a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_slideshow') ?></a></li>
                    <li><a href="<?= e(lang_url('/app.php')) ?>"><?= te('footer.apk') ?></a></li>
                    <li><a href="<?= e(lang_url('/kontak.php')) ?>#dmca">DMCA</a></li>
                </ul>
            </div>

            <div>
                <h3><?= te('footer.social') ?></h3>
                <ul class="footer-links">
                    <li><a href="https://wa.me/6287711180777" target="_blank" rel="noopener">💬 WhatsApp: 087711180777</a></li>
                    <li><a href="https://www.tiktok.com/@_fandi96" target="_blank" rel="noopener">🎵 TikTok: @_fandi96</a></li>
                    <li><a href="mailto:afandiae01@gmail.com">✉️ afandiae01@gmail.com</a></li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <p><?= e($SITE_FOOTER_TEXT) ?></p>
            <p class="footer-credit"><?= te('footer.credit_label') ?> <strong>Fandi</strong> • <a href="<?= e(lang_url('/kontak.php')) ?>"><?= te('nav.contact') ?></a></p>
        </div>
        <p class="small" style="margin-top:12px;opacity:.7"><?= te('footer.disclaimer') ?></p>
    </div>
</footer>
<?php render_site_tags(); ?>
<?php render_popunder(); ?>
<script>
window.VS_I18N = <?= json_encode([
    'processing'      => t('form.loading'),
    'fetching'        => t('form.fetching'),
    'network_error'   => t('status.network_error'),
    'no_title'        => t('result.no_title'),
    'seconds'         => t('result.seconds'),
    'via'             => t('result.via'),
    'source'          => t('result.source'),
    'btn_hd'          => t('btn.hd'),
    'btn_sd'          => t('btn.sd'),
    'btn_wm'          => t('btn.wm'),
    'btn_mp3'         => t('btn.mp3'),
    'btn_zip'         => t('btn.zip'),
    'submit'          => t('form.button'),
    'invalid_url'     => t('dl.err_invalid_url'),
    'copied'          => t('donate.copied'),
    'copy'            => t('donate.copy'),
    'paste'           => t('form.paste'),
    'platform_tiktok' => t('platform.tiktok'),
    'platform_douyin' => t('platform.douyin'),
    'update_available' => t('app.update_available'),
    'paste_hint'      => t('paste_hint'),
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>
<script src="<?= SITE_URL ?>/assets/js/app.js?v=<?= APP_VERSION ?>" defer></script>
<script>
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
        navigator.serviceWorker.register('<?= SITE_URL ?>/service-worker.js?v=<?= APP_VERSION ?>').catch(function () {});
    });
}
</script>
</body>
</html>
