<?php
/**
 * includes/functions.php — SEMUA FUNGSI INTI
 * (HTTP helper, validasi URL TikTok/Douyin, parser tiap provider,
 *  AUTO PROVIDER, ekstrak URL dari teks share, dll)
 * File ini tidak untuk diakses langsung via browser (diblokir .htaccess).
 */

if (!defined('SITE_URL')) {
    require_once dirname(__DIR__) . '/config.php';
}

/* ============================================================
 * HTTP HELPER
 * ============================================================ */

/**
 * HTTP GET dengan cURL. Mengembalikan body (string) atau null jika gagal.
 * $timeout: batas waktu per request (detik) — default HTTP_TIMEOUT.
 */
function http_get($url, $headers = [], $timeout = null)
{
    $timeout = $timeout === null ? HTTP_TIMEOUT : (int)$timeout;
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => HTTP_MAX_REDIRECTS,
        CURLOPT_CONNECTTIMEOUT => min(10, $timeout),
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_USERAGENT      => HTTP_USER_AGENT,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING       => '',
        CURLOPT_HTTPHEADER     => $headers,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($body === false || $err !== '' || $code >= 400) {
        return null;
    }
    return $body;
}

/**
 * HTTP GET lalu decode JSON. Mengembalikan array atau null.
 */
function http_get_json($url, $headers = [], $timeout = null)
{
    $body = http_get($url, $headers, $timeout);
    if ($body === null) {
        return null;
    }
    $data = json_decode($body, true);
    return is_array($data) ? $data : null;
}

/* ============================================================
 * CACHE SEDERHANA — anti rate-limit & anti down
 * (hasil sukses disimpan 15 menit; link sama tidak dihitung 2x)
 * ============================================================ */

function vs_cache_path($key)
{
    return sys_get_temp_dir() . '/vs_dl_' . md5((string)$key) . '.cache';
}

/** Ambil cache. Mengembalikan array atau null jika tidak ada/kadaluarsa. */
function vs_cache_get($key)
{
    $p = vs_cache_path($key);
    if (!is_file($p)) {
        return null;
    }
    $raw = @file_get_contents($p);
    if ($raw === false) {
        return null;
    }
    $data = @unserialize($raw);
    if (!is_array($data) || !isset($data['exp']) || $data['exp'] < time()) {
        @unlink($p);
        return null;
    }
    return isset($data['val']) ? $data['val'] : null;
}

/** Simpan cache (TTL detik). Tulis atomik (tmp + rename) supaya aman
 *  walau beberapa permintaan datang bersamaan (anti file korup). */
function vs_cache_set($key, $value, $ttl)
{
    $p = vs_cache_path($key);
    $tmp = $p . '.' . uniqid('', true) . '.tmp';
    if (@file_put_contents($tmp, serialize(['exp' => time() + (int)$ttl, 'val' => $value]), LOCK_EX) !== false) {
        @rename($tmp, $p); // rename = atomik di Linux/hosting
    } else {
        @unlink($tmp);
    }
    // Kebersihan: sesekali buang cache kedaluwarsa supaya /tmp tidak menumpuk
    if (mt_rand(1, 40) === 1) {
        foreach ((array)@glob(sys_get_temp_dir() . '/vs_dl_*.cache') as $old) {
            $raw = @file_get_contents($old);
            $d = $raw !== false ? @unserialize($raw) : null;
            if (!is_array($d) || !isset($d['exp']) || $d['exp'] < time()) {
                @unlink($old);
            }
        }
    }
}

/* ============================================================
 * EKSTRAKSI URL — dukungan paste teks share utuh (seperti downloader populer)
 * ============================================================ */

/**
 * Ambil URL pertama dari teks (mis. teks share Douyin/TikTok yang
 * berisi kalimat + link). Mengembalikan string URL atau ''.
 */
function extract_url($text)
{
    $text = trim((string)$text);
    if ($text === '') {
        return '';
    }
    if (preg_match('#https?://[^\s"\'<>]+#i', $text, $m)) {
        // Buang tanda baca yang menempel di akhir URL
        return rtrim($m[0], '.,;:!?)]}');
    }
    return $text; // bukan teks berisi URL — biarkan divalidasi nanti
}

/* ============================================================
 * VALIDASI & DETEKSI PLATFORM (TikTok / Douyin)
 * ============================================================ */

/**
 * Cek apakah URL adalah link TikTok yang valid.
 * Mendukung: tiktok.com, www.tiktok.com, m.tiktok.com, vm.tiktok.com, vt.tiktok.com.
 */
function is_tiktok_url($url)
{
    if (!is_string($url) || trim($url) === '') {
        return false;
    }
    return (bool)preg_match('#^https?://([a-z0-9-]+\.)*tiktok\.com(/|$|\?)#i', trim($url));
}

/**
 * Cek apakah URL adalah link Douyin (抖音) yang valid.
 * Mendukung: douyin.com, www.douyin.com, v.douyin.com, www.iesdouyin.com, dll.
 */
function is_douyin_url($url)
{
    if (!is_string($url) || trim($url) === '') {
        return false;
    }
    return (bool)preg_match('#^https?://([a-z0-9-]+\.)*(douyin\.com|iesdouyin\.com|douyin\.net)(/|$|\?)#i', trim($url));
}

/**
 * Cek apakah URL didukung (TikTok ATAU Douyin).
 */
function is_supported_url($url)
{
    return is_tiktok_url($url) || is_douyin_url($url);
}

/**
 * Deteksi platform dari URL. Mengembalikan 'tiktok', 'douyin', atau false.
 */
function detect_platform($url)
{
    if (is_douyin_url($url)) {
        return 'douyin';
    }
    if (is_tiktok_url($url)) {
        return 'tiktok';
    }
    return false;
}

/**
 * Resolve link pendek (vm.tiktok.com / vt.tiktok.com / v.douyin.com)
 * menjadi URL lengkap dengan mengikuti redirect (request kecil: hanya 1 byte).
 */
function resolve_short_url($url)
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, // body jangan sampai ke output
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => HTTP_MAX_REDIRECTS,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => HTTP_TIMEOUT,
        CURLOPT_USERAGENT      => HTTP_USER_AGENT,
        CURLOPT_RANGE          => '0-0', // CURLOPT_RANGE expects "X-Y"
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    curl_exec($ch);
    $effective = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);

    return $effective ? $effective : $url;
}

/** Apakah URL termasuk link pendek yang perlu di-resolve? */
function is_short_url($url)
{
    return (bool)preg_match('#^https?://(vm|vt)\.tiktok\.com/#i', $url)
        || (bool)preg_match('#^https?://www\.tiktok\.com/t/#i', $url)
        || (bool)preg_match('#^https?://v\.douyin\.com/#i', $url);
}

/* ============================================================
 * PARSER — satu fungsi per provider
 * Input: array hasil decode JSON dari API provider.
 * Output: array standar ATAU null jika format tidak dikenali.
 * ============================================================ */

/**
 * Standar output parser:
 * [
 *   'id'       => string,  'title'    => string,
 *   'author'   => string,  'avatar'   => string (URL),
 *   'hd'       => string (URL video tanpa watermark),
 *   'wm'       => string (URL video dengan watermark),
 *   'music'    => string (URL audio),
 *   'cover'    => string (URL thumbnail),
 *   'duration' => int (detik),
 *   'provider' => string (nama provider),
 *   'platform' => string ('tiktok' | 'douyin'),
 * ] + 'webpage_url', 'provider_id' (ditambahkan AUTO PROVIDER)
 */

function parse_tikwm($json)
{
    if (!is_array($json)) {
        return null;
    }
    if ((int)(isset($json['code']) ? $json['code'] : -1) !== 0) {
        return null; // tikwm mengembalikan code != 0 jika gagal
    }
    $d = isset($json['data']) ? $json['data'] : null;
    if (!is_array($d)) {
        return null;
    }

    // Post foto/slideshow (images) — kumpulkan URL foto
    $images = [];
    if (isset($d['images']) && is_array($d['images'])) {
        foreach ($d['images'] as $img) {
            if (!is_array($img)) {
                continue;
            }
            $u = '';
            if (isset($img['url_list'][0]) && is_string($img['url_list'][0])) {
                $u = $img['url_list'][0];
            } elseif (isset($img['url']) && is_string($img['url'])) {
                $u = $img['url'];
            } elseif (isset($img[0]) && is_string($img[0])) {
                $u = $img[0];
            }
            if ($u !== '' && strpos($u, 'http') === 0) {
                $images[] = $u;
            }
        }
    }

    $hd = isset($d['hdplay']) ? $d['hdplay'] : '';
    if ($hd === '') {
        $hd = isset($d['play']) ? $d['play'] : '';
    }
    if ($hd === '' && empty($images)) {
        return null;
    }

    $author = isset($d['author']) && is_array($d['author']) ? $d['author'] : [];

    return [
        'id'       => (string)(isset($d['id']) ? $d['id'] : ''),
        'title'    => trim((string)(isset($d['title']) ? $d['title'] : '')),
        'author'   => (string)(isset($author['nickname']) ? $author['nickname'] : (isset($author['unique_id']) ? $author['unique_id'] : '')),
        'avatar'   => (string)(isset($author['avatar']) ? $author['avatar'] : ''),
        'hd'       => (string)$hd,
        'sd'       => (string)(isset($d['play']) ? $d['play'] : $hd),
        'wm'       => (string)(isset($d['wmplay']) ? $d['wmplay'] : $hd),
        'music'    => (string)(isset($d['music']) ? $d['music'] : ''),
        'cover'    => (string)(isset($d['cover']) ? $d['cover'] : (isset($d['origin_cover']) ? $d['origin_cover'] : '')),
        'duration' => (int)(isset($d['duration']) ? $d['duration'] : 0),
        'images'   => $images,
        'type'     => empty($images) ? 'video' : 'images',
        'provider' => 'TikWM',
    ];
}

function parse_tiklydown($json)
{
    if (!is_array($json)) {
        return null;
    }

    // Post foto (slideshow) TiklyDown
    $images = [];
    if (isset($json['images']) && is_array($json['images'])) {
        foreach ($json['images'] as $img) {
            if (is_string($img) && strpos($img, 'http') === 0) {
                $images[] = $img;
            } elseif (is_array($img) && isset($img['url']) && is_string($img['url'])) {
                $images[] = $img['url'];
            }
        }
    }

    $v = isset($json['video']) ? $json['video'] : null;
    if (!is_array($v) && empty($images)) {
        return null;
    }
    $hd = '';
    if (is_array($v)) {
        $hd = isset($v['noWatermarkHD']) ? $v['noWatermarkHD'] : '';
        if ($hd === '') {
            $hd = isset($v['noWatermark']) ? $v['noWatermark'] : '';
        }
    }
    if ($hd === '' && empty($images)) {
        return null;
    }

    $author = isset($json['author']) && is_array($json['author']) ? $json['author'] : [];
    $audio  = isset($json['audio']) && is_array($json['audio']) ? $json['audio'] : [];

    return [
        'id'       => (string)(isset($json['id']) ? $json['id'] : ''),
        'title'    => trim((string)(isset($json['title']) ? $json['title'] : '')),
        'author'   => (string)(isset($author['nickname']) ? $author['nickname'] : (isset($author['name']) ? $author['name'] : (isset($author['unique_id']) ? $author['unique_id'] : ''))),
        'avatar'   => (string)(isset($author['avatar']) ? $author['avatar'] : ''),
        'hd'       => (string)$hd,
        'sd'       => (string)(is_array($v) && isset($v['noWatermark']) ? $v['noWatermark'] : $hd),
        'wm'       => (string)(is_array($v) && isset($v['watermark']) ? $v['watermark'] : $hd),
        'music'    => (string)(isset($audio['music']) ? $audio['music'] : (isset($json['music']) ? $json['music'] : '')),
        'cover'    => (string)(isset($json['image']) ? $json['image'] : (is_array($v) && isset($v['cover']) ? $v['cover'] : '')),
        'duration' => (int)(isset($json['duration']) ? $json['duration'] : 0),
        'images'   => $images,
        'type'     => empty($images) ? 'video' : 'images',
        'provider' => 'TiklyDown',
    ];
}

/**
 * Parser khusus Douyin: ubah objek "aweme" (format JSON resmi Douyin web)
 * menjadi array standar. Objek aweme dipakai oleh hampir semua API Douyin
 * (douyin.wtf, TikHub, hasil scrape halaman share, dll).
 */
function parse_aweme($aweme, $providerName = 'Douyin')
{
    if (!is_array($aweme)) {
        return null;
    }

    $video = isset($aweme['video']) && is_array($aweme['video']) ? $aweme['video'] : [];

    // --- Foto/slideshow (post gambar Douyin/TikTok) ---
    $images = [];
    $imgNodes = [];
    if (isset($aweme['images']) && is_array($aweme['images'])) {
        $imgNodes = $aweme['images'];
    } elseif (isset($aweme['image_post_info']['images']) && is_array($aweme['image_post_info']['images'])) {
        $imgNodes = $aweme['image_post_info']['images'];
    } elseif (isset($aweme['imagePostInfo']['images']) && is_array($aweme['imagePostInfo']['images'])) {
        $imgNodes = $aweme['imagePostInfo']['images'];
    }
    foreach ($imgNodes as $img) {
        if (!is_array($img)) {
            continue;
        }
        $u = '';
        if (isset($img['url_list'][0]) && is_string($img['url_list'][0])) {
            $u = $img['url_list'][0];
        } elseif (isset($img['urlList'][0]) && is_string($img['urlList'][0])) {
            $u = $img['urlList'][0];
        } elseif (isset($img['display_image']['url_list'][0]) && is_string($img['display_image']['url_list'][0])) {
            $u = $img['display_image']['url_list'][0];
        } elseif (isset($img['displayImage']['urlList'][0]) && is_string($img['displayImage']['urlList'][0])) {
            $u = $img['displayImage']['urlList'][0];
        } elseif (isset($img['download_url_list'][0]) && is_string($img['download_url_list'][0])) {
            $u = $img['download_url_list'][0];
        }
        if ($u !== '' && strpos($u, 'http') === 0) {
            $images[] = $u;
        }
    }

    // --- URL video: play_addr (Douyin) / playAddr (TikTok web) ---
    $playUrls = [];
    $dlUrls   = [];
    foreach (['play_addr', 'playAddr'] as $k) {
        if (isset($video[$k]['url_list']) && is_array($video[$k]['url_list'])) {
            $playUrls = $video[$k]['url_list'];
            break;
        }
        if (isset($video[$k]) && is_string($video[$k]) && $video[$k] !== '') {
            $playUrls = [$video[$k]];
            break;
        }
    }
    foreach (['download_addr', 'downloadAddr'] as $k) {
        if (isset($video[$k]['url_list']) && is_array($video[$k]['url_list'])) {
            $dlUrls = $video[$k]['url_list'];
            break;
        }
        if (isset($video[$k]) && is_string($video[$k]) && $video[$k] !== '') {
            $dlUrls = [$video[$k]];
            break;
        }
    }
    $play     = '';
    foreach (array_merge($playUrls, $dlUrls) as $u) {
        if (is_string($u) && $u !== '' && strpos($u, 'http') === 0) {
            $play = $u;
            break;
        }
    }
    if ($play === '' && empty($images)) {
        return null;
    }

    // Trik standar Douyin: URL /aweme/v1/playwm/ = pakai watermark,
    // ganti "playwm" -> "play" = tanpa watermark.
    if ($play !== '' && strpos($play, '/playwm/') !== false) {
        $hd = str_replace('/playwm/', '/play/', $play);
        $wm = $play;
    } else {
        $hd = $play;
        $wm = ($play !== '' && strpos($play, '/play/') !== false)
            ? str_replace('/play/', '/playwm/', $play)
            : (isset($dlUrls[0]) ? (string)$dlUrls[0] : $play);
    }

    // --- Audio (play_url Douyin / playUrl TikTok web) ---
    $music = '';
    if (isset($aweme['music']['play_url']['url_list'][0]) && is_string($aweme['music']['play_url']['url_list'][0])) {
        $music = $aweme['music']['play_url']['url_list'][0];
    } elseif (isset($aweme['music']['play_url']) && is_string($aweme['music']['play_url'])) {
        $music = $aweme['music']['play_url'];
    } elseif (isset($aweme['music']['playUrl']) && is_string($aweme['music']['playUrl'])) {
        $music = $aweme['music']['playUrl'];
    }

    // --- Cover (array url_list Douyin / string TikTok web) ---
    $cover = '';
    foreach (['video.cover.url_list.0', 'video.origin_cover.url_list.0', 'video.dynamic_cover.url_list.0',
              'video.cover', 'video.originCover', 'video.dynamicCover'] as $path) {
        $node = $aweme;
        foreach (explode('.', $path) as $k) {
            $node = (is_array($node) && isset($node[$k])) ? $node[$k] : null;
            if ($node === null) {
                break;
            }
        }
        if (is_string($node) && $node !== '') {
            $cover = $node;
            break;
        }
    }

    // --- Author (nickname + avatar) ---
    $author = isset($aweme['author']) && is_array($aweme['author']) ? $aweme['author'] : [];
    $avatar = '';
    if (isset($author['avatar_thumb']['url_list'][0])) {
        $avatar = (string)$author['avatar_thumb']['url_list'][0];
    } elseif (isset($author['avatar_thumb']) && is_string($author['avatar_thumb'])) {
        $avatar = $author['avatar_thumb'];
    } elseif (isset($author['avatarThumb']) && is_string($author['avatarThumb'])) {
        $avatar = $author['avatarThumb'];
    } elseif (isset($author['avatarLarger']) && is_string($author['avatarLarger'])) {
        $avatar = $author['avatarLarger'];
    } elseif (isset($author['avatar_larger']['url_list'][0])) {
        $avatar = (string)$author['avatar_larger']['url_list'][0];
    }

    // --- Durasi: API Douyin web sering pakai milidetik ---
    $dur = (int)(isset($aweme['duration']) ? $aweme['duration'] : (isset($video['duration']) ? $video['duration'] : 0));
    if ($dur >= 10000) {
        $dur = (int)round($dur / 1000);
    }

    return [
        'id'       => (string)(isset($aweme['aweme_id']) ? $aweme['aweme_id'] : (isset($aweme['id']) ? $aweme['id'] : (isset($aweme['itemId']) ? $aweme['itemId'] : ''))),
        'title'    => trim((string)(isset($aweme['desc']) ? $aweme['desc'] : (isset($aweme['title']) ? $aweme['title'] : ''))),
        'author'   => (string)(isset($author['nickname']) ? $author['nickname'] : (isset($author['unique_id']) ? $author['unique_id'] : '')),
        'avatar'   => $avatar,
        'hd'       => $hd,
        'sd'       => isset($dlUrls[0]) && is_string($dlUrls[0]) && strpos($dlUrls[0], 'http') === 0 ? $dlUrls[0] : $hd,
        'wm'       => $wm,
        'music'    => $music,
        'cover'    => $cover,
        'duration' => $dur,
        'images'   => $images,
        'type'     => empty($images) ? 'video' : 'images',
        'provider' => $providerName,
    ];
}

/**
 * Parser untuk API douyin.wtf (Evil0ctal Douyin_TikTok_Download_API) dan
 * API serupa yang mengembalikan JSON berisi objek "aweme".
 * Mendukung beberapa bentuk respons: aweme_data, aweme_list[0], data.item_list[0].
 */
function parse_douyin_wtf($json)
{
    if (!is_array($json)) {
        return null;
    }

    $candidates = [];
    if (isset($json['aweme_data'])) {
        $candidates[] = $json['aweme_data'];
    }
    if (isset($json['aweme_list'][0])) {
        $candidates[] = $json['aweme_list'][0];
    }
    if (isset($json['data']['aweme_data'])) {
        $candidates[] = $json['data']['aweme_data'];
    }
    if (isset($json['data']['item_list'][0])) {
        $candidates[] = $json['data']['item_list'][0];
    }
    if (isset($json['data']['aweme_list'][0])) {
        $candidates[] = $json['data']['aweme_list'][0];
    }
    $candidates[] = $json; // kadang objek aweme dikirim langsung
    $found = find_aweme_node($json);
    if ($found !== null) {
        $candidates[] = $found;
    }

    foreach ($candidates as $node) {
        if (is_array($node) && (isset($node['video']) || isset($node['aweme_id']))) {
            $out = parse_aweme($node, 'Douyin.wtf API');
            if ($out !== null) {
                return $out;
            }
        }
    }
    return null;
}

/**
 * Cari objek video ("aweme"/item) di dalam JSON apa pun secara rekursif —
 * dipakai untuk hasil scrape halaman share Douyin / halaman TikTok yang
 * strukturnya sering berubah. Menerima format snake_case (Douyin) maupun
 * camelCase (TikTok web).
 */
function find_aweme_node($node, $depth = 0)
{
    if ($depth > 8 || !is_array($node)) {
        return null;
    }
    $hasId    = isset($node['aweme_id']) || isset($node['id']) || isset($node['itemId']);
    $hasVideo = isset($node['video']) && is_array($node['video']);
    if ($hasId && $hasVideo) {
        return $node;
    }
    foreach ($node as $child) {
        if (is_array($child)) {
            $found = find_aweme_node($child, $depth + 1);
            if ($found !== null) {
                return $found;
            }
        }
    }
    return null;
}

/**
 * Parser lokal TikTok (tanpa API pihak ketiga): buka halaman video TikTok
 * lalu baca data JSON yang ditanam di halaman tersebut (RENDER_DATA /
 * __UNIVERSAL_DATA_FOR_REHYDRATION__ / SIGI_STATE).
 * Dipanggil langsung dengan URL video (bukan JSON).
 */
function parse_tiktok_direct($url)
{
    // Ambil ID video dari URL (mis. /@user/video/1234567890 atau /@user/photo/123)
    $id = '';
    if (preg_match('#/(?:video|photo|v|story)/(\d+)#i', $url, $m)) {
        $id = $m[1];
    }
    if ($id === '') {
        return null;
    }

    // Coba URL halaman yang mungkin (bentuk lengkap & pendek)
    $pages = [rtrim($url, '/')];
    if (preg_match('#/@[^/]+/#i', $url)) {
        $pages[] = 'https://www.tiktok.com/embed/v2/' . $id; // halaman embed (ringan)
    }

    foreach ($pages as $pageUrl) {
        $html = http_get($pageUrl, [
            'Accept: text/html,application/xhtml+xml',
            'Referer: https://www.tiktok.com/',
            'Accept-Language: en-US,en;q=0.9',
        ], PROVIDER_TIMEOUT);
        if ($html === null || $html === '') {
            continue;
        }

        $jsonCandidates = [];

        // Bentuk 1: <script id="RENDER_DATA" type="application/json">URL-ENCODED</script>
        if (preg_match('/<script[^>]+id="RENDER_DATA"[^>]*>(.*?)<\/script>/s', $html, $m)) {
            $data = json_decode(urldecode(trim($m[1])), true);
            if (is_array($data)) {
                $jsonCandidates[] = $data;
            }
        }
        // Bentuk 2: __UNIVERSAL_DATA_FOR_REHYDRATION__
        if (preg_match('/<script[^>]+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)<\/script>/s', $html, $m)) {
            $data = json_decode(trim($m[1]), true);
            if (is_array($data)) {
                $jsonCandidates[] = $data;
            }
        }
        // Bentuk 3: SIGI_STATE (format lama TikTok)
        if (preg_match('/<script[^>]+id="SIGI_STATE"[^>]*>(.*?)<\/script>/s', $html, $m)) {
            $data = json_decode(trim($m[1]), true);
            if (is_array($data)) {
                $jsonCandidates[] = $data;
            }
        }
        // Bentuk 4: window.__UNIVERSAL_DATA_FOR_REHYDRATION__ = {...}
        if (preg_match('/__UNIVERSAL_DATA_FOR_REHYDRATION__\s*=\s*(\{.*?\})\s*;?\s*<\/script>/s', $html, $m)) {
            $data = json_decode(trim($m[1]), true);
            if (is_array($data)) {
                $jsonCandidates[] = $data;
            }
        }

        foreach ($jsonCandidates as $data) {
            $node = find_aweme_node($data);
            if ($node !== null) {
                $out = parse_aweme($node, 'TikTok Direct');
                if ($out !== null) {
                    return $out;
                }
            }
        }
    }

    return null;
}

/**
 * Ambil cookie ttwid dari Douyin (dibutuhkan halaman share Douyin agar tidak
 * kena halaman verifikasi). Mengembalikan string cookie atau ''.
 */
function douyin_fetch_ttwid()
{
    static $ttwid = null;
    if ($ttwid !== null) {
        return $ttwid;
    }
    $ttwid = '';
    $ch = curl_init('https://www.douyin.com/');
    $cookies = [];
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 3,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_USERAGENT      => HTTP_USER_AGENT,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HEADERFUNCTION => function ($ch, $h) use (&$cookies) {
            if (stripos($h, 'Set-Cookie:') === 0 && stripos($h, 'ttwid=') !== false) {
                if (preg_match('/ttwid=([^;]+)/i', $h, $m)) {
                    $cookies[] = 'ttwid=' . trim($m[1]);
                }
            }
            return strlen($h);
        },
    ]);
    curl_setopt($ch, CURLOPT_RANGE, '0-0'); // request kecil saja
    curl_exec($ch);
    curl_close($ch);
    $ttwid = implode('; ', $cookies);
    return $ttwid;
}

/**
 * ==== PENYEDIA OPSIONAL: TikHub API (https://tikhub.io) ====
 * Aktifkan dengan mengisi TIKHUB_API_KEY di config.php (butuh 1 baris).
 * Begitu kunci diisi, provider ini otomatis masuk rantai untuk TikTok & Douyin.
 */
function parse_tikhub($url)
{
    $key = defined('TIKHUB_API_KEY') ? TIKHUB_API_KEY : '';
    if ($key === '') {
        return null;
    }
    $is_douyin = stripos($url, 'douyin') !== false || stripos($url, 'iesdouyin') !== false;
    // Ekstrak ID
    $id = '';
    if (preg_match('#/(?:video|note|item)/(\d+)#i', $url, $m)) {
        $id = $m[1];
    } elseif (preg_match('#/(\d{15,25})#', $url, $m)) {
        $id = $m[1];
    }
    if ($id === '') {
        return null;
    }
    $endpoint = $is_douyin
        ? 'https://api.tikhub.io/api/v1/douyin/web/fetch_one_video?aweme_id=' . $id
        : 'https://api.tikhub.io/api/v1/tiktok/web/fetch_one_video?aweme_id=' . $id;
    $j = http_get_json($endpoint, [
        'Authorization: Bearer ' . $key,
        'Accept: application/json',
        'User-Agent: ' . HTTP_USER_AGENT,
    ], PROVIDER_TIMEOUT);
    if (!$j) {
        return null;
    }
    $node = $j['data']['aweme_detail'] ?? $j['data'] ?? $j['aweme_detail'] ?? null;
    if (!is_array($node)) {
        return null;
    }
    $r = parse_aweme($node);
    return $r !== null ? $r : null;
}

/**
 * ==== PENYEDIA: DLPanda (dlpanda.com/douyin) — scraper pihak ketiga ====
 * Berguna saat Douyin memblokir IP server: DLPanda yang mengambil dari IP mereka.
 */
function parse_dlpanda_douyin($url)
{
    $cookieFile = tempnam(sys_get_temp_dir(), 'dlp');
    $html = false;

    // Langkah 1: ambil halaman untuk cookie + token CSRF
    $ch = curl_init('https://dlpanda.com/douyin');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 3,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT        => PROVIDER_TIMEOUT,
        CURLOPT_USERAGENT      => HTTP_USER_AGENT,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_COOKIEJAR      => $cookieFile,
        CURLOPT_COOKIEFILE     => $cookieFile,
    ]);
    $html = curl_exec($ch);
    curl_close($ch);
    if (!is_string($html) || $html === '') {
        @unlink($cookieFile);
        return null;
    }
    $token = preg_match('/name="_token"\s+value="([^"]+)"/', $html, $m) ? $m[1] : '';
    $t0ken = preg_match('/name="t0ken"\s+value="([^"]+)"/', $html, $m) ? $m[1] : '';

    // Langkah 2: POST URL target
    $ch = curl_init('https://dlpanda.com/douyin');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query([
            '_token' => $token,
            't0ken'  => $t0ken,
            'url'    => $url,
        ]),
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 3,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT        => PROVIDER_TIMEOUT,
        CURLOPT_USERAGENT      => HTTP_USER_AGENT,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_COOKIEJAR      => $cookieFile,
        CURLOPT_COOKIEFILE     => $cookieFile,
        CURLOPT_REFERER        => 'https://dlpanda.com/douyin',
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/x-www-form-urlencoded',
            'Origin: https://dlpanda.com',
            'Accept: text/html,application/xhtml+xml',
        ],
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    @unlink($cookieFile);
    if (!is_string($res) || $res === '') {
        return null;
    }

    // Cari tautan unduhan di HTML hasil
    $video = '';
    $music = '';
    $cover = '';
    if (preg_match_all('#href=["\']?(https?://[^"\'\s>]+\.mp4[^"\'\s>]*)#i', $res, $m)) {
        $video = end($m[1]);
    }
    if (preg_match_all('#href=["\']?(https?://[^"\'\s>]+\.mp3[^"\'\s>]*)#i', $res, $m)) {
        $music = end($m[1]);
    }
    if (preg_match('#<img[^>]+src=["\']?(https?://[^"\'\s>]+)#i', $res, $m)) {
        $cover = $m[1];
    }
    $title = '';
    if (preg_match('#<h5[^>]*>(.*?)</h5>#is', $res, $m)) {
        $title = trim(strip_tags($m[1]));
    } elseif (preg_match('#<title>(.*?)</title>#is', $res, $m)) {
        $title = trim(strip_tags($m[1]));
    }

    if ($video === '' && $music === '') {
        return null;
    }

    $id = preg_match('#/(\d{15,25})#', $url, $m) ? $m[1] : 'x';

    return [
        'id'           => $id,
        'title'        => $title !== '' ? $title : 'Douyin Video ' . $id,
        'author'       => '',
        'avatar'       => '',
        'hd'           => $video,
        'sd'           => $video,
        'wm'           => '',
        'music'        => $music,
        'cover'        => $cover,
        'duration'     => 0,
        'images'       => [],
        'type'         => $video !== '' ? 'video' : 'audio',
        'provider'     => 'DLPanda',
        'webpage_url'  => $url,
    ];
}

/**
 * Parser lokal Douyin (tanpa API pihak ketiga): buka halaman share resmi
 * Douyin lalu baca data JSON yang ditanam di halaman tersebut.
 * Dipanggil langsung dengan URL video (bukan JSON).
 */
function parse_douyin_direct($url)
{
    // Ambil ID video dari URL (mis. /video/1234567890/ atau /share/video/1234567890/)
    $id = '';
    if (preg_match('#/(?:video|note|share/video)/(\d+)#i', $url, $m)) {
        $id = $m[1];
    }
    if ($id === '') {
        return null;
    }

    $pages = [
        'https://www.iesdouyin.com/share/video/' . $id . '/',
        'https://www.douyin.com/video/' . $id,
    ];

    $ttwid  = douyin_fetch_ttwid();
    $cookie = $ttwid !== '' ? ['Cookie: ' . $ttwid] : [];

    foreach ($pages as $pageUrl) {
        $html = http_get($pageUrl, array_merge([
            'Accept: text/html,application/xhtml+xml',
            'Referer: ' . $pageUrl,
            'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
        ], $cookie), PROVIDER_TIMEOUT);
        if ($html === null || $html === '') {
            continue;
        }

        $jsonCandidates = [];

        // Bentuk 1: <script id="RENDER_DATA" type="application/json">URL-ENCODED</script>
        if (preg_match('/<script[^>]+id="RENDER_DATA"[^>]*>(.*?)<\/script>/s', $html, $m)) {
            $decoded = urldecode(trim($m[1]));
            $data = json_decode($decoded, true);
            if (is_array($data)) {
                $jsonCandidates[] = $data;
            }
        }

        // Bentuk 2: <script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application/json">JSON</script>
        if (preg_match('/<script[^>]+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)<\/script>/s', $html, $m)) {
            $data = json_decode(trim($m[1]), true);
            if (is_array($data)) {
                $jsonCandidates[] = $data;
            }
        }

        // Bentuk 3: window._ROUTER_DATA = {...};
        if (preg_match('/window\._ROUTER_DATA\s*=\s*(\{.*?\})\s*;?\s*<\/script>/s', $html, $m)) {
            $data = json_decode(trim($m[1]), true);
            if (is_array($data)) {
                $jsonCandidates[] = $data;
            }
        }

        foreach ($jsonCandidates as $data) {
            $aweme = find_aweme_node($data);
            if ($aweme !== null) {
                $out = parse_aweme($aweme, 'Douyin Direct');
                if ($out !== null) {
                    return $out;
                }
            }
        }
    }

    return null;
}

/* ============================================================
 * AUTO PROVIDER — mencoba semua provider secara berurutan
 * ============================================================ */

/**
 * Ambil data video TikTok / Douyin. Mengembalikan array standar (lihat parser)
 * atau ['error' => '...'] jika semua provider gagal.
 *
 * $inputUrl boleh berupa URL asli ATAU teks share utuh (otomatis diekstrak).
 */
function fetch_video($inputUrl)
{
    global $PROVIDERS, $DOUYIN_PROVIDERS;

    // 1) Ekstrak URL dari teks share (kalau pengguna menempel teks utuh)
    $url = extract_url($inputUrl);
    if ($url === '' || !is_supported_url($url)) {
        return ['error' => t('dl.err_invalid_url')];
    }

    // Rapikan spasi yang mungkin ikut ter-copy
    $url = preg_replace('/\s+/', '', $url);

    // 2) Resolve link pendek agar provider bisa membacanya
    if (is_short_url($url)) {
        $resolved = resolve_short_url($url);
        if (is_supported_url($resolved)) {
            $url = $resolved;
        }
    }

    // 3) Pilih rantai provider sesuai platform
    $platform = detect_platform($url);
    if ($platform === false) {
        return ['error' => t('dl.err_invalid_url')];
    }
    $providers = ($platform === 'douyin')
        ? (isset($DOUYIN_PROVIDERS) ? $DOUYIN_PROVIDERS : [])
        : (isset($PROVIDERS) ? $PROVIDERS : []);

    // 4) Cache: hasil sukses disimpan 15 menit (hemat kuota provider / anti
    //    rate-limit); hasil gagal disimpan singkat supaya tidak memborbardir
    //    provider saat link memang tidak valid.
    $cacheKey = 'fetch_' . $platform . '_' . $url;
    $cached   = vs_cache_get($cacheKey);
    if (is_array($cached) && isset($cached['data'])) {
        return $cached['data'];
    }

    $started = time();
    $retries = max(1, defined('PROVIDER_RETRIES') ? (int)PROVIDER_RETRIES : 2);
    $budget  = max(10, defined('PROVIDER_BUDGET') ? (int)PROVIDER_BUDGET : 50);

    $errors = [];
    foreach ($providers as $provider) {
        // Anggaran waktu total — jangan sampai pengunjung menunggu lama
        if (time() - $started > $budget) {
            $errors[] = 'waktu pemrosesan habis';
            break;
        }

        $parser = isset($provider['parser']) ? $provider['parser'] : '';
        $name   = isset($provider['name']) ? $provider['name'] : (string)$provider['id'];

        if (isset($provider['api_url']) && !is_callable($parser)) {
            $errors[] = $name . ' (parser tidak ditemukan)';
            continue;
        }
        if (!isset($provider['api_url']) && !is_callable($parser)) {
            $errors[] = $name . ' (parser tidak ditemukan)';
            continue;
        }

        $result   = null;
        $lastNote = 'tidak merespon';
        if (count($errors) > 0) {
            usleep(250000); // jeda antar-provider (sopan & hindari limit beruntun)
        }
        for ($attempt = 1; $attempt <= $retries; $attempt++) {
            if (time() - $started > $budget) {
                break;
            }
            if (isset($provider['api_url'])) {
                // Provider tipe API: GET JSON lalu parse
                $apiUrl  = $provider['api_url'] . rawurlencode($url);
                $headers = ['Accept: application/json'];
                if (!empty($provider['headers']) && is_array($provider['headers'])) {
                    $headers = array_merge($headers, $provider['headers']);
                }
                $json = http_get_json($apiUrl, $headers, PROVIDER_TIMEOUT);
                if ($json === null) {
                    $lastNote = 'tidak merespon';
                    continue; // retry
                }
                $result = call_user_func($parser, $json);
            } else {
                // Provider tipe langsung (scrape halaman sendiri)
                $result = call_user_func($parser, $url);
            }

            if (is_array($result)) {
                break;
            }
            $lastNote = 'format tidak dikenali / video tidak tersedia';
            if ($attempt < $retries) {
                usleep(1200000); // jeda 1,2 detik — TikWM membatasi 1 request/detik,
                                 // jeda ini membuat retry benar-benar lolos rate-limit
            }
        }

        if (is_array($result)) {
            $result['webpage_url'] = $url;
            $result['provider_id'] = $provider['id'];
            $result['platform']    = $platform;
            vs_cache_set($cacheKey, ['ok' => true, 'data' => $result], CACHE_TTL);
            return $result;
        }
        $errors[] = $name . ' (' . $lastNote . ')';
    }

    $out = [
        'error' => t('err.all_providers'),
        'debug' => $errors,
    ];
    vs_cache_set($cacheKey, ['ok' => false, 'data' => $out], CACHE_FAIL_TTL);
    return $out;
}

/**
 * Kompatibilitas lama — fungsi lama fetch_tiktok() tetap tersedia.
 */
function fetch_tiktok($inputUrl)
{
    return fetch_video($inputUrl);
}

/* ============================================================
 * HELPER LAIN
 * ============================================================ */

/** Escape output untuk HTML. */
function e($str)
{
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/**
 * Buat nama file unduhan yang rapi, contoh:
 * tiktok_djkhaled_7590113207298133261_20261007.mp4
 * douyin_zhangsan_7451234567890123456_20261010.mp4
 */
function make_filename($info, $ext)
{
    $base = 'video';
    if (!empty($info['platform']) && preg_match('/^[a-z]+$/', $info['platform'])) {
        $base = $info['platform'];
    } elseif (!empty($info['provider']) && stripos($info['provider'], 'douyin') !== false) {
        $base = 'douyin';
    } else {
        $base = 'tiktok';
    }
    if (!empty($info['author'])) {
        $base .= '_' . preg_replace('/[^A-Za-z0-9_-]/', '', $info['author']);
    }
    if (!empty($info['id'])) {
        $base .= '_' . preg_replace('/[^0-9]/', '', $info['id']);
    }
    $base .= '_' . date('Ymd');
    return $base . '.' . $ext;
}

/**
 * Validasi host URL media hasil provider — hanya izinkan domain resmi
 * TikTok, Douyin & CDN terkait, untuk menghindari penyalahgunaan (SSRF).
 */
function is_allowed_media_host($url)
{
    $host = parse_url($url, PHP_URL_HOST);
    if (!$host) {
        return false;
    }
    $host    = strtolower($host);
    $allowed = [
        // TikTok
        'tiktok.com', 'tiktokcdn.com', 'tiktokcdn-us.com', 'tiktokv.com', 'muscdn.com', 'musical.ly',
        // Douyin / ByteDance
        'douyin.com', 'douyinpic.com', 'douyinvod.com', 'douyinstatic.com', 'iesdouyin.com',
        'snssdk.com', 'amemv.com', 'byteimg.com', 'ibytedtos.com', 'zjcdn.com', 'bytedance.com',
        // Provider
        'tiklydown.eu.org', 'tikwm.com', 'dlpanda.com',
    ];
    foreach ($allowed as $suffix) {
        if ($host === $suffix || substr($host, -strlen('.' . $suffix)) === '.' . $suffix) {
            return true;
        }
    }
    return false;
}

/**
 * Referer yang tepat untuk streaming media sesuai platform.
 */
function media_referer($platform)
{
    return $platform === 'douyin' ? 'https://www.douyin.com/' : 'https://www.tiktok.com/';
}
