<?php
/**
 * includes/header.php — HEADER HTML semua halaman (tema Cosmic Aurora).
 * Termasuk: meta SEO + hreflang, JSON-LD, nav + dropdown, pemilih bahasa,
 * toggle tema terang/gelap, menu mobile, iklan opsional.
 */
if (!defined('SITE_URL')) {
    require_once dirname(__DIR__) . '/config.php';
}
require_once dirname(__DIR__) . '/includes/ads.php';

$pageTitle = isset($pageTitle) ? $pageTitle : t('meta.title_home');
$pageDesc  = isset($pageDesc)  ? $pageDesc  : t('meta.desc_home');
$canonPath = isset($canonicalPath) ? $canonicalPath : '/';
$canonical = lang_url($canonPath);
?>
<!DOCTYPE html>
<html lang="<?= SITE_LANG ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?></title>
    <meta name="description" content="<?= e($pageDesc) ?>">
    <meta name="keywords" content="<?= e(t('meta.keywords')) ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?= e($canonical) ?>">
    <?php foreach (vs_supported_langs() as $code => $meta): ?>
    <link rel="alternate" hreflang="<?= e($code) ?>" href="<?= e(lang_url_for($code, $canonPath)) ?>">
    <?php endforeach; ?>
    <link rel="alternate" hreflang="x-default" href="<?= e(rtrim(SITE_URL, '/') . ($canonPath === '/' ? '/' : '/' . ltrim($canonPath, '/'))) ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?= e(SITE_NAME) ?>">
    <meta property="og:locale" content="<?= e(vs_og_locale()) ?>">
    <meta property="og:title" content="<?= e($pageTitle) ?>">
    <meta property="og:description" content="<?= e($pageDesc) ?>">
    <meta property="og:url" content="<?= e($canonical) ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="theme-color" content="#4f46e5">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="VoidSyntax">
    <link rel="manifest" href="<?= SITE_URL ?>/manifest.json">
    <link rel="apple-touch-icon" href="<?= SITE_URL ?>/assets/img/icon-192.png">
    <meta property="og:image" content="<?= SITE_URL ?>/assets/img/og-thumbnail.jpg?v=<?= APP_VERSION ?>">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta name="twitter:image" content="<?= SITE_URL ?>/assets/img/og-thumbnail.jpg?v=<?= APP_VERSION ?>">
    <meta name="twitter:title" content="<?= e($pageTitle) ?>">
    <meta name="twitter:description" content="<?= e($pageDesc) ?>">
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ctext y='.9em' font-size='90'%3E%F0%9F%8E%B5%3C/text%3E%3C/svg%3E">
    <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css?v=<?= APP_VERSION ?>">
    <script>
    /* Terapkan tema tersimpan SEBELUM render (cegah kedip) */
    try {
        var vsTheme = localStorage.getItem('vs_theme');
        if (vsTheme === 'dark' || (!vsTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        }
    } catch (e) {}
    </script>
    <?php render_head_tags(); ?>
    <?php if (!empty($MONETIZATION['adsense_enabled']) && !empty($MONETIZATION['adsense_client'])): ?>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=<?= e($MONETIZATION['adsense_client']) ?>" crossorigin="anonymous"></script>
    <?php endif; ?>
    <?php if (!empty($MONETIZATION['ga4_id'])): ?>
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($MONETIZATION['ga4_id']) ?>"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '<?= e($MONETIZATION['ga4_id']) ?>');
    </script>
    <?php endif; ?>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": <?= json_encode(SITE_NAME, JSON_UNESCAPED_UNICODE) ?>,
      "url": <?= json_encode(lang_url('/'), JSON_UNESCAPED_UNICODE) ?>,
      "applicationCategory": "UtilitiesApplication",
      "operatingSystem": "Web, Android",
      "inLanguage": <?= json_encode(SITE_LANG, JSON_UNESCAPED_UNICODE) ?>,
      "description": <?= json_encode($pageDesc, JSON_UNESCAPED_UNICODE) ?>,
      "offers": { "@type": "Offer", "price": "0", "priceCurrency": "IDR" },
      "author": { "@type": "Person", "name": "Fandi", "url": "https://www.tiktok.com/@_fandi96" }
    }
    </script>
    <?php if (empty($noFaqSchema) && !empty($SITE_FAQ)): ?>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        <?php foreach ($SITE_FAQ as $i => $q): ?>{
          "@type": "Question",
          "name": <?= json_encode($q['q'], JSON_UNESCAPED_UNICODE) ?>,
          "acceptedAnswer": { "@type": "Answer", "text": <?= json_encode($q['a'], JSON_UNESCAPED_UNICODE) ?> }
        }<?= $i < count($SITE_FAQ) - 1 ? ',' : '' ?>
        <?php endforeach; ?>
      ]
    }
    </script>
    <?php endif; ?>
</head>
<body>
<header class="site-header">
    <div class="container header-inner">
        <a href="<?= e(lang_url('/')) ?>" class="brand"><span class="logo-mark">VS</span><span class="grad-text">VoidSyntax</span></a>

        <nav class="main-nav">
            <a href="<?= e(lang_url('/')) ?>"><?= te('nav.home') ?></a>
            <a href="<?= e(lang_url('/cara-penggunaan.php')) ?>"><?= te('nav.howto') ?></a>
            <a href="<?= e(lang_url('/faq.php')) ?>"><?= te('nav.faq') ?></a>
            <a href="<?= e(lang_url('/kontak.php')) ?>"><?= te('nav.contact') ?></a>

            <div class="dropdown" data-dropdown>
                <button type="button"><?= te('nav.tiktok_dl') ?>
                    <svg class="w-4 h-4" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
                <div class="dropdown-menu">
                    <a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.tiktok_video') ?></a>
                    <a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.tiktok_mp3') ?></a>
                    <a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.tiktok_slideshow') ?></a>
                    <a href="<?= e(lang_url('/#how-to-use')) ?>"><?= te('nav.sub.tiktok_story') ?></a>
                    <a href="<?= e(lang_url('/artikel/')) ?>"><?= te('nav.sub.articles') ?></a>
                </div>
            </div>

            <div class="dropdown" data-dropdown>
                <button type="button"><?= te('nav.douyin_dl') ?>
                    <svg class="w-4 h-4" width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
                <div class="dropdown-menu">
                    <a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_video') ?></a>
                    <a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_audio') ?></a>
                    <a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_photo') ?></a>
                    <a href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_slideshow') ?></a>
                </div>
            </div>
        </nav>

        <div class="header-actions">
            <div class="lang-wrap" data-langwrap>
                <button type="button" class="btn-chip" data-langbtn>
                    <span class="text-base"><?= (vs_supported_langs()[SITE_LANG]['flag'] ?? '🌐') ?></span>
                    <span style="font-weight:600"><?= strtoupper(e(SITE_LANG)) ?></span>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M19 9l-7 7-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
                <div class="lang-menu" data-langmenu>
                    <?php foreach (vs_supported_langs() as $code => $meta): ?>
                    <a class="<?= $code === SITE_LANG ? 'active' : '' ?>" href="<?= e(lang_url_for($code, $canonPath)) ?>" hreflang="<?= e($code) ?>"><span><?= $meta['flag'] ?></span> <?= e($meta['name']) ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <button type="button" class="btn-chip btn-icon" data-theme title="Toggle theme">
                <span class="sr-only">Toggle theme</span>
                <svg class="icon-moon" viewBox="0 0 24 24" fill="none"><path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                <svg class="icon-sun" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="2"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4l1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4m11.4-11.4l1.4-1.4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
            </button>
            <button type="button" class="burger" data-burger aria-label="Menu">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
            </button>
        </div>

    </div>

    <div class="mobile-menu" data-mobilemenu>
        <a href="<?= e(lang_url('/')) ?>"><?= te('nav.home') ?></a>
        <a href="<?= e(lang_url('/cara-penggunaan.php')) ?>"><?= te('nav.howto') ?></a>
        <a href="<?= e(lang_url('/faq.php')) ?>"><?= te('nav.faq') ?></a>
        <a href="<?= e(lang_url('/kontak.php')) ?>"><?= te('nav.contact') ?></a>
        <a class="mm-sub" href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.tiktok_video') ?></a>
        <a class="mm-sub" href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.tiktok_mp3') ?></a>
        <a class="mm-sub" href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_video') ?></a>
        <a class="mm-sub" href="<?= e(lang_url('/#unduh')) ?>"><?= te('nav.sub.douyin_audio') ?></a>
        <a class="mm-sub" href="<?= e(lang_url('/artikel/')) ?>"><?= te('nav.sub.articles') ?></a>
        <a class="mm-sub" href="<?= e(lang_url('/app.php')) ?>"><?= te('footer.apk') ?></a>
    </div>
</header>
<main class="container">
<?php render_ad_slot('top_banner'); ?>
