<?php
/**
 * includes/i18n.php — SISTEM MULTI-BAHASA
 * Terjemahan disimpan di folder /lang (satu file per bahasa, kunci => teks).
 *
 * Pakai:
 *   t('nav.articles')                  -> teks terjemahan
 *   t('footer.copy', ['year' => '2026']) -> dengan placeholder :year
 *   te('hero.title')                   -> terjemahan + escape HTML
 *   lang_url('/artikel/')              -> URL dengan prefix bahasa (/en/artikel/)
 *
 * Cara menambah bahasa baru: salin lang/en.php menjadi lang/xx.php (xx = kode
 * bahasa, 2 huruf), terjemahkan isinya, lalu daftarkan di $VS_LANG_META bawah.
 * File ini tidak untuk diakses langsung via browser (diblokir .htaccess).
 */

if (!defined('APP_NAME')) {
    exit('Akses langsung tidak diizinkan.');
}

/* Daftar bahasa yang tersedia: kode => [nama asli, bendera] */
$GLOBALS['VS_LANG_META'] = [
    'id' => ['name' => 'Indonesia',      'flag' => '🇮🇩'],
    'en' => ['name' => 'English',        'flag' => '🇬🇧'],
    'ms' => ['name' => 'Bahasa Melayu',  'flag' => '🇲🇾'],
];

$GLOBALS['VS_LANG_DEFAULT'] = 'id';
$GLOBALS['VS_TRANSLATIONS'] = [];   // cache per bahasa
$GLOBALS['VS_CURRENT_LANG'] = null;

/** Daftar bahasa yang didukung (kode => meta). */
function vs_supported_langs()
{
    return $GLOBALS['VS_LANG_META'];
}

/** Bahasa yang sedang aktif (deteksi dari URL ?lang / cookie / Accept-Language). */
function vs_current_lang()
{
    if ($GLOBALS['VS_CURRENT_LANG'] !== null) {
        return $GLOBALS['VS_CURRENT_LANG'];
    }

    $supported = vs_supported_langs();
    $default   = $GLOBALS['VS_LANG_DEFAULT'];
    $lang      = '';

    // 1) Parameter ?lang=en atau prefix path /en (hasil rewrite .htaccess)
    if (isset($_GET['lang'])) {
        $cand = strtolower(substr(preg_replace('/[^a-z]/i', '', (string)$_GET['lang']), 0, 2));
        if (isset($supported[$cand])) {
            $lang = $cand;
        }
    }

    // 2) Cookie pilihan pengguna
    if ($lang === '' && isset($_COOKIE['vs_lang'])) {
        $cand = strtolower(substr(preg_replace('/[^a-z]/i', '', (string)$_COOKIE['vs_lang']), 0, 2));
        if (isset($supported[$cand])) {
            $lang = $cand;
        }
    }

    // 3) Deteksi otomatis dari browser (Accept-Language)
    if ($lang === '' && isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
        $best    = $default;
        $bestQ   = -1.0;
        $defaultQ = -1.0;
        foreach (explode(',', (string)$_SERVER['HTTP_ACCEPT_LANGUAGE']) as $part) {
            $bits   = explode(';q=', trim($part));
            $code   = strtolower(substr($bits[0], 0, 2));
            $q      = isset($bits[1]) ? (float)$bits[1] : 1.0;
            if ($code === $default) {
                $defaultQ = $q;
            }
            if (isset($supported[$code]) && $q > $bestQ) {
                $best  = $code;
                $bestQ = $q;
            }
        }
        // Bahasa default tetap unggul kalau kualitasnya sama-sama tinggi
        if ($defaultQ >= $bestQ && $defaultQ > 0) {
            $lang = $default;
        } else {
            $lang = $best;
        }
    }

    if ($lang === '') {
        $lang = $default;
    }

    // Simpan pilihan ke cookie (1 tahun) supaya konsisten antar halaman
    if (!headers_sent()) {
        setcookie('vs_lang', $lang, [
            'expires'  => time() + 31536000,
            'path'     => '/',
            'samesite' => 'Lax',
        ]);
    }

    $GLOBALS['VS_CURRENT_LANG'] = $lang;
    return $lang;
}

/** Muat array terjemahan sebuah bahasa (fallback: bahasa default). */
function vs_load_lang($lang)
{
    $lang = (string)$lang;
    if (isset($GLOBALS['VS_TRANSLATIONS'][$lang])) {
        return $GLOBALS['VS_TRANSLATIONS'][$lang];
    }

    $default = $GLOBALS['VS_LANG_DEFAULT'];
    $file    = dirname(__DIR__) . '/lang/' . preg_replace('/[^a-z]/i', '', $lang) . '.php';
    $data    = (is_file($file) && is_array($arr = include $file)) ? $arr : [];

    // Lengkapi kunci yang belum diterjemahkan dengan teks bahasa default
    if ($lang !== $default && is_file(dirname(__DIR__) . '/lang/' . $default . '.php')) {
        $base  = include dirname(__DIR__) . '/lang/' . $default . '.php';
        $data  = array_merge(is_array($base) ? $base : [], $data);
    }

    $GLOBALS['VS_TRANSLATIONS'][$lang] = $data;
    return $data;
}

/**
 * Ambil teks terjemahan berdasarkan kunci.
 * Contoh: t('footer.copy', ['year' => '2026']) — placeholder :year di dalam teks.
 */
function t($key, $vars = [])
{
    static $map = null;
    if ($map === null) {
        $map = vs_load_lang(vs_current_lang());
    }
    $text = isset($map[$key]) ? (string)$map[$key] : (string)$key;
    if (!empty($vars) && is_array($vars)) {
        $replace = [];
        foreach ($vars as $k => $v) {
            $replace[':' . $k] = (string)$v;
        }
        $text = strtr($text, $replace);
    }
    return $text;
}

/** Terjemahan + escape HTML (untuk output teks biasa). */
function te($key, $vars = [])
{
    return htmlspecialchars(t($key, $vars), ENT_QUOTES, 'UTF-8');
}

/**
 * URL dengan prefix bahasa. Contoh (bahasa en):
 *   lang_url('/')            -> https://voidsyntax.my.id/en
 *   lang_url('/artikel/')    -> https://voidsyntax.my.id/en/artikel/
 * Bahasa default tanpa prefix (URL default tanpa prefix).
 */
function lang_url($path = '/')
{
    $lang = vs_current_lang();
    $path = '/' . ltrim((string)$path, '/');
    if ($path === '/') {
        $path = '';
    }
    $prefix = ($lang === $GLOBALS['VS_LANG_DEFAULT']) ? '' : '/' . $lang;
    return SITE_URL . $prefix . $path;
}

/** URL halaman yang sama dalam bahasa tertentu (untuk menu bahasa & hreflang).
 *  SEMUA bahasa memakai prefix eksplisit (/id, /en, /ms) supaya pindah
 *  bahasa SELALU berhasil — termasuk pindah ke Indonesia (dulu tanpa prefix,
 *  sehingga cookie lama menang dan "Indonesia" tidak bisa dipilih). */
function lang_url_for($lang, $path = '/')
{
    $path = '/' . ltrim((string)$path, '/');
    if ($path === '/') {
        $path = '';
    }
    $prefix = '/' . $lang;
    return SITE_URL . $prefix . $path;
}

/** Kode bahasa untuk og:locale (id_ID, en_US, ...). */
function vs_og_locale($lang = null)
{
    $map = ['id' => 'id_ID', 'en' => 'en_US', 'ms' => 'ms_MY'];
    $lang = $lang !== null ? $lang : vs_current_lang();
    return isset($map[$lang]) ? $map[$lang] : 'en_US';
}
