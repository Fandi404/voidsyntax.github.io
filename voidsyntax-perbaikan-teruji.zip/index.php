<?php
/**
 * index.php — HALAMAN UTAMA (tema Cosmic Aurora)
 * Hero + form + 3 kartu fitur + cara pakai + konten SEO + FAQ.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/ads.php';

$pageTitle = t('meta.title_home');
$pageDesc  = t('meta.desc_home');

require_once __DIR__ . '/includes/header.php';
?>
<section class="hero-wrap" id="unduh">
    <h1 class="h1-hero grad-text reveal"><?= t('hero.title') ?></h1>

    <form id="dl-form" class="dl-form" autocomplete="off">
        <div class="form-row">
            <div class="input-wrap">
                <input type="text" id="tiktok-url" name="url" placeholder="<?= te('form.placeholder') ?>" required>
                <button type="button" class="paste-btn" id="paste-btn" title="<?= te('form.paste') ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect></svg>
                </button>
            </div>
            <button type="submit" id="dl-btn" class="btn-grad"><?= te('form.button') ?></button>
        </div>
    </form>

    <p id="status" class="status" role="status"></p>
    <div id="result" class="result" hidden></div>
    <?php render_ad_slot('below_result'); ?>

    <p class="lead"><?= t('hero.lead') ?></p>

    <div class="hero-chips reveal">
        <span class="chip"><span class="ico">🎬</span> <?= te('hero.chip1') ?></span>
        <span class="chip"><span class="ico">🎵</span> <?= te('hero.chip2') ?></span>
        <span class="chip"><span class="ico">🗂️</span> <?= te('hero.chip3') ?></span>
        <span class="chip"><span class="ico">🌏</span> <?= te('hero.chip4') ?></span>
    </div>

    <div class="cards-3">
        <?php foreach ($SITE_FEATURES as $f): ?>
        <div class="feature-card reveal">
            <h2><?= e($f['title']) ?> <span class="arrow">→</span></h2>
            <p><?= e($f['desc']) ?></p>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ===== Cara pakai ===== -->
    <section id="how-to-use" class="section reveal" style="width:100%">
        <h2 class="h2-grad"><?= t('howto.heading') ?></h2>
        <div class="steps-grid">
            <?php for ($i = 1; $i <= 4; $i++): ?>
            <div class="step reveal">
                <div class="step-num"><?= $i ?></div>
                <h3><?= te('howto.' . $i . '.title') ?></h3>
                <p><?= te('howto.' . $i . '.desc') ?></p>
            </div>
            <?php endfor; ?>
        </div>
        <!-- Bagian Tips Pro telah dihapus sesuai permintaan -->
    </section>

    <!-- ===== FAQ ===== -->
    <section id="faq" class="section reveal" style="width:100%">
        <h2 class="h2-grad"><?= t('faq.heading') ?></h2>
        <div class="faq-list">
            <?php foreach ($SITE_FAQ as $q): ?>
            <div class="faq-item">
                <details>
                    <summary>
                        <h3 style="margin:0;font-size:1.15rem"><?= e($q['q']) ?></h3>
                        <svg class="chev" width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </summary>
                    <div class="a" style="margin-top:10px"><?= e($q['a']) ?></div>
                </details>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
</section>

<!-- ===== AUTO PLAY MUSIK RANDOM INDONESIA SLOW — HANYA BERANDA ===== -->
<div id="audio-widget" style="position:fixed;bottom:20px;left:20px;z-index:9999;background:rgba(15,23,42,0.9);backdrop-filter:blur(10px);border:1px solid rgba(0,210,255,0.3);padding:8px 14px;border-radius:30px;display:flex;align-items:center;gap:10px;color:#fff;font-size:12px;box-shadow:0 4px 20px rgba(0,0,0,0.4);">
    <span id="bgm-icon" style="font-size:14px;">🎵</span>
    <span id="bgm-title" style="max-width:130px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500;">Memuat Lagu...</span>
    <button id="bgm-btn" onclick="toggleBGM()" style="background:linear-gradient(135deg, #00d2ff, #3a7bd5);border:none;color:#fff;padding:4px 12px;border-radius:15px;cursor:pointer;font-weight:bold;font-size:11px;transition:0.3s;">Memuat...</button>
</div>

<script>
(function() {
    // 1. Cek apakah pengguna berada di Beranda (Dibuat lebih fleksibel)
    const path = window.location.pathname;
    const isHomePage = path === '/' || path.includes('index.php') || path === '';
    
    if (!isHomePage) {
        const widget = document.getElementById('audio-widget');
        if (widget) widget.remove();
        return;
    }

    // 2. Playlist Lagu Indonesia Slow (Data Asli Anda Dipertahankan)
    const playlistIndo = [
        { 
            name: "Budi Doremi - Mesin Waktu", 
            url: "/audio/mesin-waktu.mp3" 
        },
        { 
            name: "Andmesh - Hanya Rindu", 
            url: "/audio/hanya-rindu.mp3" 
        },
        { 
            name: "Virgoun - Bukti", 
            url: "/audio/bukti.mp3"  
        }
    ];

    // 3. Ambil 1 Lagu Secara Random
    const currentTrack = playlistIndo[Math.floor(Math.random() * playlistIndo.length)];
    const audio = new Audio();
    audio.src = currentTrack.url;
    audio.loop = true;
    audio.volume = 0.35; // Volume dipasang 35% agar tidak merusak telinga

    const btn = document.getElementById('bgm-btn');
    const title = document.getElementById('bgm-title');
    if (title) title.innerText = currentTrack.name;

    let isUserPaused = false;
    let isInteractionSetup = false;

    // 4. Fungsi Pemutar Musik yang Aman dari Kebijakan Autoplay Browser
    function playAudio() {
        if (isUserPaused || !audio.src || audio.error) return;
        
        const playPromise = audio.play();
        if (playPromise !== undefined) {
            playPromise.then(() => {
                if (btn && !audio.error) btn.innerText = "Pause";
            }).catch((error) => {
                // Autoplay diblokir, tunggu interaksi pengguna
                if (btn && !audio.error) btn.innerText = "Play";
                setupUserInteraction();
            });
        }
    }

    function setupUserInteraction() {
        if (isInteractionSetup) return;
        isInteractionSetup = true;

        const triggerPlay = () => {
            if (!isUserPaused && !audio.error) {
                audio.play().then(() => {
                    if (btn) btn.innerText = "Pause";
                }).catch(e => console.log("Menunggu file audio selesai dimuat..."));
            }
            // Hapus event listener agar tidak berat
            document.removeEventListener('click', triggerPlay);
            document.removeEventListener('touchstart', triggerPlay);
            document.removeEventListener('scroll', triggerPlay);
        };

        // Tunggu klik atau sentuhan pertama dari pengunjung web
        document.addEventListener('click', triggerPlay, { once: true });
        document.addEventListener('touchstart', triggerPlay, { once: true });
        document.addEventListener('scroll', triggerPlay, { once: true });
    }

    // 5. Tombol Manual Play / Pause
    window.toggleBGM = function() {
        if (audio.error) return; // Jangan lakukan apa-apa jika link lagunya error

        if (audio.paused) {
            isUserPaused = false;
            audio.play().then(() => {
                if (btn) btn.innerText = "Pause";
            }).catch(e => console.log("Buffering audio dari archive.org..."));
        } else {
            isUserPaused = true;
            audio.pause();
            if (btn) btn.innerText = "Play";
        }
    };

    // 6. OTOMATIS PAUSE saat pindah tab / minimize browser
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            audio.pause();
        } else {
            if (!isUserPaused) playAudio();
        }
    });

    // 7. OTOMATIS PAUSE saat window kehilangan fokus (buka tab/aplikasi lain)
    window.addEventListener('blur', function() {
        if (!audio.paused) audio.pause();
    });

    window.addEventListener('focus', function() {
        if (!isUserPaused && !document.hidden) playAudio();
    });

    // 8. OTOMATIS MATI TOTAL saat pengguna pindah halaman
    window.addEventListener('beforeunload', function() {
        audio.pause();
        audio.src = '';
    });

    // Jalankan saat halaman siap
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        playAudio();
    } else {
        document.addEventListener('DOMContentLoaded', playAudio);
    }
})();
</script>

<?php render_donations(); ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>