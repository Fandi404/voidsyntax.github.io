<?php
/**
 * kontak.php — Halaman Kontak + DMCA (tema Cosmic Aurora)
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle     = t('page.contact.title');
$pageDesc      = t('page.contact.desc');
$canonicalPath = '/kontak.php';
$noFaqSchema   = true;

require_once __DIR__ . '/includes/header.php';
?>
<div class="page-head">
    <h1 class="grad-text"><?= t('contact.heading') ?></h1>
    <p><?= t('contact.intro') ?></p>
</div>

<section class="prose-section" style="margin-top:32px">
    <div class="space">
        <h3><?= t('contact.channels') ?></h3>
        <ul>
            <li>💬 <strong>WhatsApp:</strong> <a href="https://wa.me/6287711180777" target="_blank" rel="noopener">087711180777</a></li>
            <li>✉️ <strong>Email:</strong> <a href="mailto:afandiae01@gmail.com">afandiae01@gmail.com</a></li>
            <li>🎵 <strong>TikTok:</strong> <a href="https://www.tiktok.com/@_fandi96" target="_blank" rel="noopener">@_fandi96</a></li>
        </ul>

        <div id="dmca">
            <h3><?= t('contact.dmca_h') ?></h3>
            <p><?= t('contact.dmca_p') ?></p>
        </div>

        <h3><?= t('contact.privacy_h') ?></h3>
        <p><?= t('contact.privacy_p') ?></p>
    </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
