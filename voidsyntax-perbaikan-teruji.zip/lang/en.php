<?php
/**
 * lang/en.php — TERJEMAHAN (v3, tema Cosmic Aurora)
 * Tambah bahasa baru: salin file ini jadi lang/xx.php lalu terjemahkan isinya.
 * Placeholder :seperti_ini diganti saat pemanggilan t("kunci", [...]).
 */
return array (
  'meta.keywords' => 'tiktok downloader, download tiktok video, tiktok no watermark, tiktok 4k, tiktok mp3, douyin downloader, douyin no watermark, voidsyntax',
  'meta.title_home' => 'Download TikTok Videos HD 1080p & 4K Without Watermark Fast',
  'meta.desc_home' => 'Download TikTok videos in Full HD 1080p and 4K without watermark for free. Super-fast multi-server processing for phones, tablets, and PCs. Douyin & MP3 supported.',
  'nav.home' => 'Home',
  'nav.articles' => 'Articles',
  'nav.features' => 'Features',
  'nav.howto' => 'How to Use',
  'nav.faq' => 'FAQ',
  'lang.label' => 'Language',
  'hero.title' => 'Download TikTok Videos Without Watermark',
  'hero.lead' => 'Download TikTok &amp; Douyin videos in Full HD 1080p and 4K without watermark for free. Super-fast multi-server processing for phones, tablets, and PCs.',
  'hero.placeholder' => 'Paste a TikTok / Douyin link (or the full share text)...',
  'hero.submit' => 'Get Video',
  'hero.hint' => 'Supports short links <code>vm.tiktok.com</code>, <code>vt.tiktok.com</code> &amp; <code>v.douyin.com</code> • Auto provider (automatic fallback)',
  'status.processing' => 'Processing...',
  'status.fetching' => 'Fetching video data...',
  'status.network_error' => 'A network error occurred. Check your connection and try again.',
  'result.no_title' => '(Untitled)',
  'result.seconds' => 'sec',
  'result.via' => 'via',
  'result.source' => 'Source',
  'btn.hd' => '⬇️ Download Full HD (1080p/4K)',
  'btn.wm' => '💧 Download With Watermark',
  'btn.mp3' => '🎵 Download MP3 Audio Only',
  'platform.tiktok' => 'TikTok',
  'platform.douyin' => 'Douyin',
  'app.title' => 'Download the Android App',
  'app.desc' => 'The app version of this website — install it on your phone, no browser needed. <strong>Version 1.0.0</strong> • <strong>~0.8 MB</strong> • <strong>Android 8.0+</strong> • Free.',
  'app.download_apk' => 'Download APK',
  'app.install_note' => 'After downloading: open the APK file → allow "install from unknown sources" → Install.',
  'app.ios_note' => '🍎 <strong>Android only (8.0+).</strong> iPhone/iPad (iOS) users: APK files cannot be installed on iOS. Instead, open this site in <strong>Safari</strong> → tap the <strong>Share</strong> button (box + arrow icon) → <strong>"Add to Home Screen"</strong> → the app icon appears on your home screen like a regular app.',
  'donate.title' => '❤️ Support Us',
  'donate.desc' => 'This website is <strong>free, no login, and unlimited</strong>. If it helps you, support us to keep it online &amp; growing — via <strong>Saweria</strong> or <strong>PayPal</strong>. Thank you! 🙏',
  'donate.qr_alt' => 'Saweria QR Code — scan to donate',
  'donate.wallet_by' => 'a.n. Fandi — send any amount you like',
  'donate.wallet_note' => 'Manual transfer (without Saweria)? After transferring, confirm via WhatsApp:',
  'donate.copy' => '📋 Copy',
  'donate.copied' => '✅ Copied',
  'history.heading' => '🕘 Recently Downloaded',
  'faq.heading' => 'Frequently Asked Questions About TikTok Video Downloading',
  'faq.1.q' => 'Can I download TikTok videos in 4K or 1080p HD quality?',
  'faq.1.a' => 'Yes! Our downloader automatically detects the highest resolution uploaded by the creator, including Full HD 1080p and 4K UHD, and provides it for watermark-free download.',
  'faq.2.q' => 'How do I remove the watermark from TikTok videos?',
  'faq.2.a' => 'Simply copy the TikTok video link, paste it into the input box on our site, and click Download. Our system will process and serve the original MP4 file completely free of the TikTok logo.',
  'faq.3.q' => 'Is this TikTok video download service 100% free?',
  'faq.3.a' => 'Yes, our TikTok video downloader is completely free with unlimited downloads and no subscription or account required.',
  'faq.4.q' => 'How do I copy a TikTok video link on my phone?',
  'faq.4.a' => 'Open the TikTok app, open the video you want, tap the \'Share\' button at the bottom right, then select \'Copy Link\'.',
  'faq.5.q' => 'Can I download TikTok videos on iPhone / iPad (iOS)?',
  'faq.5.a' => 'Absolutely. Open the Safari browser on your iPhone or iPad, visit our site, paste the video link, then click the download button to save it straight to your Photos or Files app.',
  'faq.6.q' => 'Can I download only the sound or MP3 music from a video?',
  'faq.6.a' => 'Yes. After pasting the video link, you can choose the \'Download MP3 Audio Only\' option to save just the music track in crisp audio quality.',
  'faq.7.q' => 'Is there a limit on how many videos I can download per day?',
  'faq.7.a' => 'There is no limit. You can download as many TikTok videos as you want, anytime.',
  'faq.8.q' => 'Is it safe to use this TikTok video downloader?',
  'faq.8.a' => 'Very safe. We do not keep copies of your videos, do not log personal data, and the entire process is protected by HTTPS encryption.',
  'footer.copy' => '© :year :name — Download TikTok & Douyin Videos Without Watermark for Free',
  'footer.credit_label' => 'Created by',
  'footer.apk' => 'Download APK',
  'footer.disclaimer' => 'This site is not affiliated with TikTok or Douyin. Use it only for your own videos or reasonable personal use.',
  'dl.err_invalid_url' => 'Invalid URL. Paste a TikTok or Douyin video link. Example: https://www.tiktok.com/@username/video/1234567890123',
  'dl.err_fetch' => 'Failed to fetch video data. Please try again in a moment.',
  'dl.err_not_available' => 'This file is not available for the selected download type.',
  'dl.err_stream' => 'Failed to download file',
  'err.all_providers' => 'All providers failed to process this video. Try again in a moment or try another video.',
  'api.err_required' => 'The "url" parameter is required.',
  'api.example' => 'example',
  'artikel.index.title' => 'Articles & Guides',
  'artikel.index.desc' => 'A collection of articles and guides: how to download TikTok videos without watermark, how to save TikTok audio as MP3, and how to download TikTok without an app.',
  'artikel.index.heading' => '📚 Articles &amp; Guides',
  'article.meta_line' => '📅 Published October 8, 2026 • ✍️ by Fandi • ⏱️ 3 min read',
  'article.cta_free' => 'Free, no login, unlimited.',
  'article.open_tool' => '⬇️ Open VoidSyntax Downloader',
  'article.a1.list_title' => 'How to Download TikTok Videos Without Watermark on Your Phone (Free, No App)',
  'article.a1.list_desc' => 'A complete guide to saving TikTok videos without watermark straight from your phone browser — no app install, no login, free, HD quality.',
  'article.a1.title' => 'How to Download TikTok Videos Without Watermark on Your Phone (Free, No App, 2026)',
  'article.a1.desc' => 'Complete guide to downloading TikTok videos without watermark on Android & iPhone: no app, no login, free, HD quality. Updated 2026.',
  'article.a1.body' => '<h1>How to Download TikTok Videos Without Watermark on Your Phone (Free, No App, 2026)</h1>
        <p class="article-meta">:meta_line</p>
        <p><strong>Downloading TikTok videos without watermark</strong> is actually easy — no need to install extra apps full of ads. Just open your phone browser, paste the TikTok video link, and the video is saved in HD without watermark. In this article we explain the full steps using <strong>VoidSyntax Downloader</strong> (voidsyntax.my.id).</p>
        <h2>Why download videos without watermark?</h2>
        <p>The watermark (TikTok logo + username) cannot be removed from within the TikTok app. Videos with watermarks also look messy when re-edited or archived. With a downloader, you get the original watermark-free video file straight from TikTok servers.</p>
        <h2>Steps to download TikTok videos without watermark</h2>
        <ol>
            <li>Open the <strong>TikTok</strong> app and find the video you want to save.</li>
            <li>Tap the <strong>Share</strong> button → choose <strong>Copy Link</strong>.</li>
            <li>Open a browser (Chrome/Safari) → visit <strong>voidsyntax.my.id</strong>.</li>
            <li>Paste the link into the box → click <strong>Get Video</strong>.</li>
            <li>Wait for the thumbnail &amp; video info → click <strong>HD No Watermark</strong>.</li>
            <li>The video downloads instantly — check your <strong>Downloads</strong> folder.</li>
        </ol>
        <blockquote>💡 <strong>Tip:</strong> this also works with short links <code>vm.tiktok.com</code> / <code>vt.tiktok.com</code> — they are resolved automatically. On iPhone, install the "app" via Safari → Share → <strong>Add to Home Screen</strong>. Or grab our <a href=":apk_url">Android app (APK)</a>.</blockquote>
        <h2>Things to keep in mind</h2>
        <ul>
            <li>Videos must be <strong>public</strong> — private videos cannot be downloaded.</li>
            <li>Respect creators\' copyrights: use for <strong>personal archiving</strong>, don\'t re-upload without permission.</li>
            <li>Video quality follows the original upload quality (can be HD).</li>
            <li>An internet connection is required — the process takes just seconds.</li>
        </ul>
        <div class="card article-cta">
            <h2>Ready to Download?</h2>
            <p>:cta_free</p>
            <a class="btn btn-primary" href=":home_url">:open_tool</a>
        </div>
        <h2>Common questions</h2>
        <p><strong>Does it work on iPhone?</strong> Yes — open the site in Safari, or install the app version via Add to Home Screen.</p>
        <p><strong>Do I need an app?</strong> No. Everything runs in the browser — on Android phones, iPhones, and PCs.</p>
        <p><strong>How long does it take?</strong> Just a few seconds, depending on video size and connection.</p>',
  'article.a2.list_title' => 'How to Download TikTok Audio as MP3 on Phone & PC (Free)',
  'article.a2.list_desc' => 'Extract audio from TikTok videos and save it as an MP3 file — works on Android, iPhone, and computers.',
  'article.a2.title' => 'How to Download TikTok Audio as MP3 on Phone & PC (Free, 2026)',
  'article.a2.desc' => 'Guide to downloading TikTok audio as MP3 files on Android, iPhone, and PC — free, no app, original audio quality.',
  'article.a2.body' => '<h1>How to Download TikTok Audio as MP3 on Phone &amp; PC (Free, 2026)</h1>
        <p class="article-meta">:meta_line</p>
        <p>We often find TikTok videos with <strong>great songs or sounds</strong> — and we only need the audio. Good news: you can <strong>download TikTok audio as MP3</strong> easily, for free, with no extra apps. The result plays anywhere: phone, PC, or Bluetooth speaker.</p>
        <h2>Why extract audio as MP3?</h2>
        <ul>
            <li><strong>Saves storage</strong> — MP3 files are much smaller than videos.</li>
            <li><strong>Plays anywhere</strong> — music, podcasts, or sound collections.</li>
            <li><strong>No video watermark</strong> — you keep the pure audio.</li>
        </ul>
        <h2>Steps to download TikTok audio as MP3</h2>
        <ol>
            <li>Open the <strong>TikTok</strong> app → find the video with the audio you want.</li>
            <li>Tap <strong>Share</strong> → <strong>Copy Link</strong>.</li>
            <li>Open a browser → visit <strong>voidsyntax.my.id</strong>.</li>
            <li>Paste the link → click <strong>Get Video</strong> → wait for the video info.</li>
            <li>Click the <strong>🎵 MP3 Audio</strong> button.</li>
            <li>The MP3 downloads instantly — check your <strong>Downloads</strong> folder.</li>
        </ol>
        <blockquote>💡 <strong>Tip:</strong> this also works with <code>vm.tiktok.com</code> short links and Douyin links. Audio quality follows the original video. On iPhone: open in Safari (or install the app via Add to Home Screen).</blockquote>
        <h2>Things to keep in mind</h2>
        <ul>
            <li>The audio you extract belongs to its original creator — use it for <strong>personal collections</strong>.</li>
            <li>For copyrighted music, avoid re-uploading or using it commercially without permission.</li>
            <li>Videos must be public — private videos cannot be processed.</li>
        </ul>
        <div class="card article-cta">
            <h2>Try It Now</h2>
            <p>:cta_free</p>
            <a class="btn btn-primary" href=":home_url">🎵 Open VoidSyntax Downloader</a>
        </div>',
  'article.a3.list_title' => 'How to Download TikTok Videos Without an App & Without Login',
  'article.a3.list_desc' => 'No bloated third-party apps with ads and excessive permissions — just open a browser, paste the link, and download.',
  'article.a3.title' => 'How to Download TikTok Videos Without an App & Without Login (Straight from the Browser, 2026)',
  'article.a3.desc' => 'Download TikTok videos without an app and without logging in — straight from your phone or PC browser. Free, fast, and private.',
  'article.a3.body' => '<h1>How to Download TikTok Videos Without an App &amp; Without Login (Straight from the Browser, 2026)</h1>
        <p class="article-meta">:meta_line</p>
        <p>Many people search for <strong>how to download TikTok videos without an app</strong> — and it really is the most practical way. Third-party downloader apps are often full of ads, demand excessive permissions (contacts, storage, even SMS), and sometimes don\'t work at all. The solution: use a downloader website that runs straight in your browser.</p>
        <h2>Advantages of downloading via browser (no app)</h2>
        <ul>
            <li><strong>No install</strong> — doesn\'t eat up your phone storage.</li>
            <li><strong>No login</strong> — no registration or account needed.</li>
            <li><strong>Free &amp; unlimited</strong> — download as much as you want.</li>
            <li><strong>Privacy protected</strong> — the link you paste is processed on the fly and never stored on the server.</li>
            <li><strong>Works on every device</strong> — Android phones, iPhones, PCs, tablets.</li>
        </ul>
        <h2>Steps (Phone &amp; PC)</h2>
        <ol>
            <li>Open <strong>TikTok</strong> → find a video → tap <strong>Share</strong> → <strong>Copy Link</strong>.</li>
            <li>Open a browser (Chrome, Safari, Firefox, Edge) → visit <strong>voidsyntax.my.id</strong>.</li>
            <li>Paste the link → click <strong>Get Video</strong>.</li>
            <li>Pick what you need: <strong>HD No Watermark</strong>, <strong>With Watermark</strong>, or <strong>MP3 Audio</strong>.</li>
            <li>Done — the file is saved in your Downloads folder.</li>
        </ol>
        <blockquote>💡 <strong>Tip:</strong> if you download often, install the "app" on your phone: Android users can <a href=":apk_url">install the APK directly</a>, iPhone users can Add to Home Screen via Safari — it feels like a real app, without the Play Store/App Store.</blockquote>
        <h2>In short</h2>
        <p>No app, no login, no hassle — open a browser, paste the link, download. That simple.</p>
        <div class="card article-cta">
            <h2>Start Downloading</h2>
            <p>:cta_free</p>
            <a class="btn btn-primary" href=":home_url">:open_tool</a>
        </div>',
  'nav.contact' => 'Contact',
  'nav.tiktok_dl' => 'TikTok Downloader',
  'nav.douyin_dl' => 'Douyin Downloader',
  'nav.sub.tiktok_video' => 'Download TikTok Video',
  'nav.sub.tiktok_mp3' => 'Download TikTok MP3',
  'nav.sub.tiktok_slideshow' => 'Download TikTok Slideshow',
  'nav.sub.tiktok_story' => 'Download TikTok Story',
  'nav.sub.articles' => 'Articles & Guides',
  'nav.sub.douyin_video' => 'Download Douyin Video',
  'nav.sub.douyin_audio' => 'Download Douyin MP3 Audio',
  'nav.sub.douyin_photo' => 'Download Douyin Photos',
  'nav.sub.douyin_slideshow' => 'Download Douyin Slideshow',
  'form.placeholder' => 'Paste a TikTok / Douyin link here…|Example: https://vt.tiktok.com/ZSxxxx/|Full share text also works!',
  'form.button' => 'Download Video',
  'form.loading' => 'Processing video...',
  'form.fetching' => 'Fetching video data...',
  'form.paste' => 'Paste',
  'btn.sd' => '⬇️ Download MP4 (No Watermark)',
  'btn.zip' => '🗂️ Download All Photos (ZIP)',
  'feature1.title' => 'No Watermark & Clean Logo',
  'feature1.desc' => 'Perfectly remove the TikTok logo and username overlay to produce clean, professional MP4 video files.',
  'feature2.title' => 'Full HD 1080p & 4K Quality',
  'feature2.desc' => 'Get the highest resolution from the source video up to 1080p Full HD and 4K UHD with maximum bitrate and crystal-clear original audio.',
  'feature3.title' => 'Super-Fast Multi-Server',
  'feature3.desc' => 'High-speed server clusters process and convert TikTok & Douyin video links instantly — no queues, no login.',
  'howto.heading' => 'How to Download TikTok Videos Without Watermark in HD',
  'howto.1.title' => 'Copy the TikTok Video Link',
  'howto.1.desc' => 'Open the TikTok app, pick your favorite video, tap the \'Share\' button, then select \'Copy Link\'.',
  'howto.2.title' => 'Paste the URL into the Downloader',
  'howto.2.desc' => 'Open our downloader site and paste the copied link into the search box at the top.',
  'howto.3.title' => 'Choose HD / 4K Quality Options',
  'howto.3.desc' => 'Pick the download resolution you want (Full HD 1080p, 4K, or the MP3 audio format without watermark).',
  'howto.4.title' => 'Save the Video to Your Device',
  'howto.4.desc' => 'Click the download button and the high-quality MP4 video file will be saved straight to your phone gallery or laptop folder.',
  'tips.title' => 'Pro Tips for Downloading TikTok Videos in HD',
  'tips.1' => 'Use the \'Copy Link\' button directly from the TikTok app to make sure the URL is valid and complete.',
  'tips.2' => 'Choose the \'Download Full HD\' option to get 1080p or 4K video resolution with the best quality.',
  'tips.3' => 'Our servers detect and remove the watermark logo automatically without reducing fps or color sharpness.',
  'tips.4' => 'Fully compatible with all browsers without needing to install third-party apps or browser plugins.',
  'tips.5' => 'Use the MP3 audio download if you only want the background music or viral sound from the TikTok video.',
  'seo.heading' => 'TikTok Video Downloader Without Watermark in Full HD 1080p &amp; 4K',
  'seo.intro' => 'Enjoying TikTok videos anywhere without watermark logo interference is now easier. Our TikTok Video Downloader provides a free, fast online solution to download any TikTok video in the highest resolution from Full HD 1080p up to 4K UHD — no visual compression, watermark-free. It also supports videos, photos, and audio from Douyin (抖音).',
  'seo.why' => '<h3>Why Do You Need a TikTok Video Downloader Without Watermark?</h3><p>The official TikTok app embeds a floating username watermark when you save videos directly. This often covers important details and lowers the aesthetic quality when you want to archive or re-share. Our downloader removes that watermark completely and extracts the pure high-resolution MP4 video file straight from the source servers.</p>',
  'seo.best' => '<h3>Main Advantages of Our TikTok Video Downloader</h3>',
  'seo.f1' => '<h4>100% TikTok Logo Watermark-Free</h4><p>Our tool precisely removes all watermarks, bouncing logos, and account names without leaving blur or crop marks.</p><ul><li>Clean videos with no TikTok logo in the corner</li><li>Original video quality with no sharpness loss</li><li>Perfect for presentations, archives, and creative content</li></ul>',
  'seo.f2' => '<h4>Full HD 1080p &amp; 4K Quality Support</h4><p>We preserve the original video resolution, letting you download in the highest quality supported by the source video.</p><ul><li>Full HD (1080p) and 4K UHD resolution when available from the creator</li><li>Maximum visual clarity with high bitrate</li><li>Original MP3 audio tracks stay crisp and intact</li></ul>',
  'seo.f3' => '<h4>Super-Fast Multi-Server Infrastructure</h4><p>Powered by high-speed global server clusters that guarantee lightning-fast processing times in seconds.</p><ul><li>Instant conversion and download with no lag</li><li>No daily download quota limits</li><li>No account registration or login — privacy stays protected</li></ul>',
  'seo.millions' => '<h3>Why Millions of Users Choose Our Service</h3><p>Security, speed, and user convenience are our core foundations. Here is why users stay loyal to our downloader:</p><ul><li>Strict privacy policy: we never store your personal data or download history</li><li>Bank-grade encrypted HTTPS connections</li><li>Regularly updated to follow TikTok updates</li><li>Free with no subscription fees, extra watermarks, or trap ads</li><li>Reliable servers with 99.9% uptime ready anytime</li></ul>',
  'seo.ethics' => '<h3>Ethics &amp; Copyright Guidelines</h3><p>We encourage all users to use this tool responsibly in accordance with applicable copyright law:</p><ul><li>Use downloaded results solely for personal consumption and archiving</li><li>Always respect the copyrights and hard work of content creators</li><li>Get written permission before republishing other people\'s content</li><li>Comply with the TikTok community terms of service</li></ul>',
  'seo.cta' => '<h3>Start Downloading TikTok Videos in 4K &amp; HD Now</h3><p>Save your favorite TikTok videos in Full HD 1080p and 4K without watermark right now. Paste the video link in the box above and enjoy instant free downloads!</p>',
  'faq.9.q' => 'Can I download Douyin (抖音) videos and photos?',
  'faq.9.a' => 'Yes! Paste a Douyin video link (www.douyin.com/video/... or v.douyin.com/...) — the system detects Douyin automatically. For photo/slideshow posts there is a "Download All Photos (ZIP)" button.',
  'faq.10.q' => 'How do I change the website language?',
  'faq.10.a' => 'Click the language menu (ID/EN) at the top right of the page and pick the language you want. Your choice is remembered automatically for future visits.',
  'page.howto.title' => 'How to Use — Download TikTok Videos Without Watermark Guide',
  'page.howto.desc' => 'Step-by-step guide to downloading TikTok videos without watermark in HD: copy the link, paste, choose quality, save.',
  'page.faq.title' => 'FAQ — TikTok Video Downloader Common Questions',
  'page.faq.desc' => 'Answers to common questions about downloading TikTok videos without watermark, 4K/HD quality, MP3, Douyin, and security.',
  'page.contact.title' => 'Contact & DMCA — VoidSyntax Downloader',
  'page.contact.desc' => 'Contact the VoidSyntax Downloader team: WhatsApp, email, TikTok. DMCA & privacy policy.',
  'page.app.title' => 'Download the Android App (APK) — VoidSyntax Downloader',
  'page.app.desc' => 'Get the VoidSyntax Downloader Android app: free, lightweight, no annoying ads. Or install as a PWA on iPhone.',
  'contact.heading' => 'Contact Us',
  'contact.intro' => 'Have questions, suggestions, or reports? We are here to help. For content removal (DMCA), see the dedicated section below.',
  'contact.channels' => 'Social Media & Contact',
  'contact.dmca_h' => 'DMCA Reports',
  'contact.dmca_p' => 'We respect creators\' copyrights. If you own content and feel it is being infringed through our service, send a DMCA report containing: (1) the infringing content URL, (2) proof of ownership, (3) your contact details, to afandiae01@gmail.com or WhatsApp 087711180777. Reports are processed within 1-3 business days.',
  'contact.privacy_h' => 'Privacy',
  'contact.privacy_p' => 'We never store your links, personal data, or download history. Everything is processed instantly and protected by HTTPS encryption. Your download history stays in your own browser (localStorage).',
  'app.install_h' => 'How to Install the APK',
  'app.ios_h' => 'iPhone / iPad (iOS) Users',
  'footer.about' => 'VoidSyntax is a free online service that lets you download TikTok & Douyin videos without watermark. We are not affiliated with TikTok or Douyin.',
  'footer.quick' => 'Quick Links',
  'footer.tools' => 'Download Tools',
  'footer.social' => 'Social Media',
  'app.update_available' => '✨ Update available! Loading the new version…',
  'hero.badge' => '⚡ Auto-provider • No watermark • 100% free',
  'hero.chip1' => 'HD 1080p/4K quality',
  'hero.chip2' => 'MP3 audio',
  'hero.chip3' => 'Slideshow to ZIP',
  'hero.chip4' => 'TikTok & Douyin',
  'app.auto_h' => '🔄 Automatic Updates',
  'app.auto_note' => 'This app and site are always connected to the latest server version. When we ship new features, you will see an \"Update available\" notification and the app loads the newest version automatically — no need to reinstall the APK.',
  'paste_hint' => 'Press Ctrl+V on your keyboard, or long-press the box and choose Paste.',
);
