<?php
/**
 * lang/id.php — TERJEMAHAN (v3, tema Cosmic Aurora)
 * Tambah bahasa baru: salin file ini jadi lang/xx.php lalu terjemahkan isinya.
 * Placeholder :seperti_ini diganti saat pemanggilan t("kunci", [...]).
 */
return array (
  'meta.keywords' => 'download tiktok, tiktok downloader, tiktok tanpa watermark, download video tiktok, tiktok mp3, tiktok 4k, download douyin, douyin tanpa watermark, voidsyntax',
  'meta.title_home' => 'Download Video TikTok HD 1080p & 4K Tanpa Watermark Cepat',
  'meta.desc_home' => 'Download video TikTok kualitas Full HD 1080p dan 4K tanpa watermark gratis. Pemrosesan multi-server super cepat untuk HP, tablet, dan PC. Support Douyin & MP3.',
  'nav.home' => 'Beranda',
  'nav.articles' => 'Artikel',
  'nav.features' => 'Fitur',
  'nav.howto' => 'Cara Penggunaan',
  'nav.faq' => 'FAQ',
  'lang.label' => 'Bahasa',
  'hero.title' => 'Download Video TikTok Tanpa Watermark',
  'hero.lead' => 'Download video TikTok &amp; Douyin kualitas Full HD 1080p dan 4K tanpa watermark gratis. Pemrosesan multi-server super cepat untuk HP, tablet, dan PC.',
  'hero.placeholder' => 'Tempel link TikTok / Douyin (atau teks share utuh)...',
  'hero.submit' => 'Ambil Video',
  'hero.hint' => 'Mendukung link pendek <code>vm.tiktok.com</code>, <code>vt.tiktok.com</code> &amp; <code>v.douyin.com</code> • Auto provider (fallback otomatis)',
  'status.processing' => 'Memproses...',
  'status.fetching' => 'Mengambil data video...',
  'status.network_error' => 'Terjadi kesalahan jaringan. Periksa koneksi lalu coba lagi.',
  'result.no_title' => '(Tanpa judul)',
  'result.seconds' => 'detik',
  'result.via' => 'via',
  'result.source' => 'Sumber',
  'btn.hd' => '⬇️ Download Full HD (1080p/4K)',
  'btn.wm' => '💧 Download Dengan Watermark',
  'btn.mp3' => '🎵 Download Audio MP3 Saja',
  'platform.tiktok' => 'TikTok',
  'platform.douyin' => 'Douyin',
  'app.title' => 'Download Aplikasi Android',
  'app.desc' => 'Versi aplikasi dari website ini — install langsung di HP, tanpa browser. <strong>Versi 1.0.0</strong> • <strong>± 0,8 MB</strong> • <strong>Android 8.0+</strong> • Gratis.',
  'app.download_apk' => 'Download APK',
  'app.install_note' => 'Setelah download: buka file APK → izinkan "install dari sumber tidak dikenal" → Install.',
  'app.ios_note' => '🍎 <strong>Khusus Android (8.0+).</strong> Pengguna iPhone/iPad (iOS): file APK tidak bisa diinstal di iOS. Caranya: buka site ini di <strong>Safari</strong> → tap tombol <strong>Share</strong> (ikon kotak + panah) → <strong>"Add to Home Screen"</strong> → ikon aplikasi muncul di layar utama, sama seperti aplikasi biasa.',
  'donate.title' => '❤️ Dukung Kami',
  'donate.desc' => 'Website ini <strong>gratis, tanpa login, dan tanpa batasan</strong>. Kalau terbantu, dukung kami agar terus online &amp; berkembang — lewat <strong>Saweria</strong> atau <strong>PayPal</strong>. Terima kasih! 🙏',
  'donate.qr_alt' => 'QR Code Saweria — scan untuk donasi',
  'donate.wallet_by' => 'a.n. Fandi — kirim sesuai keinginan (bebas nominal)',
  'donate.wallet_note' => 'Transfer manual (tanpa Saweria)? Setelah transfer, konfirmasi via WhatsApp:',
  'donate.copy' => '📋 Salin',
  'donate.copied' => '✅ Tersalin',
  'history.heading' => '🕘 Terakhir Diunduh',
  'faq.heading' => 'Pertanyaan Umum Tentang Pengunduhan Video TikTok',
  'faq.1.q' => 'Apakah saya bisa men-download video TikTok dalam kualitas 4K atau 1080p HD?',
  'faq.1.a' => 'Ya! Pengunduh kami secara otomatis mendeteksi resolusi tertinggi yang diunggah oleh kreator, termasuk kualitas Full HD 1080p dan 4K UHD, lalu menyediakannya untuk diunduh tanpa watermark.',
  'faq.2.q' => 'Bagaimana cara menghilangkan watermark dari video TikTok?',
  'faq.2.a' => 'Cukup salin link video TikTok, tempelkan ke kolom input di situs kami, lalu klik Download. Sistem kami akan memproses dan menyajikan file MP4 asli yang sepenuhnya bebas dari logo TikTok.',
  'faq.3.q' => 'Apakah layanan download video TikTok ini 100% gratis?',
  'faq.3.a' => 'Ya, pengunduh video TikTok kami sepenuhnya gratis tanpa batasan jumlah unduhan dan tanpa memerlukan biaya langganan atau pembuatan akun.',
  'faq.4.q' => 'Bagaimana cara menyalin link video TikTok di HP?',
  'faq.4.a' => 'Buka aplikasi TikTok, buka video yang diinginkan, tekan tombol \'Bagikan\' di kanan bawah, lalu pilih opsi \'Salin Tautan\'.',
  'faq.5.q' => 'Bisakah saya mengunduh video TikTok di iPhone / iPad (iOS)?',
  'faq.5.a' => 'Tentu saja. Buka browser Safari di iPhone atau iPad Anda, akses situs kami, tempelkan link video, lalu klik tombol download untuk menyimpannya langsung ke aplikasi Foto atau File.',
  'faq.6.q' => 'Apakah saya bisa mengunduh hanya suara atau musik MP3 dari video?',
  'faq.6.a' => 'Bisa. Setelah menempelkan link video, Anda dapat memilih opsi \'Download Audio MP3 Saja\' untuk menyimpan track lagunya saja dalam kualitas audio jernih.',
  'faq.7.q' => 'Apakah ada batasan jumlah video yang dapat diunduh per hari?',
  'faq.7.a' => 'Tidak ada batasan. Anda dapat mengunduh sebanyak mungkin video TikTok yang Anda inginkan kapan saja.',
  'faq.8.q' => 'Apakah aman menggunakan pengunduh video TikTok ini?',
  'faq.8.a' => 'Sangat aman. Kami tidak menyimpan salinan video Anda, tidak mencatat data pribadi, dan seluruh proses dilindungi oleh enkripsi HTTPS.',
  'footer.copy' => '© :year :name — Download Video TikTok & Douyin Tanpa Watermark Gratis',
  'footer.credit_label' => 'Dibuat oleh',
  'footer.apk' => 'Unduh APK',
  'footer.disclaimer' => 'Situs ini tidak berafiliasi dengan TikTok maupun Douyin. Gunakan hanya untuk video milik sendiri atau penggunaan pribadi yang wajar.',
  'dl.err_invalid_url' => 'URL tidak valid. Tempel link video TikTok atau Douyin. Contoh: https://www.tiktok.com/@namauser/video/1234567890123',
  'dl.err_fetch' => 'Gagal mengambil data video. Coba lagi beberapa saat.',
  'dl.err_not_available' => 'File tidak tersedia untuk jenis unduhan ini.',
  'dl.err_stream' => 'Gagal mengunduh file',
  'err.all_providers' => 'Semua provider gagal memproses video ini. Coba beberapa saat lagi atau coba video lain.',
  'api.err_required' => 'Parameter "url" wajib diisi.',
  'api.example' => 'contoh',
  'artikel.index.title' => 'Artikel & Panduan',
  'artikel.index.desc' => 'Kumpulan artikel dan panduan: cara download video TikTok tanpa watermark, cara download audio TikTok jadi MP3, dan cara download TikTok tanpa aplikasi.',
  'artikel.index.heading' => '📚 Artikel &amp; Panduan',
  'article.meta_line' => '📅 Dipublikasikan 8 Oktober 2026 • ✍️ oleh Fandi • ⏱️ 3 menit baca',
  'article.cta_free' => 'Gratis, tanpa login, tanpa batasan.',
  'article.open_tool' => '⬇️ Buka VoidSyntax Downloader',
  'article.a1.list_title' => 'Cara Download Video TikTok Tanpa Watermark di HP (Gratis, Tanpa Aplikasi)',
  'article.a1.list_desc' => 'Panduan lengkap menyimpan video TikTok tanpa watermark langsung dari browser HP — tanpa install aplikasi, tanpa login, gratis, kualitas HD.',
  'article.a1.title' => 'Cara Download Video TikTok Tanpa Watermark di HP (Gratis, Tanpa Aplikasi, 2026)',
  'article.a1.desc' => 'Panduan lengkap cara download video TikTok tanpa watermark di HP Android & iPhone: tanpa aplikasi, tanpa login, gratis, kualitas HD. Update 2026.',
  'article.a1.body' => '<h1>Cara Download Video TikTok Tanpa Watermark di HP (Gratis, Tanpa Aplikasi, 2026)</h1>
        <p class="article-meta">:meta_line</p>
        <p><strong>Cara download video TikTok tanpa watermark</strong> itu sebenarnya gampang — tidak perlu install aplikasi tambahan yang penuh iklan. Cukup buka browser di HP, tempel link video TikTok, dan video akan tersimpan dalam kualitas HD tanpa watermark. Di artikel ini kami jelaskan langkah lengkapnya menggunakan <strong>VoidSyntax Downloader</strong> (voidsyntax.my.id).</p>
        <h2>Kenapa video perlu tanpa watermark?</h2>
        <p>Watermark (logo TikTok + username) memang tidak bisa dihilangkan langsung dari aplikasi TikTok. Video dengan watermark juga terlihat kurang rapi kalau dipakai untuk diedit ulang atau diarsipkan. Dengan downloader, kamu mendapatkan file video asli tanpa watermark langsung dari server TikTok.</p>
        <h2>Langkah-langkah download video TikTok tanpa watermark</h2>
        <ol>
            <li>Buka aplikasi <strong>TikTok</strong>, cari video yang ingin kamu simpan.</li>
            <li>Tap tombol <strong>Bagikan (Share)</strong> → pilih <strong>Salin Tautan (Copy Link)</strong>.</li>
            <li>Buka browser (Chrome/Safari) → kunjungi <strong>voidsyntax.my.id</strong>.</li>
            <li>Tempel link di kolom yang tersedia → klik <strong>Ambil Video</strong>.</li>
            <li>Tunggu thumbnail &amp; info video muncul → klik <strong>HD Tanpa Watermark</strong>.</li>
            <li>Video langsung terunduh — cek di folder <strong>Download</strong> (HP) atau folder download browser (PC).</li>
        </ol>
        <blockquote>💡 <strong>Tips:</strong> cara ini juga bisa untuk link pendek <code>vm.tiktok.com</code> / <code>vt.tiktok.com</code> — otomatis di-resolve. Untuk pengguna iPhone, versi "app"-nya bisa dipasang lewat Safari → Share → <strong>Add to Home Screen</strong>. Atau download juga versi <a href=":apk_url">aplikasi Android (APK)</a> kami.</blockquote>
        <h2>Hal yang perlu diperhatikan</h2>
        <ul>
            <li>Video harus bersifat <strong>publik</strong> — video private tidak bisa diunduh.</li>
            <li>Hormati hak cipta kreator: gunakan untuk <strong>arsip pribadi</strong>, jangan upload ulang tanpa izin.</li>
            <li>Kualitas video mengikuti kualitas asli yang diupload kreator (bisa HD).</li>
            <li>Butuh koneksi internet — prosesnya hanya beberapa detik.</li>
        </ul>
        <div class="card article-cta">
            <h2>Siap Download?</h2>
            <p>:cta_free</p>
            <a class="btn btn-primary" href=":home_url">:open_tool</a>
        </div>
        <h2>Pertanyaan umum</h2>
        <p><strong>Apakah bisa untuk iPhone?</strong> Bisa — buka websitenya di Safari, atau pasang versi app-nya lewat Add to Home Screen.</p>
        <p><strong>Apakah perlu aplikasi?</strong> Tidak. Semuanya jalan di browser — untuk HP Android, iPhone, maupun PC.</p>
        <p><strong>Berapa lama prosesnya?</strong> Beberapa detik saja, tergantung ukuran video dan koneksi.</p>',
  'article.a2.list_title' => 'Cara Download Audio TikTok Jadi MP3 di HP & PC (Gratis)',
  'article.a2.list_desc' => 'Ekstrak audio dari video TikTok dan simpan sebagai file MP3 — bisa untuk HP Android, iPhone, maupun komputer.',
  'article.a2.title' => 'Cara Download Audio TikTok Jadi MP3 di HP & PC (Gratis, 2026)',
  'article.a2.desc' => 'Panduan cara download audio TikTok jadi file MP3 di HP Android, iPhone, dan PC — gratis, tanpa aplikasi, kualitas audio asli.',
  'article.a2.body' => '<h1>Cara Download Audio TikTok Jadi MP3 di HP &amp; PC (Gratis, 2026)</h1>
        <p class="article-meta">:meta_line</p>
        <p>Sering kita menemukan video TikTok dengan <strong>lagu atau suara yang bagus</strong> — dan kita hanya butuh audionya saja. Kabar baiknya: kamu bisa <strong>download audio TikTok jadi MP3</strong> dengan mudah, gratis, dan tanpa aplikasi tambahan. File hasilnya bisa diputar di mana saja: HP, PC, atau speaker Bluetooth.</p>
        <h2>Kenapa ekstrak audio jadi MP3?</h2>
        <ul>
            <li><strong>Hemat penyimpanan</strong> — file MP3 jauh lebih kecil dari video.</li>
            <li><strong>Bisa diputar di mana saja</strong> — musik, podcast, atau koleksi suara.</li>
            <li><strong>Tanpa watermark video</strong> — yang kamu simpan audio murninya.</li>
        </ul>
        <h2>Langkah-langkah download audio TikTok jadi MP3</h2>
        <ol>
            <li>Buka aplikasi <strong>TikTok</strong> → cari video yang audionya ingin kamu simpan.</li>
            <li>Tap <strong>Bagikan (Share)</strong> → <strong>Salin Tautan (Copy Link)</strong>.</li>
            <li>Buka browser → kunjungi <strong>voidsyntax.my.id</strong>.</li>
            <li>Tempel link → klik <strong>Ambil Video</strong> → tunggu info video muncul.</li>
            <li>Klik tombol <strong>🎵 Audio MP3</strong>.</li>
            <li>File MP3 langsung terunduh — cek folder <strong>Download</strong>.</li>
        </ol>
        <blockquote>💡 <strong>Tips:</strong> cara ini juga jalan untuk link pendek <code>vm.tiktok.com</code> dan link Douyin. Kualitas audio mengikuti kualitas asli video. Untuk iPhone: buka di Safari (atau pasang versi app via Add to Home Screen).</blockquote>
        <h2>Hal yang perlu diperhatikan</h2>
        <ul>
            <li>Audio yang kamu ekstrak adalah milik kreator aslinya — gunakan untuk <strong>koleksi pribadi</strong>.</li>
            <li>Untuk musik berhak cipta, hindari mengupload ulang atau menggunakannya secara komersial tanpa izin.</li>
            <li>Video harus publik — video private tidak bisa diproses.</li>
        </ul>
        <div class="card article-cta">
            <h2>Coba Sekarang</h2>
            <p>:cta_free</p>
            <a class="btn btn-primary" href=":home_url">🎵 Buka VoidSyntax Downloader</a>
        </div>',
  'article.a3.list_title' => 'Cara Download Video TikTok Tanpa Aplikasi & Tanpa Login',
  'article.a3.list_desc' => 'Tanpa aplikasi tambahan yang penuh iklan dan izin berlebihan — cukup buka browser, tempel link, langsung download.',
  'article.a3.title' => 'Cara Download Video TikTok Tanpa Aplikasi & Tanpa Login (Langsung dari Browser, 2026)',
  'article.a3.desc' => 'Cara download video TikTok tanpa aplikasi dan tanpa login — langsung dari browser HP atau PC. Gratis, cepat, dan privasi terjaga.',
  'article.a3.body' => '<h1>Cara Download Video TikTok Tanpa Aplikasi &amp; Tanpa Login (Langsung dari Browser, 2026)</h1>
        <p class="article-meta">:meta_line</p>
        <p>Banyak orang mencari <strong>cara download video TikTok tanpa aplikasi</strong> — dan memang itu yang paling praktis. Aplikasi downloader pihak ketiga seringkali penuh iklan, meminta izin berlebihan (kontak, penyimpanan, bahkan SMS), dan kadang tidak work sama sekali. Solusinya: pakai website downloader yang jalan langsung di browser.</p>
        <h2>Keunggulan download lewat browser (tanpa aplikasi)</h2>
        <ul>
            <li><strong>Tanpa install</strong> — tidak perlu menghabiskan memori HP.</li>
            <li><strong>Tanpa login</strong> — tidak perlu daftar atau masuk akun apa pun.</li>
            <li><strong>Gratis &amp; tanpa batasan</strong> — download sebanyak yang kamu mau.</li>
            <li><strong>Privasi terjaga</strong> — link yang kamu tempel hanya diproses saat itu dan tidak disimpan di server.</li>
            <li><strong>Jalan di semua perangkat</strong> — HP Android, iPhone, PC, tablet.</li>
        </ul>
        <h2>Langkah-langkah (HP &amp; PC)</h2>
        <ol>
            <li>Buka <strong>TikTok</strong> → cari video → tap <strong>Bagikan</strong> → <strong>Salin Tautan</strong>.</li>
            <li>Buka browser (Chrome, Safari, Firefox, Edge) → kunjungi <strong>voidsyntax.my.id</strong>.</li>
            <li>Tempel link di kolom → klik <strong>Ambil Video</strong>.</li>
            <li>Pilih yang kamu mau: <strong>HD Tanpa Watermark</strong>, <strong>Dengan Watermark</strong>, atau <strong>Audio MP3</strong>.</li>
            <li>Selesai — file tersimpan di folder Download.</li>
        </ol>
        <blockquote>💡 <strong>Tips:</strong> untuk yang sering download, pasang versi "app"-nya di HP: pengguna Android bisa install <a href=":apk_url">APK-nya langsung</a>, pengguna iPhone bisa Add to Home Screen lewat Safari — hasilnya seperti aplikasi beneran, tetap tanpa install dari Play Store/App Store.</blockquote>
        <h2>Ringkasnya</h2>
        <p>Tanpa aplikasi, tanpa login, tanpa ribet — buka browser, tempel link, download. Semudah itu.</p>
        <div class="card article-cta">
            <h2>Mulai Download</h2>
            <p>:cta_free</p>
            <a class="btn btn-primary" href=":home_url">:open_tool</a>
        </div>',
  'nav.contact' => 'Kontak',
  'nav.tiktok_dl' => 'TikTok Downloader',
  'nav.douyin_dl' => 'Douyin Downloader',
  'nav.sub.tiktok_video' => 'Download Video TikTok',
  'nav.sub.tiktok_mp3' => 'Download TikTok MP3',
  'nav.sub.tiktok_slideshow' => 'Download TikTok Slideshow',
  'nav.sub.tiktok_story' => 'Download TikTok Story',
  'nav.sub.articles' => 'Artikel & Panduan',
  'nav.sub.douyin_video' => 'Download Video Douyin',
  'nav.sub.douyin_audio' => 'Download Audio MP3 Douyin',
  'nav.sub.douyin_photo' => 'Download Foto Douyin',
  'nav.sub.douyin_slideshow' => 'Download Slideshow Douyin',
  'form.placeholder' => 'Tempel link TikTok / Douyin di sini…|Contoh: https://vt.tiktok.com/ZSxxxx/|Teks share utuh juga bisa!',
  'form.button' => 'Download Video',
  'form.loading' => 'Memproses video...',
  'form.fetching' => 'Mengambil data video...',
  'form.paste' => 'Tempel',
  'btn.sd' => '⬇️ Download MP4 (Tanpa Watermark)',
  'btn.zip' => '🗂️ Download Semua Foto (ZIP)',
  'feature1.title' => 'Bebas Watermark & Logo Bersih',
  'feature1.desc' => 'Hilangkan logo TikTok dan username overlay secara sempurna untuk menghasilkan file video MP4 yang jernih dan profesional.',
  'feature2.title' => 'Kualitas Full HD 1080p & 4K',
  'feature2.desc' => 'Dapatkan resolusi tertinggi dari sumber video hingga 1080p Full HD dan 4K UHD dengan bitrate maksimal dan audio asli jernih.',
  'feature3.title' => 'Multi-Server Super Cepat',
  'feature3.desc' => 'Kluster server berkecepatan tinggi memproses dan mengonversi link video TikTok & Douyin secara instan tanpa antrean dan tanpa login.',
  'howto.heading' => 'Cara Download Video TikTok Tanpa Watermark Kualitas HD',
  'howto.1.title' => 'Salin Link Video TikTok',
  'howto.1.desc' => 'Buka aplikasi TikTok, pilih video favorit yang ingin diunduh, ketuk tombol \'Bagikan\' (Share), lalu pilih \'Salin Tautan\' (Copy Link).',
  'howto.2.title' => 'Tempel URL ke Pengunduh',
  'howto.2.desc' => 'Buka situs pengunduh kami dan tempelkan link yang telah disalin ke dalam kolom pencarian di bagian atas.',
  'howto.3.title' => 'Pilih Opsi Kualitas HD / 4K',
  'howto.3.desc' => 'Pilih resolusi unduhan yang Anda inginkan (Full HD 1080p, 4K, atau format audio MP3 tanpa watermark).',
  'howto.4.title' => 'Simpan Video ke Perangkat',
  'howto.4.desc' => 'Klik tombol download dan file video MP4 berkualitas tinggi akan langsung tersimpan ke galeri HP atau folder laptop Anda.',
  'tips.title' => 'Tips Pro untuk Download Video TikTok HD',
  'tips.1' => 'Gunakan tombol \'Salin Tautan\' langsung dari aplikasi TikTok untuk memastikan URL valid dan lengkap.',
  'tips.2' => 'Pilih opsi \'Download Full HD\' untuk mendapatkan resolusi video 1080p atau 4K dengan kualitas terbaik.',
  'tips.3' => 'Server kami mendeteksi dan menghapus watermark logo secara otomatis tanpa mengurangi fps atau ketajaman warna.',
  'tips.4' => 'Kompatibel penuh untuk semua browser tanpa perlu menginstal aplikasi pihak ketiga atau plugin browser.',
  'tips.5' => 'Gunakan unduhan audio MP3 jika Anda hanya menginginkan musik latar atau sound viral dari video TikTok.',
  'seo.heading' => 'Pengunduh Video TikTok Tanpa Watermark Kualitas Full HD 1080p &amp; 4K',
  'seo.intro' => 'Menikmati video TikTok di mana saja tanpa gangguan logo watermark kini semakin mudah. Pengunduh Video TikTok kami menyediakan solusi online gratis dan cepat untuk mengunduh video TikTok apa pun dalam resolusi tertinggi Full HD 1080p hingga 4K UHD tanpa kompresi visual dan bebas watermark. Mendukung juga video, foto, dan audio dari Douyin (抖音).',
  'seo.why' => '<h3>Mengapa Anda Membutuhkan Pengunduh Video TikTok Tanpa Watermark?</h3><p>Aplikasi resmi TikTok menyematkan watermark nama pengguna yang melayang di atas video saat Anda menyimpannya langsung. Hal ini seringkali menutupi detail penting video dan menurunkan kualitas estetika saat ingin diarsipkan atau dibagikan ulang. Pengunduh kami menghilangkan watermark tersebut sepenuhnya dan mengekstrak file video MP4 murni beresolusi tinggi langsung dari server sumber.</p>',
  'seo.best' => '<h3>Keunggulan Utama Pengunduh Video TikTok Kami</h3>',
  'seo.f1' => '<h4>100% Bebas Watermark Logo TikTok</h4><p>Alat kami secara presisi menghapus semua watermark, logo bergoyang, dan nama akun tanpa meninggalkan blur atau bekas crop.</p><ul><li>Video bersih tanpa logo TikTok di sudut layar</li><li>Kualitas video orisinal tanpa penurunan ketajaman</li><li>Sangat cocok untuk presentasi, arsip, dan konten kreatif</li></ul>',
  'seo.f2' => '<h4>Dukungan Kualitas Full HD 1080p &amp; 4K</h4><p>Kami menjaga integritas resolusi asli video, memungkinkan Anda mengunduh dalam kualitas tertinggi yang didukung oleh video sumber.</p><ul><li>Resolusi Full HD (1080p) dan 4K UHD jika tersedia dari kreator</li><li>Kejernihan visual maksimal dengan bitrate tinggi</li><li>Kualitas trek audio MP3 asli tetap jernih dan utuh</li></ul>',
  'seo.f3' => '<h4>Infrastruktur Multi-Server Super Cepat</h4><p>Didukung oleh kluster server global berkecepatan tinggi yang menjamin waktu pemrosesan secepat kilat dalam hitungan detik.</p><ul><li>Proses konversi dan pengunduhan instan tanpa lag</li><li>Tanpa batasan kuota download harian</li><li>Tidak perlu registrasi akun atau login — privasi tetap terjaga</li></ul>',
  'seo.millions' => '<h3>Mengapa Jutaan Pengguna Memilih Layanan Kami</h3><p>Keamanan, kecepatan, dan kenyamanan pengguna adalah fondasi utama kami. Inilah alasan pengguna setia memilih pengunduh kami:</p><ul><li>Kebijakan privasi ketat: kami tidak pernah menyimpan data pribadi atau riwayat unduhan Anda</li><li>Koneksi aman terenkripsi HTTPS standar perbankan</li><li>Sistem selalu diperbarui secara berkala mengikuti pembaruan TikTok</li><li>Gratis tanpa biaya langganan, watermark tambahan, atau iklan jebakan</li><li>Server andal dengan uptime 99.9% siap melayani kapan pun</li></ul>',
  'seo.ethics' => '<h3>Panduan Etika dan Hak Cipta</h3><p>Kami mendorong seluruh pengguna untuk memanfaatkan alat ini secara bertanggung jawab sesuai hukum hak cipta yang berlaku:</p><ul><li>Gunakan hasil unduhan semata-mata untuk konsumsi dan arsip pribadi</li><li>Selalu hargai hak cipta dan jerih payah pembuat konten</li><li>Dapatkan izin tertulis sebelum mempublikasikan ulang konten orang lain</li><li>Patuhi syarat dan ketentuan layanan komunitas TikTok</li></ul>',
  'seo.cta' => '<h3>Mulai Download Video TikTok Kualitas 4K &amp; HD Sekarang</h3><p>Simpan video TikTok favorit Anda dalam kualitas Full HD 1080p dan 4K tanpa watermark sekarang juga. Tempelkan link video pada kolom di atas dan nikmati kemudahan unduhan instan gratis!</p>',
  'faq.9.q' => 'Apakah bisa download video Douyin (抖音) dan fotonya?',
  'faq.9.a' => 'Bisa! Tempel link video Douyin (www.douyin.com/video/... atau v.douyin.com/...) — sistem otomatis mendeteksi Douyin. Untuk postingan foto/slideshow tersedia tombol "Download Semua Foto (ZIP)".',
  'faq.10.q' => 'Bagaimana cara mengganti bahasa website?',
  'faq.10.a' => 'Klik menu bahasa (ID/EN) di pojok kanan atas halaman, lalu pilih bahasa yang Anda inginkan. Pilihan bahasa akan diingat otomatis untuk kunjungan berikutnya.',
  'page.howto.title' => 'Cara Penggunaan — Panduan Download Video TikTok Tanpa Watermark',
  'page.howto.desc' => 'Panduan langkah demi langkah cara download video TikTok tanpa watermark kualitas HD: salin link, tempel, pilih kualitas, simpan.',
  'page.faq.title' => 'FAQ — Pertanyaan Umum Pengunduh Video TikTok',
  'page.faq.desc' => 'Jawaban atas pertanyaan umum seputar download video TikTok tanpa watermark, kualitas 4K/HD, MP3, Douyin, dan keamanan.',
  'page.contact.title' => 'Kontak & DMCA — VoidSyntax Downloader',
  'page.contact.desc' => 'Hubungi tim VoidSyntax Downloader: WhatsApp, email, TikTok. Kebijakan DMCA & privasi.',
  'page.app.title' => 'Download Aplikasi Android (APK) — VoidSyntax Downloader',
  'page.app.desc' => 'Unduh aplikasi VoidSyntax Downloader untuk Android: gratis, ringan, tanpa iklan mengganggu. Atau pasang sebagai PWA di iPhone.',
  'contact.heading' => 'Hubungi Kami',
  'contact.intro' => 'Ada pertanyaan, saran, atau laporan? Kami siap membantu. Untuk penghapusan konten (DMCA), lihat bagian khusus di bawah.',
  'contact.channels' => 'Media Sosial & Kontak',
  'contact.dmca_h' => 'Laporan DMCA',
  'contact.dmca_p' => 'Kami menghormati hak cipta kreator. Jika Anda pemilik konten dan merasa materi Anda dilanggar melalui layanan kami, kirimkan laporan DMCA berisi: (1) URL konten yang dilanggar, (2) bukti kepemilikan, (3) kontak Anda, ke email afandiae01@gmail.com atau WhatsApp 087711180777. Laporan akan kami proses dalam 1-3 hari kerja.',
  'contact.privacy_h' => 'Privasi',
  'contact.privacy_p' => 'Kami tidak pernah menyimpan link, data pribadi, atau riwayat unduhan Anda. Semua proses dilakukan secara instan dan dilindungi enkripsi HTTPS. Riwayat unduhan hanya tersimpan di browser Anda sendiri (localStorage).',
  'app.install_h' => 'Cara Install APK',
  'app.ios_h' => 'Pengguna iPhone / iPad (iOS)',
  'footer.about' => 'VoidSyntax adalah layanan online gratis yang memungkinkan Anda mengunduh video TikTok & Douyin tanpa watermark. Kami tidak berafiliasi dengan TikTok maupun Douyin.',
  'footer.quick' => 'Tautan Cepat',
  'footer.tools' => 'Alat Download',
  'footer.social' => 'Media Sosial',
  'app.update_available' => '✨ Pembaruan tersedia! Memuat versi terbaru…',
  'hero.badge' => '⚡ Auto-provider • Tanpa watermark • 100% gratis',
  'hero.chip1' => 'Kualitas HD 1080p/4K',
  'hero.chip2' => 'Audio MP3',
  'hero.chip3' => 'Slideshow jadi ZIP',
  'hero.chip4' => 'TikTok & Douyin',
  'app.auto_h' => '🔄 Pembaruan Otomatis',
  'app.auto_note' => 'Aplikasi & situs ini selalu terhubung ke server terbaru. Saat kami memperbarui fitur, Anda akan melihat notifikasi \"Pembaruan tersedia\" lalu aplikasi memuat versi terbaru secara otomatis — tidak perlu install ulang APK.',
  'paste_hint' => 'Tekan Ctrl+V di keyboard, atau tekan lama kotak lalu pilih Tempel.',
);
