<?php
/**
 * lang/ms.php — TERJEMAHAN (v3, tema Cosmic Aurora)
 * Tambah bahasa baru: salin file ini jadi lang/xx.php lalu terjemahkan isinya.
 * Placeholder :seperti_ini diganti saat pemanggilan t("kunci", [...]).
 */
return array (
  'meta.keywords' => 'muat turun tiktok, tiktok downloader, tiktok tanpa watermark, muat turun video tiktok, tiktok mp3, tiktok 4k, muat turun douyin, douyin tanpa watermark, voidsyntax',
  'meta.title_home' => 'Muat Turun Video TikTok HD 1080p & 4K Tanpa Watermark Pantas',
  'meta.desc_home' => 'Muat turun video TikTok kualiti Full HD 1080p dan 4K tanpa watermark percuma. Pemprosesan multi-server pantas untuk telefon, tablet, dan PC. Sokong Douyin & MP3.',
  'nav.home' => 'Utama',
  'nav.articles' => 'Artikel',
  'nav.features' => 'Ciri',
  'nav.howto' => 'Cara Guna',
  'nav.faq' => 'FAQ',
  'lang.label' => 'Bahasa',
  'hero.title' => 'Muat Turun Video TikTok Tanpa Watermark',
  'hero.lead' => 'Muat turun video TikTok &amp; Douyin kualiti Full HD 1080p dan 4K tanpa watermark percuma. Pemprosesan multi-server pantas untuk telefon, tablet, dan PC.',
  'hero.placeholder' => 'Tampal pautan TikTok / Douyin (atau teks share penuh)...',
  'hero.submit' => 'Ambil Video',
  'hero.hint' => 'Menyokong pautan pendek <code>vm.tiktok.com</code>, <code>vt.tiktok.com</code> &amp; <code>v.douyin.com</code> • Auto provider (fallback automatik)',
  'status.processing' => 'Memproses...',
  'status.fetching' => 'Mengambil data video...',
  'status.network_error' => 'Ralat rangkaian berlaku. Semak sambungan anda dan cuba lagi.',
  'result.no_title' => '(Tanpa tajuk)',
  'result.seconds' => 'saat',
  'result.via' => 'via',
  'result.source' => 'Sumber',
  'btn.hd' => '⬇️ Muat Turun Full HD (1080p/4K)',
  'btn.wm' => '💧 Muat Turun Dengan Watermark',
  'btn.mp3' => '🎵 Muat Turun Audio MP3 Sahaja',
  'platform.tiktok' => 'TikTok',
  'platform.douyin' => 'Douyin',
  'app.title' => 'Muat Turun Aplikasi Android',
  'app.desc' => 'Versi aplikasi laman web ini — pasang terus di telefon, tanpa pelayar. <strong>Versi 1.0.0</strong> • <strong>± 0.8 MB</strong> • <strong>Android 8.0+</strong> • Percuma.',
  'app.download_apk' => 'Muat Turun APK',
  'app.install_note' => 'Selepas muat turun: buka fail APK → benarkan "pasang dari sumber tidak diketahui" → Pasang.',
  'app.ios_note' => '🍎 <strong>Khas untuk Android (8.0+).</strong> Pengguna iPhone/iPad (iOS): fail APK tidak boleh dipasang di iOS. Caranya: buka laman ini di <strong>Safari</strong> → tekan butang <strong>Share</strong> (ikon kotak + anak panah) → <strong>"Add to Home Screen"</strong> → ikon aplikasi muncul di skrin utama seperti aplikasi biasa.',
  'donate.title' => '❤️ Sokong Kami',
  'donate.desc' => 'Laman web ini <strong>percuma, tanpa login, dan tanpa had</strong>. Jika ia membantu anda, sokong kami agar terus online &amp; berkembang — melalui <strong>Saweria</strong> atau <strong>PayPal</strong>. Terima kasih! 🙏',
  'donate.qr_alt' => 'Kod QR Saweria — imbas untuk menderma',
  'donate.wallet_by' => 'a.n. Fandi — hantar apa-apa sahaja (bebas nominal)',
  'donate.wallet_note' => 'Pindahan manual (tanpa Saweria)? Selepas pindahan, sahkan melalui WhatsApp:',
  'donate.copy' => '📋 Salin',
  'donate.copied' => '✅ Disalin',
  'history.heading' => '🕘 Baru Dimuat Turun',
  'faq.heading' => 'Soalan Lazim Tentang Pemuat Turunan Video TikTok',
  'faq.1.q' => 'Bolehkah saya memuat turun video TikTok dalam kualiti 4K atau 1080p HD?',
  'faq.1.a' => 'Ya! Pemuat turun kami secara automatik mengesan resolusi tertinggi yang dimuat naik oleh kreator, termasuk kualiti Full HD 1080p dan 4K UHD, lalu menyediakannya untuk dimuat turun tanpa watermark.',
  'faq.2.q' => 'Bagaimana cara menghilangkan watermark dari video TikTok?',
  'faq.2.a' => 'Cukup salin pautan video TikTok, tampal ke kotak input di laman kami, kemudian klik Muat Turun. Sistem kami akan memproses dan menyajikan fail MP4 asal yang sepenuhnya bebas dari logo TikTok.',
  'faq.3.q' => 'Adakah perkhidmatan muat turun video TikTok ini 100% percuma?',
  'faq.3.a' => 'Ya, pemuat turun video TikTok kami sepenuhnya percuma tanpa had bilangan muat turun dan tanpa memerlukan biaya langganan atau pembuatan akaun.',
  'faq.4.q' => 'Bagaimana cara menyalin pautan video TikTok di telefon?',
  'faq.4.a' => 'Buka aplikasi TikTok, buka video yang diingini, tekan butang \'Share\' di kanan bawah, kemudian pilih opsi \'Copy Link\'.',
  'faq.5.q' => 'Bolehkah saya memuat turun video TikTok di iPhone / iPad (iOS)?',
  'faq.5.a' => 'Tentu sahaja. Buka pelayar Safari di iPhone atau iPad anda, akses laman kami, tampal pautan video, kemudian klik butang muat turun untuk menyimpannya terus ke aplikasi Foto atau Fail.',
  'faq.6.q' => 'Bolehkah saya memuat turun hanya suara atau muzik MP3 dari video?',
  'faq.6.a' => 'Boleh. Selepas menampal pautan video, anda boleh memilih opsi \'Muat Turun Audio MP3 Sahaja\' untuk menyimpan track lagu sahaja dalam kualiti audio jernih.',
  'faq.7.q' => 'Adakah had bilangan video yang boleh dimuat turun sehari?',
  'faq.7.a' => 'Tiada had. Anda boleh memuat turun sebanyak mungkin video TikTok yang anda mahukan pada bila-bila masa.',
  'faq.8.q' => 'Adakah selamat menggunakan pemuat turun video TikTok ini?',
  'faq.8.a' => 'Sangat selamat. Kami tidak menyimpan salinan video anda, tidak mencatat data peribadi, dan seluruh proses dilindungi oleh enkripsi HTTPS.',
  'footer.copy' => '© :year :name — Muat Turun Video TikTok & Douyin Tanpa Watermark Percuma',
  'footer.credit_label' => 'Dicipta oleh',
  'footer.apk' => 'Muat Turun APK',
  'footer.disclaimer' => 'Laman ini tidak bergabung dengan TikTok mahupun Douyin. Gunakan hanya untuk video milik sendiri atau penggunaan peribadi yang wajar.',
  'dl.err_invalid_url' => 'URL tidak sah. Tampal pautan video TikTok atau Douyin. Contoh: https://www.tiktok.com/@namauser/video/1234567890123',
  'dl.err_fetch' => 'Gagal mengambil data video. Sila cuba lagi sebentar lagi.',
  'dl.err_not_available' => 'Fail tidak tersedia untuk jenis muat turun ini.',
  'dl.err_stream' => 'Gagal memuat turun fail',
  'err.all_providers' => 'Semua provider gagal memproses video ini. Cuba lagi sebentar lagi atau cuba video lain.',
  'api.err_required' => 'Parameter "url" wajib diisi.',
  'api.example' => 'contoh',
  'artikel.index.title' => 'Artikel & Panduan',
  'artikel.index.desc' => 'Himpunan artikel dan panduan: cara muat turun video TikTok tanpa watermark, cara muat turun audio TikTok jadi MP3, dan cara muat turun TikTok tanpa aplikasi.',
  'artikel.index.heading' => '📚 Artikel &amp; Panduan',
  'article.meta_line' => '📅 Diterbitkan 8 Oktober 2026 • ✍️ oleh Fandi • ⏱️ 3 minit baca',
  'article.cta_free' => 'Percuma, tanpa login, tanpa had.',
  'article.open_tool' => '⬇️ Buka VoidSyntax Downloader',
  'article.a1.list_title' => 'Cara Muat Turun Video TikTok Tanpa Watermark di HP (Percuma, Tanpa Aplikasi)',
  'article.a1.list_desc' => 'Panduan lengkap menyimpan video TikTok tanpa watermark terus dari pelayar HP — tanpa pasang aplikasi, tanpa login, percuma, kualiti HD.',
  'article.a1.title' => 'Cara Muat Turun Video TikTok Tanpa Watermark di HP (Percuma, Tanpa Aplikasi, 2026)',
  'article.a1.desc' => 'Panduan lengkap cara muat turun video TikTok tanpa watermark di HP Android & iPhone: tanpa aplikasi, tanpa login, percuma, kualiti HD. Kemaskini 2026.',
  'article.a1.body' => '<h1>Cara Muat Turun Video TikTok Tanpa Watermark di HP (Percuma, Tanpa Aplikasi, 2026)</h1>
        <p class="article-meta">:meta_line</p>
        <p><strong>Cara muat turun video TikTok tanpa watermark</strong> sebenarnya mudah — tidak perlu pasang aplikasi tambahan yang penuh iklan. Cukup buka pelayar di HP, tampal pautan video TikTok, dan video akan tersimpan dalam kualiti HD tanpa watermark. Dalam artikel ini kami terangkan langkah lengkap menggunakan <strong>VoidSyntax Downloader</strong> (voidsyntax.my.id).</p>
        <h2>Kenapa video perlu tanpa watermark?</h2>
        <p>Watermark (logo TikTok + username) memang tidak boleh dihilangkan terus dari aplikasi TikTok. Video dengan watermark juga kurang kemas jika digunakan untuk disunting semula atau diarkibkan. Dengan pemuat turun, anda mendapat fail video asal tanpa watermark terus dari pelayan TikTok.</p>
        <h2>Langkah-langkah muat turun video TikTok tanpa watermark</h2>
        <ol>
            <li>Buka aplikasi <strong>TikTok</strong>, cari video yang ingin anda simpan.</li>
            <li>Tekan butang <strong>Share</strong> → pilih <strong>Copy Link</strong>.</li>
            <li>Buka pelayar (Chrome/Safari) → lawati <strong>voidsyntax.my.id</strong>.</li>
            <li>Tampal pautan dalam kotak yang tersedia → klik <strong>Ambil Video</strong>.</li>
            <li>Tunggu thumbnail &amp; info video muncul → klik <strong>HD Tanpa Watermark</strong>.</li>
            <li>Video terus dimuat turun — semak folder <strong>Download</strong> (HP) atau folder muat turun pelayar (PC).</li>
        </ol>
        <blockquote>💡 <strong>Tips:</strong> cara ini juga boleh untuk pautan pendek <code>vm.tiktok.com</code> / <code>vt.tiktok.com</code> — automatik diselesaikan. Untuk pengguna iPhone, versi "app" boleh dipasang melalui Safari → Share → <strong>Add to Home Screen</strong>. Atau muat turun juga versi <a href=":apk_url">aplikasi Android (APK)</a> kami.</blockquote>
        <h2>Perkara yang perlu diberi perhatian</h2>
        <ul>
            <li>Video mesti bersifat <strong>umum</strong> — video peribadi tidak boleh dimuat turun.</li>
            <li>Hormati hak cipta kreator: gunakan untuk <strong>arkib peribadi</strong>, jangan muat naik semula tanpa kebenaran.</li>
            <li>Kualiti video mengikut kualiti asal yang dimuat naik kreator (boleh HD).</li>
            <li>Perlukan sambungan internet — prosesnya hanya beberapa saat.</li>
        </ul>
        <div class="card article-cta">
            <h2>Sedia Muat Turun?</h2>
            <p>:cta_free</p>
            <a class="btn btn-primary" href=":home_url">:open_tool</a>
        </div>
        <h2>Soalan lazim</h2>
        <p><strong>Boleh guna di iPhone?</strong> Boleh — buka laman web di Safari, atau pasang versi app melalui Add to Home Screen.</p>
        <p><strong>Perlukah aplikasi?</strong> Tidak. Semuanya berjalan di pelayar — untuk HP Android, iPhone, mahupun PC.</p>
        <p><strong>Berapa lama prosesnya?</strong> Beberapa saat sahaja, bergantung pada saiz video dan sambungan.</p>',
  'article.a2.list_title' => 'Cara Muat Turun Audio TikTok Jadi MP3 di HP & PC (Percuma)',
  'article.a2.list_desc' => 'Ekstrak audio daripada video TikTok dan simpan sebagai fail MP3 — boleh untuk HP Android, iPhone, mahupun komputer.',
  'article.a2.title' => 'Cara Muat Turun Audio TikTok Jadi MP3 di HP & PC (Percuma, 2026)',
  'article.a2.desc' => 'Panduan cara muat turun audio TikTok jadi fail MP3 di HP Android, iPhone, dan PC — percuma, tanpa aplikasi, kualiti audio asal.',
  'article.a2.body' => '<h1>Cara Muat Turun Audio TikTok Jadi MP3 di HP &amp; PC (Percuma, 2026)</h1>
        <p class="article-meta">:meta_line</p>
        <p>Sering kali kita jumpa video TikTok dengan <strong>lagu atau bunyi yang best</strong> — dan kita hanya perlukan audionya sahaja. Berita baiknya: anda boleh <strong>muat turun audio TikTok jadi MP3</strong> dengan mudah, percuma, dan tanpa aplikasi tambahan. Fail hasilnya boleh dimainkan di mana-mana: HP, PC, atau pembesar suara Bluetooth.</p>
        <h2>Kenapa ekstrak audio jadi MP3?</h2>
        <ul>
            <li><strong>Jimat storan</strong> — fail MP3 jauh lebih kecil daripada video.</li>
            <li><strong>Boleh dimainkan di mana-mana</strong> — muzik, podcast, atau koleksi bunyi.</li>
            <li><strong>Tanpa watermark video</strong> — yang anda simpan adalah audio tulennya.</li>
        </ul>
        <h2>Langkah-langkah muat turun audio TikTok jadi MP3</h2>
        <ol>
            <li>Buka aplikasi <strong>TikTok</strong> → cari video yang audionya ingin anda simpan.</li>
            <li>Tekan <strong>Share</strong> → <strong>Copy Link</strong>.</li>
            <li>Buka pelayar → lawati <strong>voidsyntax.my.id</strong>.</li>
            <li>Tampal pautan → klik <strong>Ambil Video</strong> → tunggu info video muncul.</li>
            <li>Klik butang <strong>🎵 Audio MP3</strong>.</li>
            <li>Fail MP3 terus dimuat turun — semak folder <strong>Download</strong>.</li>
        </ol>
        <blockquote>💡 <strong>Tips:</strong> cara ini juga berjalan untuk pautan pendek <code>vm.tiktok.com</code> dan pautan Douyin. Kualiti audio mengikut kualiti asal video. Untuk iPhone: buka di Safari (atau pasang versi app via Add to Home Screen).</blockquote>
        <h2>Perkara yang perlu diberi perhatian</h2>
        <ul>
            <li>Audio yang anda ekstrak adalah milik kreator asalnya — gunakan untuk <strong>koleksi peribadi</strong>.</li>
            <li>Untuk muzik berhak cipta, elakkan memuat naik semula atau menggunakannya secara komersial tanpa kebenaran.</li>
            <li>Video mesti umum — video peribadi tidak boleh diproses.</li>
        </ul>
        <div class="card article-cta">
            <h2>Cuba Sekarang</h2>
            <p>:cta_free</p>
            <a class="btn btn-primary" href=":home_url">🎵 Buka VoidSyntax Downloader</a>
        </div>',
  'article.a3.list_title' => 'Cara Muat Turun Video TikTok Tanpa Aplikasi & Tanpa Login',
  'article.a3.list_desc' => 'Tanpa aplikasi tambahan yang penuh iklan dan izin berlebihan — cukup buka pelayar, tampal pautan, terus muat turun.',
  'article.a3.title' => 'Cara Muat Turun Video TikTok Tanpa Aplikasi & Tanpa Login (Terus dari Pelayar, 2026)',
  'article.a3.desc' => 'Cara muat turun video TikTok tanpa aplikasi dan tanpa login — terus dari pelayar HP atau PC. Percuma, pantas, dan privasi terpelihara.',
  'article.a3.body' => '<h1>Cara Muat Turun Video TikTok Tanpa Aplikasi &amp; Tanpa Login (Terus dari Pelayar, 2026)</h1>
        <p class="article-meta">:meta_line</p>
        <p>Ramai orang mencari <strong>cara muat turun video TikTok tanpa aplikasi</strong> — dan memang itulah yang paling praktikal. Aplikasi pemuat turun pihak ketiga sering kali penuh iklan, meminta izin berlebihan (kenalan, storan, malah SMS), dan kadang-kadang langsung tidak berfungsi. Penyelesaiannya: guna laman web pemuat turun yang berjalan terus di pelayar.</p>
        <h2>Kelebihan muat turun melalui pelayar (tanpa aplikasi)</h2>
        <ul>
            <li><strong>Tanpa pasang</strong> — tidak perlu menghabiskan memori HP.</li>
            <li><strong>Tanpa login</strong> — tidak perlu daftar atau masuk akaun apa-apa.</li>
            <li><strong>Percuma &amp; tanpa had</strong> — muat turun sebanyak yang anda mahu.</li>
            <li><strong>Privasi terpelihara</strong> — pautan yang anda tampal hanya diproses pada ketika itu dan tidak disimpan di pelayan.</li>
            <li><strong>Berjalan di semua peranti</strong> — HP Android, iPhone, PC, tablet.</li>
        </ul>
        <h2>Langkah-langkah (HP &amp; PC)</h2>
        <ol>
            <li>Buka <strong>TikTok</strong> → cari video → tekan <strong>Share</strong> → <strong>Copy Link</strong>.</li>
            <li>Buka pelayar (Chrome, Safari, Firefox, Edge) → lawati <strong>voidsyntax.my.id</strong>.</li>
            <li>Tampal pautan dalam kotak → klik <strong>Ambil Video</strong>.</li>
            <li>Pilih yang anda mahu: <strong>HD Tanpa Watermark</strong>, <strong>Dengan Watermark</strong>, atau <strong>Audio MP3</strong>.</li>
            <li>Selesai — fail tersimpan dalam folder Download.</li>
        </ol>
        <blockquote>💡 <strong>Tips:</strong> untuk yang kerap muat turun, pasang versi "app" di HP: pengguna Android boleh pasang <a href=":apk_url">APK terus</a>, pengguna iPhone boleh Add to Home Screen melalui Safari — hasilnya seperti aplikasi betul, tetap tanpa pasang dari Play Store/App Store.</blockquote>
        <h2>Ringkasnya</h2>
        <p>Tanpa aplikasi, tanpa login, tanpa ribet — buka pelayar, tampal pautan, muat turun. Semudah itu.</p>
        <div class="card article-cta">
            <h2>Mula Muat Turun</h2>
            <p>:cta_free</p>
            <a class="btn btn-primary" href=":home_url">:open_tool</a>
        </div>',
  'nav.contact' => 'Hubungi Kami',
  'nav.tiktok_dl' => 'TikTok Downloader',
  'nav.douyin_dl' => 'Douyin Downloader',
  'nav.sub.tiktok_video' => 'Muat Turun Video TikTok',
  'nav.sub.tiktok_mp3' => 'Muat Turun TikTok MP3',
  'nav.sub.tiktok_slideshow' => 'Muat Turun TikTok Slideshow',
  'nav.sub.tiktok_story' => 'Muat Turun TikTok Story',
  'nav.sub.articles' => 'Artikel & Panduan',
  'nav.sub.douyin_video' => 'Muat Turun Video Douyin',
  'nav.sub.douyin_audio' => 'Muat Turun Audio MP3 Douyin',
  'nav.sub.douyin_photo' => 'Muat Turun Foto Douyin',
  'nav.sub.douyin_slideshow' => 'Muat Turun Slideshow Douyin',
  'form.placeholder' => 'Tampal pautan TikTok / Douyin di sini…|Contoh: https://vt.tiktok.com/ZSxxxx/|Teks share penuh juga boleh!',
  'form.button' => 'Muat Turun Video',
  'form.loading' => 'Memproses video...',
  'form.fetching' => 'Mengambil data video...',
  'form.paste' => 'Tampal',
  'btn.sd' => '⬇️ Muat Turun MP4 (Tanpa Watermark)',
  'btn.zip' => '🗂️ Muat Turun Semua Foto (ZIP)',
  'feature1.title' => 'Bebas Watermark & Logo Bersih',
  'feature1.desc' => 'Hilangkan logo TikTok dan username overlay dengan sempurna untuk menghasilkan fail video MP4 yang jernih dan profesional.',
  'feature2.title' => 'Kualiti Full HD 1080p & 4K',
  'feature2.desc' => 'Dapatkan resolusi tertinggi dari sumber video sehingga 1080p Full HD dan 4K UHD dengan bitrate maksimum dan audio asli jernih.',
  'feature3.title' => 'Multi-Server Super Pantas',
  'feature3.desc' => 'Kluster server berkelajuan tinggi memproses dan menukar pautan video TikTok & Douyin secara instan tanpa beratur dan tanpa login.',
  'howto.heading' => 'Cara Muat Turun Video TikTok Tanpa Watermark Kualiti HD',
  'howto.1.title' => 'Salin Pautan Video TikTok',
  'howto.1.desc' => 'Buka aplikasi TikTok, pilih video kegemaran yang ingin dimuat turun, tekan butang \'Share\', kemudian pilih \'Copy Link\'.',
  'howto.2.title' => 'Tampal URL ke Pemuat Turun',
  'howto.2.desc' => 'Buka laman pemuat turun kami dan tampal pautan yang telah disalin ke dalam kotak carian di bahagian atas.',
  'howto.3.title' => 'Pilih Opsi Kualiti HD / 4K',
  'howto.3.desc' => 'Pilih resolusi muat turun yang anda mahukan (Full HD 1080p, 4K, atau format audio MP3 tanpa watermark).',
  'howto.4.title' => 'Simpan Video ke Peranti',
  'howto.4.desc' => 'Klik butang muat turun dan fail video MP4 berkualiti tinggi akan terus disimpan ke galeri telefon atau folder laptop anda.',
  'tips.title' => 'Tips Pro untuk Muat Turun Video TikTok HD',
  'tips.1' => 'Guna butang \'Copy Link\' terus dari aplikasi TikTok untuk memastikan URL sah dan lengkap.',
  'tips.2' => 'Pilih opsi \'Muat Turun Full HD\' untuk mendapatkan resolusi video 1080p atau 4K dengan kualiti terbaik.',
  'tips.3' => 'Server kami mengesan dan menghapus watermark logo secara automatik tanpa mengurangi fps atau ketajaman warna.',
  'tips.4' => 'Serasi penuh untuk semua pelayar tanpa perlu memasang aplikasi pihak ketiga atau plugin pelayar.',
  'tips.5' => 'Guna muat turun audio MP3 jika anda hanya mahukan muzik latar atau sound viral dari video TikTok.',
  'seo.heading' => 'Pemuat Turun Video TikTok Tanpa Watermark Kualiti Full HD 1080p &amp; 4K',
  'seo.intro' => 'Menikmati video TikTok di mana sahaja tanpa gangguan logo watermark kini semakin mudah. Pemuat Turun Video TikTok kami menyediakan solusi online percuma dan pantas untuk memuat turun video TikTok apa pun dalam resolusi tertinggi Full HD 1080p sehingga 4K UHD tanpa pemampatan visual dan bebas watermark. Menyokong juga video, foto, dan audio dari Douyin (抖音).',
  'seo.why' => '<h3>Mengapa Anda Memerlukan Pemuat Turun Video TikTok Tanpa Watermark?</h3><p>Aplikasi rasmi TikTok menyemat watermark nama pengguna yang melayang di atas video apabila anda menyimpannya terus. Hal ini sering menutupi detail penting video dan menurunkan kualiti estetika apabila ingin diarkibkan atau dikongsi semula. Pemuat turun kami menghilangkan watermark tersebut sepenuhnya dan mengekstrak fail video MP4 tulen beresolusi tinggi terus dari server sumber.</p>',
  'seo.best' => '<h3>Keunggulan Utama Pemuat Turun Video TikTok Kami</h3>',
  'seo.f1' => '<h4>100% Bebas Watermark Logo TikTok</h4><p>Alat kami secara presisi menghapus semua watermark, logo bergoyang, dan nama akaun tanpa meninggalkan blur atau kesan crop.</p><ul><li>Video bersih tanpa logo TikTok di sudut skrin</li><li>Kualiti video orisinal tanpa penurunan ketajaman</li><li>Sangat sesuai untuk pembentangan, arkib, dan kandungan kreatif</li></ul>',
  'seo.f2' => '<h4>Sokongan Kualiti Full HD 1080p &amp; 4K</h4><p>Kami menjaga integriti resolusi asal video, membolehkan anda memuat turun dalam kualiti tertinggi yang disokong oleh video sumber.</p><ul><li>Resolusi Full HD (1080p) dan 4K UHD jika tersedia dari kreator</li><li>Kejernihan visual maksimum dengan bitrate tinggi</li><li>Kualiti trek audio MP3 asal kekal jernih dan utuh</li></ul>',
  'seo.f3' => '<h4>Infrastruktur Multi-Server Super Pantas</h4><p>Disokong oleh kluster server global berkelajuan tinggi yang menjamin masa pemprosesan sepantas kilat dalam hitungan saat.</p><ul><li>Proses penukaran dan muat turun instan tanpa lag</li><li>Tanpa had kuota muat turun harian</li><li>Tidak perlu pendaftaran akaun atau login — privasi kekal terpelihara</li></ul>',
  'seo.millions' => '<h3>Mengapa Jutaan Pengguna Memilih Perkhidmatan Kami</h3><p>Keselamatan, kelajuan, dan keselesaan pengguna adalah asas utama kami. Inilah sebab pengguna setia memilih pemuat turun kami:</p><ul><li>Dasar privasi ketat: kami tidak pernah menyimpan data peribadi atau sejarah muat turun anda</li><li>Sambungan HTTPS tersulit gred perbankan</li><li>Sistem sentiasa dikemas kini mengikuti kemas kini TikTok</li><li>Percuma tanpa biaya langganan, watermark tambahan, atau iklan perangkap</li><li>Server boleh dipercayai dengan uptime 99.9% sedia bila-bila masa</li></ul>',
  'seo.ethics' => '<h3>Panduan Etika dan Hak Cipta</h3><p>Kami menggalakkan semua pengguna menggunakan alat ini secara bertanggungjawab mengikut undang-undang hak cipta yang berlaku:</p><ul><li>Guna hasil muat turun semata-mata untuk konsumsi dan arkib peribadi</li><li>Sentiasa hargai hak cipta dan usaha pembuat kandungan</li><li>Dapatkan izin bertulis sebelum menerbitkan semula kandungan orang lain</li><li>Patuhi syarat dan ketentuan perkhidmatan komuniti TikTok</li></ul>',
  'seo.cta' => '<h3>Mula Muat Turun Video TikTok Kualiti 4K &amp; HD Sekarang</h3><p>Simpan video TikTok kegemaran anda dalam kualiti Full HD 1080p dan 4K tanpa watermark sekarang juga. Tampal pautan video pada kotak di atas dan nikmati kemudahan muat turun instan percuma!</p>',
  'faq.9.q' => 'Boleh muat turun video Douyin (抖音) dan fotonya?',
  'faq.9.a' => 'Boleh! Tampal pautan video Douyin (www.douyin.com/video/... atau v.douyin.com/...) — sistem automatik mengesan Douyin. Untuk postingan foto/slideshow tersedia butang "Muat Turun Semua Foto (ZIP)".',
  'faq.10.q' => 'Bagaimana cara menukar bahasa laman web?',
  'faq.10.a' => 'Klik menu bahasa (ID/EN) di penjuk kanan atas halaman, kemudian pilih bahasa yang anda mahukan. Pilihan bahasa akan diingati automatik untuk lawatan akan datang.',
  'page.howto.title' => 'Cara Guna — Panduan Muat Turun Video TikTok Tanpa Watermark',
  'page.howto.desc' => 'Panduan langkah demi langkah cara muat turun video TikTok tanpa watermark kualiti HD: salin pautan, tampal, pilih kualiti, simpan.',
  'page.faq.title' => 'FAQ — Soalan Lazim Pemuat Turun Video TikTok',
  'page.faq.desc' => 'Jawapan kepada soalan lazim seputar muat turun video TikTok tanpa watermark, kualiti 4K/HD, MP3, Douyin, dan keselamatan.',
  'page.contact.title' => 'Hubungi & DMCA — VoidSyntax Downloader',
  'page.contact.desc' => 'Hubungi pasukan VoidSyntax Downloader: WhatsApp, e-mel, TikTok. Dasar DMCA & privasi.',
  'page.app.title' => 'Muat Turun Aplikasi Android (APK) — VoidSyntax Downloader',
  'page.app.desc' => 'Dapatkan aplikasi VoidSyntax Downloader untuk Android: percuma, ringan, tanpa iklan mengganggu. Atau pasang sebagai PWA di iPhone.',
  'contact.heading' => 'Hubungi Kami',
  'contact.intro' => 'Ada soalan, cadangan, atau laporan? Kami sedia membantu. Untuk penghapusan kandungan (DMCA), lihat bahagian khusus di bawah.',
  'contact.channels' => 'Media Sosial & Kontak',
  'contact.dmca_h' => 'Laporan DMCA',
  'contact.dmca_p' => 'Kami menghormati hak cipta kreator. Jika anda pemilik kandungan dan merasa materi anda dilanggar melalui perkhidmatan kami, hantar laporan DMCA berisi: (1) URL kandungan yang dilanggar, (2) bukti pemilikan, (3) kontak anda, ke e-mel afandiae01@gmail.com atau WhatsApp 087711180777. Laporan akan diproses dalam 1-3 hari bekerja.',
  'contact.privacy_h' => 'Privasi',
  'contact.privacy_p' => 'Kami tidak pernah menyimpan pautan, data peribadi, atau sejarah muat turun anda. Semua proses dilakukan secara instan dan dilindungi enkripsi HTTPS. Sejarah muat turun hanya disimpan di pelayar anda sendiri (localStorage).',
  'app.install_h' => 'Cara Pasang APK',
  'app.ios_h' => 'Pengguna iPhone / iPad (iOS)',
  'footer.about' => 'VoidSyntax adalah perkhidmatan online percuma yang membolehkan anda memuat turun video TikTok & Douyin tanpa watermark. Kami tidak bergabung dengan TikTok mahupun Douyin.',
  'footer.quick' => 'Pautan Pantas',
  'footer.tools' => 'Alat Muat Turun',
  'footer.social' => 'Media Sosial',
  'app.update_available' => '✨ Kemas kini tersedia! Memuat versi baharu…',
  'hero.badge' => '⚡ Auto-provider • Tanpa tera air • 100% percuma',
  'hero.chip1' => 'Kualiti HD 1080p/4K',
  'hero.chip2' => 'Audio MP3',
  'hero.chip3' => 'Slideshow jadi ZIP',
  'hero.chip4' => 'TikTok & Douyin',
  'app.auto_h' => '🔄 Kemas Kini Automatik',
  'app.auto_note' => 'Aplikasi dan laman ini sentiasa bersambung ke pelayan terkini. Apabila kami menambah ciri baharu, anda akan melihat notifikasi \"Kemas kini tersedia\" dan aplikasi memuat versi terbaharu secara automatik — tidak perlu pasang semula APK.',
  'paste_hint' => 'Tekan Ctrl+V pada papan kekunci, atau tekan lama kotak kemudian pilih Tampal.',
);
