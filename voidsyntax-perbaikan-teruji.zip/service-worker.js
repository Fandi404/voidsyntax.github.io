/**
 * service-worker.js — PWA service worker untuk VoidSyntax Downloader.
 *
 * Strategi (VERSI BARU — anti-stale, selalu segar tanpa hapus cache):
 *  - Halaman HTML (navigasi) : NETWORK FIRST — selalu ambil dari server.
 *    Cache hanya dipakai kalau offline. Salinan terbaru tetap disimpan.
 *  - Aset statis (css/js/img/ikon) : CACHE FIRST — cepat; sudah cache-busted (?v=).
 *  - /api, /download.php, /version.php : tidak ditangani (selalu network, live).
 *  - Update: cache lama otomatis terhapus saat versi baru aktif (skipWaiting).
 */
const CACHE = 'voidsyntax-v1.3.2';

const SHELL = [
  '/',
  '/manifest.json',
  '/assets/img/icon-192.png',
  '/assets/img/icon-512.png'
];

self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(CACHE)
      .then(function (cache) { return cache.addAll(SHELL); })
      .then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.filter(function (key) { return key !== CACHE; })
            .map(function (key) { return caches.delete(key); })
      );
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function (event) {
  var req = event.request;
  if (req.method !== 'GET') { return; }

  var url = new URL(req.url);

  // Jangan tangani: biarkan langsung ke network (data & unduhan live)
  if (url.pathname.indexOf('/api') === 0) { return; }
  if (url.pathname.indexOf('/download.php') === 0) { return; }
  if (url.pathname.indexOf('/version.php') === 0) { return; }

  // Hanya same-origin
  if (url.origin !== self.location.origin) { return; }

  // ---- Halaman HTML → NETWORK FIRST (selalu versi terbaru) ----
  if (req.mode === 'navigate' || (req.headers.get('accept') || '').indexOf('text/html') !== -1) {
    event.respondWith(
      fetch(req).then(function (response) {
        if (response && response.status === 200) {
          var copy = response.clone();
          caches.open(CACHE).then(function (cache) { cache.put(req, copy); });
        }
        return response;
      }).catch(function () {
        // Offline → fallback ke cache, lalu ke halaman utama
        return caches.match(req).then(function (cached) {
          return cached || caches.match('/');
        });
      })
    );
    return;
  }

  // ---- Aset statis → CACHE FIRST (cepat), fallback network ----
  event.respondWith(
    caches.match(req).then(function (cached) {
      if (cached) { return cached; }
      return fetch(req).then(function (response) {
        if (response && response.status === 200 && response.type === 'basic') {
          var copy = response.clone();
          caches.open(CACHE).then(function (cache) { cache.put(req, copy); });
        }
        return response;
      });
    })
  );
});
