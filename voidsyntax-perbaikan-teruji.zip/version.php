<?php
/**
 * version.php — cap versi website (dipakai untuk AUTO-REFRESH).
 *
 * Output: APP_VERSION + timestamp dari file-file utama website.
 * Berubah OTOMATIS setiap kali ada file yang di-upload/update —
 * tidak perlu diapa-apakan saat update.
 *
 * Dipakai oleh assets/js/app.js: halaman cek versi ini tiap 1 menit,
 * kalau berubah (ada update) → halaman reload sendiri.
 * Jangan hapus file ini.
 */
if (!defined('SITE_URL')) {
    require_once __DIR__ . '/config.php';
}
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

$files = array('index.php', 'cara-penggunaan.php', 'faq.php', 'kontak.php', 'app.php', 'includes/header.php', 'includes/footer.php', 'assets/css/style.css', 'assets/js/app.js', 'config.php', 'includes/functions.php', 'includes/i18n.php', 'lang/id.php', 'lang/en.php', 'lang/ms.php');
$stamp = '';
foreach ($files as $f) {
    $p = __DIR__ . '/' . $f;
    $stamp .= (is_file($p) ? (string)filemtime($p) : '0') . '.';
}
echo APP_VERSION . '|' . $stamp;
